local weapons = nil
local armor = nil
local objects = nil
local function loadItems()
    weapons = Ext.Stats.GetStats("Weapon")
    armor = Ext.Stats.GetStats("Armor")
    objects = Ext.Stats.GetStats("Object")

    L.Debug("Item lists loaded.", #objects, #armor, #weapons)
end

-------------------------------------------------------------------------------------------------
--                                                                                             --
--                                          Structures                                         --
--                                                                                             --
-------------------------------------------------------------------------------------------------

---@class Item : Struct
---@field Name string
---@field Type string
---@field RootTemplate string
---@field Rarity string
---@field GUID string|nil
---@field Slot string|nil
---@field Mod table
local V73_CUSTOM_ITEM_LOCA = {
    TOT_DAKOUSAI_ARMOR = {NameKey="TOT_DAKOUSAI_ARMOR_NAME", Name="h73a00000000000000000000000002001", Desc="h73a00000000000000000000000002002"},
    TOT_THOR_ARMOR = {NameKey="TOT_THOR_ARMOR_NAME", Name="h73a00000000000000000000000002011", Desc="h73a00000000000000000000000002012"},
    TOT_DAWN_CROWN = {NameKey="TOT_DAWN_CROWN_NAME", Name="h73a00000000000000000000000002021", Desc="h73a00000000000000000000000002022"},
    TOT_PREDATOR_BOOTS = {NameKey="TOT_PREDATOR_BOOTS_NAME", Name="h73a00000000000000000000000002031", Desc="h73a00000000000000000000000002032"},
    TOT_DEV_MACE = {NameKey="TOT_DEV_MACE_NAME", Name="h73a00000000000000000000000002041", Desc="h73a00000000000000000000000002042"},
    TOT_BARD_VIRTUOSO_CAP = {NameKey="TOT_BARD_VIRTUOSO_CAP_NAME", Name="h74a00000000000000000000000000101", Desc="h74a00000000000000000000000000102"},
    TOT_BARD_MAESTRO_GLOVES = {NameKey="TOT_BARD_MAESTRO_GLOVES_NAME", Name="h74a00000000000000000000000000111", Desc="h74a00000000000000000000000000112"},
    TOT_BARD_ENCORE_BOOTS = {NameKey="TOT_BARD_ENCORE_BOOTS_NAME", Name="h74a00000000000000000000000000121", Desc="h74a00000000000000000000000000122"},
    TOT_BARD_HARMONIC_DUELIST = {NameKey="TOT_BARD_HARMONIC_DUELIST_NAME", Name="h74a00000000000000000000000000131", Desc="h74a00000000000000000000000000132"},
    TOT_MONK_AWAKENED_FIST_BOOTS = {NameKey="TOT_MONK_AWAKENED_FIST_BOOTS_NAME", Name="h74a00000000000000000000000000141", Desc="h74a00000000000000000000000000142"},
    TOT_IMMORTAL_GUARDIAN_RING = {NameKey="TOT_IMMORTAL_GUARDIAN_RING_NAME", Name="h74a00000000000000000000000000151", Desc="h74a00000000000000000000000000152"},
    TOT_RING_OF_ELEMENTS = {NameKey="TOT_RING_OF_ELEMENTS_NAME", Name="h74a00000000000000000000000000161", Desc="h74a00000000000000000000000000162"},
    TOT_HERO_AMULET = {NameKey="TOT_HERO_AMULET_NAME", Name="h74a00000000000000000000000000171", Desc="h74a00000000000000000000000000172"},
    TOT_EXOSKELETAL_GAUNTLETS = {NameKey="TOT_EXOSKELETAL_GAUNTLETS_NAME", Name="h74a00000000000000000000000000181", Desc="h74a00000000000000000000000000182"},
    TOT_SUN_GOD_SCIMITAR = {NameKey="TOT_SUN_GOD_SCIMITAR_NAME", Name="h74i00000000000000000000000000101", Desc="h74i00000000000000000000000000102"},
    TOT_SUN_GOD_CAPE = {NameKey="TOT_SUN_GOD_CAPE_NAME", Name="h74i00000000000000000000000000111", Desc="h74i00000000000000000000000000112"},
    TOT_SUN_GOD_TUNIC = {NameKey="TOT_SUN_GOD_TUNIC_NAME", Name="h75g00000000000000000000000000101", Desc="h75g00000000000000000000000000102"},
    TOT_SUN_GOD_GLOVES = {NameKey="TOT_SUN_GOD_GLOVES_NAME", Name="h75g00000000000000000000000000111", Desc="h75g00000000000000000000000000112"},
    TOT_SUN_GOD_BOOTS = {NameKey="TOT_SUN_GOD_BOOTS_NAME", Name="h75g00000000000000000000000000121", Desc="h75g00000000000000000000000000122"},
    TOT_SUN_GOD_RING = {NameKey="TOT_SUN_GOD_RING_NAME", Name="h75g00000000000000000000000000131", Desc="h75g00000000000000000000000000132"},
    TOT_NECRO_TORCH = {NameKey="TOT_NECRO_TORCH_NAME", Name="h74i00000000000000000000000000121", Desc="h74i00000000000000000000000000122"},
    TOT_NECRO_HOOD = {NameKey="TOT_NECRO_HOOD_NAME", Name="h74i00000000000000000000000000131", Desc="h74i00000000000000000000000000132"},
    TOT_NECRO_ARMOR = {NameKey="TOT_NECRO_ARMOR_NAME", Name="h74i00000000000000000000000000141", Desc="h74i00000000000000000000000000142"},
    TOT_NECRO_STAFF = {NameKey="TOT_NECRO_STAFF_NAME", Name="h84s00000000000000000000000000101", Desc="h84s00000000000000000000000000102"},
    TOT_NECRO_CAPE = {NameKey="TOT_NECRO_CAPE_NAME", Name="h84s00000000000000000000000000111", Desc="h84s00000000000000000000000000112"},
    TOT_NECRO_BOW = {NameKey="TOT_NECRO_BOW_NAME", Name="h84s00000000000000000000000000121", Desc="h84s00000000000000000000000000122"},
    TOT_RADIANT_ARMOR = {NameKey="TOT_RADIANT_ARMOR_NAME", Name="h74p00000000000000000000000000101", Desc="h74p00000000000000000000000000102"},
    TOT_RADIANT_GLOVES = {NameKey="TOT_RADIANT_GLOVES_NAME", Name="h74p00000000000000000000000000111", Desc="h74p00000000000000000000000000112"},
    TOT_RADIANT_BOOTS = {NameKey="TOT_RADIANT_BOOTS_NAME", Name="h74p00000000000000000000000000121", Desc="h74p00000000000000000000000000122"},
    TOT_RADIANT_CAPE = {NameKey="TOT_RADIANT_CAPE_NAME", Name="h74p00000000000000000000000000131", Desc="h74p00000000000000000000000000132"},
    TOT_RADIANT_GOD_MACE = {NameKey="TOT_RADIANT_GOD_MACE_NAME", Name="h75k00000000000000000000000000101", Desc="h75k00000000000000000000000000102"},
    TOT_TWILIGHT_STAFF = {NameKey="TOT_TWILIGHT_STAFF_NAME", Name="h75j00000000000000000000000000101", Desc="h75j00000000000000000000000000102"},
    TOT_TWILIGHT_HELM = {NameKey="TOT_TWILIGHT_HELM_NAME", Name="h75j00000000000000000000000000111", Desc="h75j00000000000000000000000000112"},
    TOT_TWILIGHT_GLOVES = {NameKey="TOT_TWILIGHT_GLOVES_NAME", Name="h75j00000000000000000000000000121", Desc="h75j00000000000000000000000000122"},
    TOT_TWILIGHT_RING = {NameKey="TOT_TWILIGHT_RING_NAME", Name="h75j00000000000000000000000000131", Desc="h75j00000000000000000000000000132"},
    TOT_BERSERKER_HELMET = {NameKey="TOT_BERSERKER_HELMET_NAME", Name="h74p00000000000000000000000000141", Desc="h74p00000000000000000000000000142"},
}
local RANDOM_MYTHIC_ITEMS = {
    Weapon = {
        "TOT_ZENITH_HALBERD",
        "TOT_FUNERAL_TIDE_TRIDENT",
    },
    Armor = {
        "TOT_MYTHIC_ABSOLUTE_AMULET",
    },
}
local RANDOM_MYTHIC_LOOKUP = {}
for _, categoryItems in pairs(RANDOM_MYTHIC_ITEMS) do
    for _, name in ipairs(categoryItems) do
        RANDOM_MYTHIC_LOOKUP[name] = true
    end
end

local function GetRandomMythicItems(category)
    local names = RANDOM_MYTHIC_ITEMS[category] or {}
    return Item.Get(names, category, nil)
end

local REWARD_ONLY_ITEMS = {
    ["TOT_RG150_BOOOAL_AMULET"] = true,
    ["TOT_DEV_MACE"] = true, -- Mythic unique: dedicated acquisition/debug only; never Legendary/Mythic random loot
    -- Conqueror prototype: test/reward only, never random loot.
    ["TOT_CONQ_HELMET"] = true,
    ["TOT_CONQ_ARMOR"] = true,
    ["TOT_CONQ_GLOVES"] = true,
    ["TOT_CONQ_BOOTS"] = true,
    ["TOT_CONQ_CAPE"] = true,
    ["TOT_CONQ_RING"] = true,
    ["TOT_CONQ_BLADE"] = true,
    ["TOT_CONQ_AMULET"] = true,
}

local Object = Libs.Struct({
    Name = nil,
    Type = nil,
    RootTemplate = "",
    Rarity = C.ItemRarity[1],
    GUID = nil,
    Slot = nil,
    Tab = nil,
    Mod = {},
})

---@param name string
---@param type string
---@param fake boolean|nil
---@return Item
function Object.New(name, type, fake)
    local o = Object.Init()

    o.Name = name
    o.Type = type

    if not fake then
        local item = Ext.Stats.Get(name)
        o.RootTemplate = item.RootTemplate
        o.Rarity = item.Rarity
        o.Tab = item.InventoryTab

        if type == "Armor" or type == "Weapon" then
            o.Slot = item.Slot
        end
        if type == "Object" or type == "CombatObject" then
            o.Slot = item.ItemUseType
        end

        local mod = Ext.Mod.GetMod(item.ModId)
        local modName = "Invalid Mod UUID"
        if mod then
            modName = mod.Info.Directory
        end

        o.Mod = { item.ModId, modName }
    end

    o.GUID = nil

    return o
end

function Object:ModifyTemplate()
    local template = self:GetTemplate()

    if template.Stats ~= self.Name then
        Event.Trigger("TemplateOverwrite", self.RootTemplate, "Stats", self.Name)
    end
end

function Object:IsSpawned()
    return self.GUID ~= nil
end

function Object:GetTemplate()
    return Ext.Template.GetTemplate(self.RootTemplate)
end

function Object:GetTranslatedName()
    local handle
    if self:IsSpawned() then
        handle = Osi.GetDisplayName(self.GUID)
    else
        handle = self:GetTemplate().DisplayName.Handle.Handle
    end
    return Osi.ResolveTranslatedString(handle)
end

---@param x number
---@param y number
---@param z number
---@return boolean
function Object:Spawn(x, y, z)
    if self:IsSpawned() then
        return false
    end

    -- V7.4H: Never leave a shared vanilla RootTemplate pointing at custom Stats.
    -- Find a valid spawn point first, then overwrite only for the CreateAt call,
    -- pin the created item's cache to the requested stat, and restore immediately.
    x, y, z = Osi.FindValidPosition(x, y, z, 100, C.NPCCharacters.Volo, 1)
    if not x or not y or not z then
        L.Error("Failed to find valid position for: ", self.Name)
        return false
    end

    local template = self:GetTemplate()
    if not template then
        L.Error("Failed to get root template for: ", self.Name, self.RootTemplate)
        return false
    end

    local originalStat = template.Stats
    local needsOverwrite = originalStat ~= self.Name
    if needsOverwrite then
        Event.Trigger("TemplateOverwrite", self.RootTemplate, "Stats", self.Name)
    end

    local ok, guid = pcall(Osi.CreateAt, self.RootTemplate, x, y, z, 0, 1, "")

    -- Restore the vanilla/shared template before doing anything else.
    if needsOverwrite then
        Event.Trigger("TemplateOverwrite", self.RootTemplate, "Stats", originalStat)
    end

    if not ok then
        L.Error("CreateAt failed for: ", self.Name, guid)
        return false
    end

    self.GUID = guid

    if self:IsSpawned() and self.GUID ~= "" then
        local entity = Ext.Entity.Get(self.GUID)
        local serverItem = entity and entity.ServerItem

        -- Create at most one cache template for this spawned instance. Reusing the
        -- same cache avoids calling CreateCacheTemplate() twice on localized
        -- custom items, which produces "already a cache template" warnings.
        local cached = nil
        if serverItem and serverItem.CreateCacheTemplate and (needsOverwrite or V73_CUSTOM_ITEM_LOCA[self.Name]) then
            cached = serverItem:CreateCacheTemplate()
        end

        -- The spawned instance must keep the custom stat after the RootTemplate is restored.
        if needsOverwrite and cached then
            cached.Stats = self.Name
        end

        local loca = V73_CUSTOM_ITEM_LOCA[self.Name]
        if loca then
            if cached then
                cached.Stats = self.Name
                if cached.DisplayName and cached.DisplayName.Handle then cached.DisplayName.Handle.Handle = loca.Name end
                if cached.Description and cached.Description.Handle then cached.Description.Handle.Handle = loca.Desc end
            end
            if Ext.Loca and Ext.Loca.UpdateTranslatedStringKey then Ext.Loca.UpdateTranslatedStringKey(loca.NameKey, loca.Name); Osi.SetStoryDisplayName(self.GUID, loca.NameKey) end
        end
        PersistentVars.SpawnedItems[self.GUID] = self

        return true
    end

    L.Error("Failed to spawn: ", self.Name)

    return false
end

function Object:Clear()
    local guid = self.GUID
    self.GUID = nil

    RetryUntil(function()
        GU.Object.Remove(guid)
        return Osi.IsItem(guid) ~= 1
    end, { immediate = true }):After(function()
        PersistentVars.SpawnedItems[guid] = nil
    end):Catch(function()
        L.Error("Failed to delete item: ", guid, self.Name)
    end)
end

-------------------------------------------------------------------------------------------------
--                                                                                             --
--                                            Public                                           --
--                                                                                             --
-------------------------------------------------------------------------------------------------

function Item.Create(name, type, rootTemplate, rarity)
    local item = Object.New(name, type, true)
    item.RootTemplate = rootTemplate
    item.Rarity = rarity

    return item
end

local itemCache = {
    Objects = {},
    Armor = {},
    Weapons = {},
    CombatObjects = {},
    ModList = nil,
}

function Item.ClearCache()
    itemCache = {
        Objects = {},
        Armor = {},
        Weapons = {},
        CombatObjects = {},
        ModList = nil,
    }
end

function Item.Get(items, type, rarity)
    return table.map(items, function(name)
        local item = Object.New(name, type)

        if rarity == nil or item.Rarity == rarity then
            return item
        end
    end)
end

function Item.Objects(rarity, forCombat)
    local cacheKey = forCombat and "CombatObjects" or "Objects"
    local type = forCombat and "CombatObject" or "Object"

    if #itemCache[cacheKey] > 0 then
        return Item.Get(itemCache[cacheKey], type, rarity)
    end

    if objects == nil then
        loadItems()
    end

    local itemFilters = External.Templates.GetItemFilters()

    local items = table.filter(objects, function(name)
        local stat = Ext.Stats.Get(name)
        if not stat then
            return false
        end
        local cat = stat.ObjectCategory
        local tab = stat.InventoryTab
        local type = stat.ItemUseType

        if REWARD_ONLY_ITEMS[name] or RANDOM_MYTHIC_LOOKUP[name] then return false end
        if string.contains(stat.ModId, itemFilters.Mods, true, true) then
            return false
        end

        if string.contains(name, itemFilters.Names, true) then
            return false
        end

        if name:match("^_") then
            return false
        end

        if stat.Rarity == "" or stat.RootTemplate == "" then
            return false
        end

        if forCombat then
            if not (type == "Potion" or tab == "Magical") then
                return false
            end
        else
            if
                not (
                    ((cat:match("^Food") or cat:match("^Drink")) and name:match("^CONS_"))
                    -- or cat:match("^Drink")
                    -- alchemy items
                    or name:match("^ALCH_Ingredient")
					
					or name:match("^GLO_SoulCoin")
                )
            then
                return false
            end
        end

        local temp = Ext.Template.GetTemplate(stat.RootTemplate)
        if not temp or temp.Name:match("DONOTUSE$") then
            return false
        end

        local a = Ext.Stats.TreasureCategory.GetLegacy("I_" .. name)
        local b = Ext.Stats.TreasureCategory.GetLegacy("I_" .. temp.Name)
        local c = false
        for _, v in pairs(string.split(stat.ObjectCategory, ";")) do
            c = Ext.Stats.TreasureCategory.GetLegacy(v)
            if c then
                break
            end
        end
        if not a and not b and not c then
            return false
        end

        return true
    end)

    itemCache[cacheKey] = items

    return Item.Get(items, type, rarity)
end

function Item.Armor(rarity)
    if #itemCache.Armor > 0 then
        return Item.Get(itemCache.Armor, "Armor", rarity)
    end

    if armor == nil then
        loadItems()
    end

    local itemFilters = External.Templates.GetItemFilters()

    local items = table.filter(armor, function(name)
        local stat = Ext.Stats.Get(name)
        if not stat then
            return false
        end
        local slot = stat.Slot

        if REWARD_ONLY_ITEMS[name] or RANDOM_MYTHIC_LOOKUP[name] then return false end
        if string.contains(stat.ModId, itemFilters.Mods, true, true) then
            return false
        end

        if string.contains(name, itemFilters.Names, true) then
            return false
        end

        if name:match("^_") then
            return false
        end

        if
            not Config.LootIncludesCampSlot
            and (slot:match("VanityBody") or slot:match("VanityBoots") or slot:match("Underwear"))
        then
            return false
        end

        if stat.Rarity == "" or stat.RootTemplate == "" then
            return false
        end

        -- doesnt exist iirc
        if stat.UseConditions ~= "" then
            return false
        end

        local temp = Ext.Template.GetTemplate(stat.RootTemplate)
        if not temp or temp.Name:match("DONOTUSE$") then
            return false
        end

        return true
    end)

    -- V7.5C: TOT_RADIANT_ARMOR is a custom Very Rare armour and must remain
    -- explicitly eligible even if the generic Stats scan/filter misses its
    -- Paladin-devotion base template. This affects every caller of Item.Armor,
    -- including random end-combat loot and Tav Currency equipment chests.
    local radiantArmor = Ext.Stats.Get("TOT_RADIANT_ARMOR")
    if radiantArmor then
        local found = false
        for _, itemName in ipairs(items) do
            if itemName == "TOT_RADIANT_ARMOR" then
                found = true
                break
            end
        end
        if not found then
            table.insert(items, "TOT_RADIANT_ARMOR")
            L.Debug("V7.5C: forced TOT_RADIANT_ARMOR into Armor loot pool")
        end
    else
        L.Error("V7.5C: TOT_RADIANT_ARMOR Stats entry was not loaded")
    end

    itemCache.Armor = items

    return Item.Get(items, "Armor", rarity)
end

function Item.Weapons(rarity)
    if #itemCache.Weapons > 0 then
        return Item.Get(itemCache.Weapons, "Weapon", rarity)
    end

    if weapons == nil then
        loadItems()
    end

    local itemFilters = External.Templates.GetItemFilters()

    local items = table.filter(weapons, function(name)
        local stat = Ext.Stats.Get(name)
        if not stat then
            return false
        end

        if REWARD_ONLY_ITEMS[name] or RANDOM_MYTHIC_LOOKUP[name] then return false end
        if string.contains(stat.ModId, itemFilters.Mods, true, true) then
            return false
        end

        if string.contains(name, itemFilters.Names, true) then
            return false
        end

        if name:match("^_") then
            return false
        end

        if stat.Rarity == "" or stat.RootTemplate == "" then
            return false
        end

        -- weapons that can't be used by players
        if stat.UseConditions ~= "" then
            return false
        end

        local temp = Ext.Template.GetTemplate(stat.RootTemplate)
        if not temp or temp.Name:match("DONOTUSE$") then
            return false
        end

        return true
    end)

    itemCache.Weapons = items

    return Item.Get(items, "Weapon", rarity)
end

-- not used
function Item.Cleanup()
    for guid, item in pairs(PersistentVars.SpawnedItems) do
        Object.Init(item):Clear()
    end
end

function Item.DestroyAll(rarity, type)
    local count = 0
    for guid, item in pairs(PersistentVars.SpawnedItems) do
        if item.Rarity == rarity and not GU.Object.IsOwned(item.GUID) and (not type or item.Type == type) then
            Object.Init(item):Clear()
            count = count + 1
        end
    end

    return count
end

function Item.PickupAll(character, rarity, type)
    local count = 0

    for _, item in pairs(PersistentVars.SpawnedItems) do
        if
            not GU.Object.IsOwned(item.GUID)
            and (type == nil or item.Type == type)
            and (rarity == nil or item.Rarity == rarity)
        then
            Osi.ToInventory(item.GUID, GC.GetPlayer(character))
            count = count + 1
            Schedule(function()
                if GU.Object.IsOwned(item.GUID) or Osi.IsItem(item.GUID) ~= 1 then
                    PersistentVars.SpawnedItems[item.GUID] = nil
                end
            end)
        end
    end

    return count
end

function Item.PickupLoot(character)
    for type, data in pairs(PersistentVars.LootFilter) do
        for rarity, pickup in pairs(data) do
            if pickup then
                Item.PickupAll(character or Player.Host(), rarity, type)
            else
                Item.DestroyAll(rarity, type)
            end
        end
    end
end

function Item.SpawnLoot(loot, x, y, z, autoPickup)
    local i = 0
    local pingedLoot = {}
    for _, item in pairs(loot) do
        if item.Type ~= "Object" then
            table.insert(pingedLoot, item)
        else
            item:Spawn(x, y, z)
        end
    end

    if #pingedLoot == 0 then
        return
    end

    Async.Interval(200 - (#pingedLoot * 2), function(self)
        i = i + 1

        if i > #pingedLoot then
            self:Clear()
            if autoPickup and Player.InCamp() then
                Item.PickupLoot()
            end

            return
        end

        if pingedLoot[i] == nil then
            L.Error("Loot was empty.", i, #pingedLoot)
            return
        end

		-- the spawn coordinates don't matter at all, it doesn't need newRandom.
        local x2 = x + math.random() * math.random(-1, 1)
        local z2 = z + math.random() * math.random(-1, 1)
        local item = pingedLoot[i]

        if item:Spawn(x2, y, z2) then
            Osi.RequestPing(x2, y, z2, item.GUID, "")
        end
    end)
end

-------------------------------------------------------------------------------------------------
--                                     CRAFT V1 (CUSTOM)                                      --
-------------------------------------------------------------------------------------------------
-- Food keeps the original Trials of Tav roll/chance. Craft is controlled separately by
-- RogueScore and weighted cumulative recipe pools. Each craft roll is independent RNG while
-- RogueScore restrictions keep the available ingredients appropriate to progression.

local CraftV1 = {
    TierSettings = {
        { MinScore = 0,   Chance = 0.55, Cap = 10 },
        { MinScore = 50,  Chance = 0.62, Cap = 12 },
        { MinScore = 100, Chance = 0.68, Cap = 15 },
        { MinScore = 200, Chance = 0.74, Cap = 18 },
        { MinScore = 350, Chance = 0.82, Cap = 22 },
    },

    -- Weight reduction for recipes from older RogueScore tiers.
    AgeMultiplier = { 1.00, 0.85, 0.65, 0.50, 0.40 },

    -- Ingredient = BG3 stats/UID name for the raw alchemy ingredient.
    -- Extract = extract family produced by the ingredient.
    -- Secondary = generic extract family required by the final recipe.
    Recipes = {
        -- RG 0-49
        { Label = "Potion of Healing",          Ingredient = "CONS_Mushrooms_RoguesMorsel", Tier = 1, MinScore = 0,   Weight = 16, Extract = "Salt",       Secondary = "Suspension" },
        { Label = "Potion of Greater Healing",  Ingredient = "CONS_Herbs_Balsam",            Tier = 1, MinScore = 0,   Weight = 14, Extract = "Ashes",      Secondary = "Salt" },
        { Label = "Elixir of Fire Resistance",  Ingredient = "CONS_Mushrooms_DragonEggMushroom",             Tier = 1, MinScore = 0,   Weight = 10, Extract = "Ashes",      Secondary = "Salt" },
        { Label = "Elixir of Poison Resistance",Ingredient = "ALCH_Ingredient_Part_MudMephitWing",     Tier = 1, MinScore = 0,   Weight = 8,  Extract = "Suspension", Secondary = "Sublimate" },
        { Label = "Oil of Accuracy",            Ingredient = "CONS_Herbs_Daggeroot",          Tier = 1, MinScore = 0,   Weight = 10, Extract = "Ashes",      Secondary = "Salt" },

        -- RG 50-99
        { Label = "Potion of Speed",             Ingredient = "ALCH_Ingredient_Part_HyenaEar",              Tier = 2, MinScore = 50,  Weight = 8,  Extract = "Ashes",      Secondary = "Salt" },
        { Label = "Elixir of Bloodlust",          Ingredient = "ALCH_Ingredient_Part_WorgFang",         Tier = 2, MinScore = 50,  Weight = 5,  Extract = "Ashes",      Secondary = "Salt" },
        { Label = "Elixir of the Colossus",       Ingredient = "OBJ_Crystal_ChasmCreeper",   Tier = 2, MinScore = 50,  Weight = 7,  Extract = "Salt",       Secondary = "Suspension" },
        { Label = "Drow Poison",                  Ingredient = "CONS_Mushrooms_SwarmingToadstool",     Tier = 2, MinScore = 50,  Weight = 8,  Extract = "Essence",    Secondary = "Salt" },

        -- RG 100-199
        { Label = "Potion of Superior Healing",   Ingredient = "ALCH_Ingredient_Loot_YellowMuskCreeper", Tier = 3, MinScore = 100, Weight = 10, Extract = "Salt",       Secondary = "Suspension" },
        { Label = "Elixir of Necrotic Resistance",Ingredient = "ALCH_Ingredient_Herb_BlackOleander",       Tier = 3, MinScore = 100, Weight = 7,  Extract = "Vitriol",    Secondary = "Sublimate" },
        { Label = "Elixir of Psychic Resistance", Ingredient = "ALCH_Ingredient_Part_IntellectDevourer",    Tier = 3, MinScore = 100, Weight = 6,  Extract = "Suspension", Secondary = "Sublimate" },
        { Label = "Elixir of Viciousness",         Ingredient = "ALCH_Ingredient_Mushroom_ShadowrootSac",    Tier = 3, MinScore = 100, Weight = 5,  Extract = "Vitriol",    Secondary = "Ashes" },
        { Label = "Potion of Invisibility",        Ingredient = "ALCH_Ingredient_Part_ImpPatagium",          Tier = 3, MinScore = 100, Weight = 6,  Extract = "Ashes",      Secondary = "Essence" },
        { Label = "Haste Spore Grenade",           Ingredient = "ALCH_Ingredient_Part_MyconidSpore_Haste",   Tier = 3, MinScore = 100, Weight = 4,  Extract = "Sublimate",  Secondary = "Essence" },

        -- RG 200-349
        { Label = "Elixir of Cloud Giant Strength",Ingredient = "ALCH_Ingredient_Loot_CloudGiantFinger", Tier = 4, MinScore = 200, Weight = 3, Extract = "Salt",      Secondary = "Suspension" },
        { Label = "Potion of Flying",               Ingredient = "ALCH_Ingredient_Part_EagleFeather",      Tier = 4, MinScore = 200, Weight = 5, Extract = "Sublimate", Secondary = "Essence" },

        -- RG 350+
        { Label = "Potion of Supreme Healing",      Ingredient = "ALCH_Ingredient_Loot_KiRinHair",         Tier = 5, MinScore = 350, Weight = 7, Extract = "Sublimate", Secondary = "Ashes" },
        { Label = "Elixir of Universal Resistance", Ingredient = "ALCH_Ingredient_Loot_DivineBoneShard",   Tier = 5, MinScore = 350, Weight = 1, Extract = "Vitriol",   Secondary = "Sublimate" },
    },

    -- Only needed when an unlocked recipe pool cannot yet create a required extract family.
    -- Autumncrocus gives Sublimate and is intentionally the only support-only ingredient in V1.
    SupportIngredients = {
        { Ingredient = "CONS_Herbs_Autumncrocus", Extract = "Sublimate", MinScore = 0, Weight = 8 },
    },
}

local craftState = {
    Drops = 0,
}

local function craftTier(score)
    local tier = 1
    for i, data in ipairs(CraftV1.TierSettings) do
        if score >= data.MinScore then
            tier = i
        end
    end
    return tier, CraftV1.TierSettings[tier]
end

local function craftRecipeWeight(recipe, currentTier)
    local age = math.max(0, currentTier - recipe.Tier)
    local multiplier = CraftV1.AgeMultiplier[math.min(age + 1, #CraftV1.AgeMultiplier)] or 0.40
    return recipe.Weight * multiplier
end

local function craftStatExists(name)
    return name ~= nil and Ext.Stats.Get(name) ~= nil
end

-- Validate every configured raw ingredient against BG3 Object Stats.
-- This is intentionally noisy on errors so a wrong Stats ID can no longer
-- silently collapse a RogueScore tier to one surviving ingredient.
local function validateCraftTable()
    local validRecipes = 0
    local invalidRecipes = 0

    for _, recipe in ipairs(CraftV1.Recipes) do
        if craftStatExists(recipe.Ingredient) then
            validRecipes = validRecipes + 1
        else
            invalidRecipes = invalidRecipes + 1
            L.Error("Craft V1.2 invalid recipe ingredient Stats ID:", recipe.Label, recipe.Ingredient)
        end
    end

    for _, support in ipairs(CraftV1.SupportIngredients) do
        if not craftStatExists(support.Ingredient) then
            L.Error("Craft V1.2 invalid support ingredient Stats ID:", support.Ingredient)
        end
    end

    L.Debug("Craft V1.2 table validation:", validRecipes, "valid recipes;", invalidRecipes, "invalid recipes")
end

local function unlockedCraftRecipes(score)
    local out = {}
    for _, recipe in ipairs(CraftV1.Recipes) do
        if score >= recipe.MinScore and craftStatExists(recipe.Ingredient) then
            table.insert(out, recipe)
        end
    end
    return out
end

local function weightedCraftRecipe(recipes, currentTier, excludeIngredient)
    local candidates = {}
    local total = 0

    for _, recipe in ipairs(recipes) do
        if recipe.Ingredient ~= excludeIngredient then
            local weight = craftRecipeWeight(recipe, currentTier)
            if weight > 0 then
                total = total + weight
                table.insert(candidates, { Recipe = recipe, Weight = weight })
            end
        end
    end

    if total <= 0 then
        return nil
    end

    local roll = math.newRandom() * total
    local cursor = 0
    for _, candidate in ipairs(candidates) do
        cursor = cursor + candidate.Weight
        if roll <= cursor then
            return candidate.Recipe
        end
    end

    return candidates[#candidates] and candidates[#candidates].Recipe or nil
end

local function resetCraftState()
    craftState.Drops = 0
end

local function craftSecondarySource(extractType, score, currentTier, unlocked)
    local candidates = {}
    local total = 0
    local seen = {}

    -- Prefer ingredients that are already part of unlocked approved recipes.
    for _, recipe in ipairs(unlocked) do
        if recipe.Extract == extractType and not seen[recipe.Ingredient] then
            local weight = craftRecipeWeight(recipe, currentTier)
            if weight > 0 then
                total = total + weight
                table.insert(candidates, { Ingredient = recipe.Ingredient, Weight = weight })
                seen[recipe.Ingredient] = true
            end
        end
    end

    -- Fallback/support ingredients only when the approved recipes cannot provide this extract yet.
    if #candidates == 0 then
        for _, support in ipairs(CraftV1.SupportIngredients) do
            if
                support.Extract == extractType
                and score >= support.MinScore
                and craftStatExists(support.Ingredient)
                and not seen[support.Ingredient]
            then
                total = total + support.Weight
                table.insert(candidates, { Ingredient = support.Ingredient, Weight = support.Weight })
                seen[support.Ingredient] = true
            end
        end
    end

    if total <= 0 then
        return nil
    end

    local roll = math.newRandom() * total
    local cursor = 0
    for _, candidate in ipairs(candidates) do
        cursor = cursor + candidate.Weight
        if roll <= cursor then
            return candidate.Ingredient
        end
    end

    return candidates[#candidates] and candidates[#candidates].Ingredient or nil
end

local function craftQuantity()
    local roll = math.newRandom()
    if roll < 0.70 then
        return 1
    elseif roll < 0.95 then
        return 2
    end
    return 3
end

local function craftIngredientForRecipe(recipe, score, currentTier, unlocked)
    -- 60% main ingredient, 40% a compatible source for the generic secondary extract.
    if math.newRandom() < 0.60 then
        return recipe.Ingredient
    end

    return craftSecondarySource(recipe.Secondary, score, currentTier, unlocked) or recipe.Ingredient
end

---@param scenario Scenario
---@param rolls integer|nil Number of craft groups to force-generate (still respects encounter cap)
---@return Item[]
function Item.GenerateCraftLoot(scenario, rolls)
    local loot = {}
    local score = math.max(0, PersistentVars.RogueScore or 0)
    local currentTier, settings = craftTier(score)
    local state = craftState
    local unlocked = unlockedCraftRecipes(score)

    rolls = rolls or 1

    for _ = 1, rolls do
        if state.Drops >= settings.Cap or #unlocked == 0 then
            break
        end

        -- Pure weighted RNG: every craft group independently chooses among all recipes
        -- unlocked for the current RogueScore. No persistent/focused recipe is retained.
        local recipe = weightedCraftRecipe(unlocked, currentTier)

        if recipe then
            local ingredient = craftIngredientForRecipe(recipe, score, currentTier, unlocked)
            if ingredient and craftStatExists(ingredient) then
                local quantity = craftQuantity()
                for _ = 1, quantity do
                    table.insert(loot, Object.New(ingredient, "Object"))
                end
                state.Drops = state.Drops + 1
                L.Debug("Craft V1.2 drop:", recipe.Label, ingredient, "x" .. tostring(quantity), "groups", state.Drops .. "/" .. settings.Cap)
            else
                L.Error("Craft V1 missing ingredient stat:", ingredient or "nil", recipe.Label)
            end
        end
    end

    return loot
end

---@param scenario Scenario
---@return Item[]
function Item.TryGenerateCraftLoot(scenario)
    local score = math.max(0, PersistentVars.RogueScore or 0)
    local _, settings = craftTier(score)
    local state = craftState

    if state.Drops >= settings.Cap or math.newRandom() >= settings.Chance then
        return {}
    end

    return Item.GenerateCraftLoot(scenario, 1)
end

function Item.GenerateSimpleLoot(rolls, chanceFood, lootRates, scenario)
    local loot = {}

    if not lootRates then
        lootRates = C.LootRates
    end

    rolls = rolls or 1
    chanceFood = chanceFood or 0.5

    for i = 1, rolls do
        local isFood = math.newRandom() < chanceFood

        if isFood then
            -- Original Trials of Tav food logic: unchanged.
            local items = Item.Objects(nil, false)
            items = table.filter(items, function(item)
                return item.Tab == "Consumable"
            end)

            L.Debug("Rolling kill food items:", #items, "Object")
            if #items > 0 then
                table.insert(loot, table.deepclone(items[math.newRandom(#items)]))
            end
        elseif scenario then
            -- Original non-food/alchemy roll now uses the controlled Craft V1 table.
            for _, item in ipairs(Item.GenerateCraftLoot(scenario, 1)) do
                table.insert(loot, item)
            end
        else
            -- Compatibility fallback for any external call that does not provide a scenario.
            local items = Item.Objects(nil, false)
            items = table.filter(items, function(item)
                return item.Tab ~= "Consumable"
            end)
            if #items > 0 then
                table.insert(loot, table.deepclone(items[math.newRandom(#items)]))
            end
        end
    end

    return table.deepclone(loot)
end

-- V7.5E: RogueScore-scaled rarity weights for EQUIPMENT ONLY.
-- CombatObject is intentionally fixed so scroll/consumable/alchemy behaviour is untouched.
-- Armor is the existing Trials equipment bucket and includes armour + jewellery slots
-- (rings and amulets); Weapons remains the weapon bucket.
local END_COMBAT_OBJECT_RATES = {
    Common = 40,
    Uncommon = 20,
    Rare = 10,
    VeryRare = 5,
    Legendary = 2,
}

local END_COMBAT_EQUIPMENT_TIERS = {
    -- 200 tickets = exact support for 0.5% Mythic without floating-point array sizes.
    -- Percentages among equipment rolls:
    -- RG 0-149   65 / 22 / 11 / 2 / 0
    -- RG 150-199 34.5 / 40 / 20 / 5 / 0.5
    -- RG 200-299 14 / 45 / 30 / 10 / 1
    -- RG 300+    3 / 40 / 40 / 15 / 2
    { MinScore = 0,   Weights = { Uncommon = 130, Rare = 44, VeryRare = 22, Legendary = 4,  Mythic = 0 } },
    { MinScore = 150, Weights = { Uncommon = 69,  Rare = 80, VeryRare = 40, Legendary = 10, Mythic = 1 } },
    { MinScore = 200, Weights = { Uncommon = 28,  Rare = 90, VeryRare = 60, Legendary = 20, Mythic = 2 } },
    { MinScore = 300, Weights = { Uncommon = 6,   Rare = 80, VeryRare = 80, Legendary = 30, Mythic = 4 } },
}

local function GetEndCombatLootRates()
    local score = math.max(0, PersistentVars.RogueScore or 0)
    local selected = END_COMBAT_EQUIPMENT_TIERS[1].Weights

    for _, tier in ipairs(END_COMBAT_EQUIPMENT_TIERS) do
        if score >= tier.MinScore then
            selected = tier.Weights
        else
            break
        end
    end

    -- Deep-copy the selected weights so no caller can mutate the shared tier table.
    return {
        Objects = table.deepclone(END_COMBAT_OBJECT_RATES),
        Armor = table.deepclone(selected),
        Weapons = table.deepclone(selected),
    }
end

function Item.GenerateLoot(rolls, lootRates, endCombatOnly)
    local loot = {}

    -- Normal callers keep their original loot table. Scenario-end rewards use a dedicated
    -- equipment-focused table: no Common equipment and only a small scroll slot.
    -- Unlock rewards may opt into EquipmentOnly to exclude every CombatObject while
    -- preserving the normal item generation / blacklist pipeline.
    if endCombatOnly then
        lootRates = GetEndCombatLootRates()
    elseif not lootRates then
        lootRates = C.LootRates
    end
    local equipmentOnly = lootRates.EquipmentOnly == true

    local function add(t, rarity, amount)
        for i = 1, amount do
            table.insert(t, rarity)
        end

        return t
    end

    -- build rarity roll tables from template e.g. { "Common", "Common", "Uncommon", "Rare" }
    -- if rarity is 0 it will be at least added once
    -- if rarity is not defined it will not be added
    local rarities = {}
    for _, category in ipairs({ "CombatObject", "Weapon", "Armor" }) do
        local rarity = {}

        for _, r in ipairs(C.ItemRarity) do
            if category == "CombatObject" and lootRates.Objects and lootRates.Objects[r] then
                add(rarity, r, lootRates.Objects[r])
            elseif category == "Weapon" and lootRates.Weapons and lootRates.Weapons[r] then
                add(rarity, r, lootRates.Weapons[r])
            elseif category == "Armor" and lootRates.Armor and lootRates.Armor[r] then
                add(rarity, r, lootRates.Armor[r])
            end
        end
        -- Mythic is a Trials Ascension logical rarity above Legendary. BG3 Stats does not
        -- expose it as a native Stats rarity enum, so only end-combat equipment tables add
        -- this explicit ticket and resolve it through RANDOM_MYTHIC_ITEMS below.
        if category == "Weapon" and lootRates.Weapons and lootRates.Weapons.Mythic then
            add(rarity, "Mythic", lootRates.Weapons.Mythic)
        elseif category == "Armor" and lootRates.Armor and lootRates.Armor.Mythic then
            add(rarity, "Mythic", lootRates.Armor.Mythic)
        end

        rarities[category] = rarity
    end

    local lastCategory = nil
    local function rollCategory()
        if endCombatOnly then
            -- 5% Scroll / 40% Weapon / 55% Armor+Jewelry.
            return ({
                "CombatObject",
                "Weapon", "Weapon", "Weapon", "Weapon", "Weapon", "Weapon", "Weapon", "Weapon",
                "Armor", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor"
            })[math.newRandom(20)]
        elseif equipmentOnly then
            -- Unlock chests: equipment only. Armor includes jewellery slots.
            -- 40% weapons / 60% armor+jewellery.
            return ({ "Weapon", "Weapon", "Weapon", "Weapon",
                      "Armor", "Armor", "Armor", "Armor", "Armor", "Armor" })[math.newRandom(10)]
        end

        return ({ "CombatObject", "Weapon", "Weapon", "Weapon", "Weapon", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor", "Armor" })[math.newRandom(12)]
    end

    for i = 1, rolls do
        local items = {}
        local fail = 0

        local rarity = nil
        -- avoid 0 rolls e.g. legendary objects dont exist
        while #items == 0 and fail < 10 do
            fail = fail + 1

            local category = rollCategory()
            -- Keep the original anti-repeat behaviour for legacy loot, but do not distort
            -- the explicit 5/40/55 end-combat probabilities.
            if not endCombatOnly and category == lastCategory then
                category = rollCategory()
            end
            lastCategory = category

            rarity = rarities[category][math.newRandom(#rarities[category])]

            if category == "CombatObject" then
                items = Item.Objects(rarity, true)
                if #items > 0 then
                    if endCombatOnly then
                        -- End-of-combat CombatObject rolls are scrolls only: no potions,
                        -- arrows, grenades or other combat consumables. Item blacklist
                        -- filtering still happens inside Item.Objects().
                        items = table.filter(items, function(item)
                            return item.Slot == "Scroll" or item.Name:match("^OBJ_Scroll")
                        end)
                    else
                        local bySlot = UT.GroupBy(items, "Slot")
                        local slots = table.keys(bySlot)
                        local randomSlot = slots[math.newRandom(#slots)]
                        L.Debug("Rolling CombatObject loot slot:", randomSlot, rarity)

                        if randomSlot == "Potion" and math.newRandom() < 0.40 then
                            items = table.filter(items, function(item)
                                return item.Name:match("^OBJ_Potion_Healing")
                            end)
                        else
                            items = table.values(bySlot[randomSlot])
                        end
                    end
                end
            elseif category == "Weapon" then
                if rarity == "Mythic" then
                    items = GetRandomMythicItems("Weapon")
                else
                    items = Item.Weapons(rarity)
                end
            elseif category == "Armor" then
                if rarity == "Mythic" then
                    items = GetRandomMythicItems("Armor")
                else
                    items = Item.Armor(rarity)
                end
                if #items > 0 and rarity ~= "Mythic" then
                    local bySlot = UT.GroupBy(items, "Slot")
                    local slots = table.keys(bySlot)
                    local randomSlot = slots[math.newRandom(#slots)]
                    L.Debug("Rolling Armor loot slot:", randomSlot, rarity)
                    items = table.values(bySlot[randomSlot])
                end
            end

            L.Debug("Rolling bonus loot items:", #items, category, rarity)
        end

        if #items > 0 then
            local random = items[math.newRandom(#items)]

            if table.contains(PersistentVars.RandomLog.Items, random.Name) then
                random = items[math.newRandom(#items)]
            end
            LogRandom("Items", random.Name, 100)

            table.insert(loot, table.deepclone(random))
        end
    end

    return table.deepclone(loot)
end

function Item.GetModList()
    if itemCache.ModList then
        return itemCache.ModList
    end

    local mods = {}

    for _, l in ipairs({ Item.Armor(), Item.Weapons(), Item.Objects(nil, false), Item.Objects(nil, true) }) do
        for _, item in ipairs(l) do
            if item.Mod[1] then
                mods[item.Mod[1]] = item.Mod[2]
            end
        end
    end

    itemCache.ModList = mods

    return mods
end

-------------------------------------------------------------------------------------------------
--                                                                                             --
--                                           Events                                            --
--                                                                                             --
-------------------------------------------------------------------------------------------------

GameState.OnUnload(Item.ClearCache)

Ext.Osiris.RegisterListener(
    "RequestCanPickup",
    3,
    "after",
    Throttle( -- avoid recursion
        10,
        function(character, object, requestID)
            if GC.IsNonPlayer(character, true) then
                return
            end

            local item = table.find(PersistentVars.SpawnedItems, function(item)
                return U.UUID.Equals(item.GUID, object)
            end)

            if item then
                L.Debug("Auto pickup:", object, character)
                Item.PickupAll(character, item.Rarity, item.Type)
            end
        end
    )
)

Ext.Osiris.RegisterListener("TeleportedToCamp", 1, "after", function(uuid)
    if U.UUID.Equals(uuid, Player.Host()) then
        Item.PickupLoot()
    end
end)
Event.On("ReturnToCamp", Item.PickupLoot)

-- A Scenario object can be reused by Trials of Tav, so reset the per-encounter craft cap
-- on the explicit ScenarioStarted event rather than relying on object identity.
local craftTableValidated = false

Event.On("ScenarioStarted", function(scenario)
    if not craftTableValidated then
        validateCraftTable()
        craftTableValidated = true
    end
    resetCraftState()
    L.Debug("Craft V1.2 reset for encounter; RG", math.max(0, PersistentVars.RogueScore or 0))
end)

Event.On("ScenarioEnemyKilled", function(scenario, enemy)
    local nr = #scenario.KilledEnemies

    local chanceFood = 1
    if nr <= 6 then
        chanceFood = 0.9
    else
        chanceFood = math.max(1, 10 - nr) / 10
    end

    local loot = Item.GenerateSimpleLoot(rolls, chanceFood, scenario.LootRates, scenario)

    -- Independent Craft V1.2 roll: boosts alchemy without reducing the original food chance.
    for _, item in ipairs(Item.TryGenerateCraftLoot(scenario)) do
        table.insert(loot, item)
    end

    local x, y, z = Osi.GetPosition(enemy.GUID)

    Item.SpawnLoot(loot, x, y, z)
end)

Event.On(
    "ScenarioEnded",
    Async.Wrap(function(scenario)
        Player.Notify(__("Dropping loot."), true)

        local rolls = math.floor(scenario:KillScore())
        local chunkSize = 20

        local map = scenario.Map
        local x, y, z = map.Enter[1], map.Enter[2], map.Enter[3]
        if Config.SpawnItemsAtPlayer then
            x, y, z = Player.Pos()
        end

        Async.Interval(40, function(self)
            if rolls <= 0 then
                self:Clear()
                return
            end

            local currentChunk = math.min(chunkSize, rolls)
            rolls = rolls - currentChunk

            local loot = Item.GenerateLoot(currentChunk, scenario.LootRates, true)
            L.Dump("Loot Chunk", loot, scenario.LootRates, currentChunk, #loot)
            Item.SpawnLoot(loot, x, y, z, true)
        end)
    end)
)




-- TOT halo aura support (Developer Mace + Dawn Crown)
local TOT_HALO_UNDEAD_TAG = "33c625aa-6982-4c27-904f-e47029a9b140" -- UNDEAD

local function TotHasHaloPassive(uuid)
    return Osi.HasPassive(uuid, "TOT_DEV_MACE_HALO") == 1 or Osi.HasPassive(uuid, "TOT_DAWN_HALO") == 1
end

local function TotIsFiendLikeTemplate(template)
    template = string.lower(template or "")
    return string.find(template, "fiend", 1, true)
        or string.find(template, "cambion", 1, true)
        or string.find(template, "orthon", 1, true)
        or string.find(template, "merregon", 1, true)
        or string.find(template, "devil", 1, true)
        or string.find(template, "imp", 1, true)
        or string.find(template, "quasit", 1, true)
end

local function TotIsHaloTarget(uuid)
    if Osi.IsTagged(uuid, TOT_HALO_UNDEAD_TAG) == 1 then
        return true
    end
    return TotIsFiendLikeTemplate(Osi.GetTemplate(uuid) or "")
end

local function TotNearbyHaloSource(target)
    for _, entity in pairs(GU.Entity.GetParty()) do
        local source = entity.Uuid and entity.Uuid.EntityUuid
        if source
            and Osi.IsDead(source) ~= 1
            and Osi.IsInCombat(source) == 1
            and TotHasHaloPassive(source)
            and Osi.IsEnemy(source, target) == 1
        then
            local d = Osi.GetDistanceTo(source, target)
            if d and d <= 6 then
                return source
            end
        end
    end
end

Ext.Osiris.RegisterListener("TurnStarted", 1, "after", function(character)
    if Osi.IsDead(character) == 1 or Osi.IsInCombat(character) ~= 1 then
        return
    end
    if not TotIsHaloTarget(character) then
        return
    end
    if Osi.HasAppliedStatus(character, "TOT_HALO_CREATOR_IMMUNITY") == 1 then
        return
    end

    local source = TotNearbyHaloSource(character)
    if source then
        Osi.ApplyStatus(character, "TOT_HALO_CREATOR_CHECK", 1, 1, source)
    end
end)


-- ============================================================================
-- V7.4 validated equipment / Unlock mechanics
-- ============================================================================

local function TotHealDirect(target, amount)
    local entity = Ext.Entity.Get(target)
    if not entity or not entity.Health or amount <= 0 then return end
    local hp = entity.Health.Hp or 0
    local maxHp = entity.Health.MaxHp or hp
    entity.Health.Hp = math.min(maxHp, hp + math.floor(amount))
    entity:Replicate("Health")
end

-- Coiffe du Virtuose: trigger off any condition using Bardic Inspiration's stack id.
Ext.Osiris.RegisterListener("StatusApplied", 4, "after", function(target, status, causee, storyActionID)
    if not causee or Osi.IsCharacter(causee) ~= 1 or Osi.HasPassive(causee, "TOT_BARD_CAP_MARKER") ~= 1 then return end
    local st = Ext.Stats.Get(status)
    if not st or st.StackId ~= "BARDIC_INSPIRATION" then return end
    local cha = Osi.GetAbility(causee, "Charisma") or 10
    local mod = math.floor((cha - 10) / 2)
    TotHealDirect(target, math.random(1,6) + math.max(0, mod))
    Osi.ApplyStatus(target, "TOT_BARD_CAP_MOVEMENT", 1, 1, causee)
end)
