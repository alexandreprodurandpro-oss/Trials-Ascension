CantripAction = CantripAction or {}

-- Characters can technically be in separate combats in co-op. Track active turns
-- per character instead of relying on a single global current-turn GUID.
local activeTurns = {}

local CLASS_UUIDS = {
    ["a865965f-501b-46e9-9eaa-7748e8c04d09"] = true, -- Wizard
    ["114e7aee-d1d4-4371-8d90-8a2080592faf"] = true, -- Cleric
    ["457d0a6e-9da8-4f95-a225-18382f0e94b5"] = true, -- Druid
    ["784001e2-c96d-4153-beb6-2adbef5abc92"] = true, -- Sorcerer
    ["b4225a4b-4bbe-4d97-9e3c-4719dbd1487c"] = true, -- Warlock
}

local function eligibleLevel(character)
    local entity = Ext.Entity.Get(character)
    local classes = entity and entity.Classes and entity.Classes.Classes
    if not classes then return 0 end
    local best = 0
    for _, cls in pairs(classes) do
        if cls and CLASS_UUIDS[tostring(cls.ClassUUID)] then
            best = math.max(best, tonumber(cls.Level) or 0)
        end
    end
    return best
end

-- Keep this idempotent. Removing/re-adding the correct passive could refill the
-- custom resource during the turn and accidentally grant extra free cantrips.
local function updateCharacter(character)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 then return end

    local level = eligibleLevel(character)
    local hasL8 = Osi.HasPassive(character, "TOT_CANTRIP_ACTION_L8") == 1
    local hasL16 = Osi.HasPassive(character, "TOT_CANTRIP_ACTION_L16") == 1

    if level >= 16 then
        if hasL8 then Osi.RemovePassive(character, "TOT_CANTRIP_ACTION_L8") end
        if not hasL16 then Osi.AddPassive(character, "TOT_CANTRIP_ACTION_L16") end
    elseif level >= 8 then
        if hasL16 then Osi.RemovePassive(character, "TOT_CANTRIP_ACTION_L16") end
        if not hasL8 then Osi.AddPassive(character, "TOT_CANTRIP_ACTION_L8") end
    else
        if hasL8 then Osi.RemovePassive(character, "TOT_CANTRIP_ACTION_L8") end
        if hasL16 then Osi.RemovePassive(character, "TOT_CANTRIP_ACTION_L16") end
    end
end

local function refreshParty()
    for _, character in pairs(GU.DB.GetPlayers()) do updateCharacter(character) end
end

Ext.Osiris.RegisterListener("CastSpell", 5, "after", function(caster, spell, spellType, spellElement, storyActionID)
    if not caster or caster == "" or Osi.IsCharacter(caster) ~= 1 then return end
    if Osi.IsInCombat(caster) ~= 1 then return end

    -- Only a spell cast during this character's own combat turn can arm the resource.
    if not activeTurns[caster] then return end

    local levelEligible = eligibleLevel(caster)
    if levelEligible < 8 then return end

    -- Ensure companions/origins such as Shadowheart have the level passive even if
    -- the party DB was not ready when the save initially loaded.
    updateCharacter(caster)

    local stat = Ext.Stats.Get(spell)
    if not stat then return end

    -- Arm only after a real levelled spell. Most spells expose Level directly;
    -- derived/upcast entries can inherit it from their root/Using stat.
    local level = tonumber(stat.Level)
    local parent = stat.Using
    local guard = 0
    while (not level or level <= 0) and parent and parent ~= "" and guard < 4 do
        local parentStat = Ext.Stats.Get(parent)
        if not parentStat then break end
        level = tonumber(parentStat.Level)
        parent = parentStat.Using
        guard = guard + 1
    end
    if not level or level <= 0 then return end

    Osi.ApplyStatus(caster, "TOT_CANTRIP_ACTION_READY", -1, 1, caster)
end)

Ext.Osiris.RegisterListener("TurnStarted", 1, "before", function(character)
    activeTurns[character] = true
    updateCharacter(character)
    if Osi.HasAppliedStatus(character, "TOT_CANTRIP_ACTION_READY") == 1 then
        Osi.RemoveStatus(character, "TOT_CANTRIP_ACTION_READY")
    end
end)

Ext.Osiris.RegisterListener("TurnEnded", 1, "after", function(character)
    activeTurns[character] = nil
    if Osi.HasAppliedStatus(character, "TOT_CANTRIP_ACTION_READY") == 1 then
        Osi.RemoveStatus(character, "TOT_CANTRIP_ACTION_READY")
    end
end)

Ext.Osiris.RegisterListener("LeveledUp", 1, "after", function(character)
    Defer(250, function() updateCharacter(character) end)
end)

Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character)
    Defer(250, function() updateCharacter(character) end)
end)

Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", refreshParty)
GameState.OnLoad(function() Defer(750, refreshParty) end, true)
