function SyncState(peerId)
    -- UI-only fields; do not persist or feed them back into gameplay.
    local state = table.deepclone(PersistentVars)
    state.PlayerLevel = Player.Level() or 1

    -- Read-only Ascension grade sourced from the same tier table used by the generator.
    local regionalStage = Player.GetRegionalStage(state.RogueScore or 0)
    state.RegionalStage = regionalStage and regionalStage.Id or 1
    state.RegionalStageName = regionalStage and regionalStage.Name or "Acte 1"
    state.RegionalStageMinRG = regionalStage and regionalStage.MinRG or 0
    state.RegionalStageMaxRG = regionalStage and regionalStage.MaxRG or nil

    state.AscensionTier = 1
    if GameMode and GameMode.GetTiers then
        local score = state.RogueScore or 0
        local tiers = GameMode.GetTiers(false, false, score)
        for _, tier in ipairs(tiers or {}) do
            local tierIndex = 1
            for i, tierName in ipairs(C.EnemyTier or {}) do
                if tier.name == tierName then tierIndex = i break end
            end
            -- "avatar" is intentionally unused; apex/Dieu is player-facing Palier 9.
            if tier.name == "apex" then tierIndex = 9 end
            if tierIndex <= state.PlayerLevel and score >= (tier.min or tier.value or 0) then
                state.AscensionTier = math.max(state.AscensionTier, tierIndex)
            end
        end
    end
    Net.Send(
        "SyncState",
        table.filter(state, function(v, k)
            if k == "SpawnedEnemies" and table.size(v) > 30 then
                return false
            end
            return true
        end, true),
        nil,
        peerId
    )
end

Net.On("SyncState", function(event)
    SyncState(event.PeerId)
end)

Net.On("IsHost", function(event)
    Net.Respond(event, event:IsHost())
end)

Net.On("GUIReady", function(event)
    if PersistentVars.GUIOpen then
        Net.Send("OpenGUI")
    end
end)

Net.On("GetSelection", function(event)
    Net.Respond(event, {
        Scenarios = table.map(Scenario.GetTemplates(), function(v, k)
            if PersistentVars.RogueModeActive and not v.RogueLike then
                return nil
            end
            return { Id = k, Name = v.Name }
        end),
		
		
        Maps = table.map(Map.GetTemplates(), function(v, k)
            return { Id = k, Name = v.Name, Author = v.Author }
        end),
    })
end)

Net.On("GetTemplates", function(event)
    Net.Respond(event, {
        Scenarios = Scenario.GetTemplates(),
        Maps = Map.GetTemplates(),
        -- Enemies = Enemy.GetTemplates(),
    })
end)

Net.On("ResetTemplates", function(event)
    if event.Payload.Scenarios then
        Templates.ExportScenarios()
    end
    if event.Payload.Maps then
        Templates.ExportMaps()
    end
    local exandriaCheck = Ext.Mod.IsModLoaded("a27fdbe3-4d1a-641d-d05f-1ba4ee529da8")

    if event.Payload.Enemies then
        if PersistentVars.LoneWolfMode and exandriaCheck then
            Templates.ExportExandriaSoloModeEnemies()
        elseif exandriaCheck then
            Templates.ExportExandriaModeEnemies()
        elseif PersistentVars.LoneWolfMode then
            Templates.ExportSoloModeEnemies()
        else
            Templates.ExportEnemies()
        end

        if Enemy and Enemy.ClearTemplateCache then
            Enemy.ClearTemplateCache()
        end
    end
    if event.Payload.LootRates then
        Templates.ExportLootRates()
    end

    Net.Respond(event, { true })
end)

Net.On("GetEnemies", function(event)
    local tier = event.Payload and event.Payload.Tier

    local grouped = {}
    for _, v in ipairs(Enemy.GetTemplates()) do
        if not tier or v.Tier == tier then
            if not grouped[v.Tier] then
                grouped[v.Tier] = {}
            end
            table.insert(grouped[v.Tier], v)
        end
    end

    Net.Respond(event, grouped)
end)

Net.On("GetItems", function(event)
    local rarity = event.Payload and event.Payload.Rarity
    Net.Respond(event, {
        Objects = Item.Objects(rarity, false),
        CombatObjects = Item.Objects(rarity, true),
        Armor = Item.Armor(rarity),
        Weapons = Item.Weapons(rarity),
    })
end)

local broadcastState

local function setRunStartRogueScoreExact(score)
    local target = math.max(0, math.floor(tonumber(score) or 0))
    local previous = PersistentVars.RogueScore or 0
    if previous == target then return end
    PersistentVars.RogueScore = target
    Event.Trigger("RogueScoreChanged", previous, target)
    Defer(1000, function()
        Player.Notify(__("Your RogueScore changed: %d -> %d!", previous, target))
    end)
end

Net.On("SetRunProgressionMode", function(event)
    if not event:IsHost() then
        Net.Respond(event, { false, TA_Text("Only the host can choose the run mode.", "Seul l'hôte peut choisir le mode de partie.") })
        return
    end

    if not PersistentVars.RogueModeActive then
        Net.Respond(event, { false, TA_Text("Run progression modes are available only in Roguelike mode.", "Le mode de partie rapide est disponible uniquement en Roguelike.") })
        return
    end

    if PersistentVars.RunProgressionLocked then
        Net.Respond(event, { false, TA_Text("The progression mode is already locked for this run.", "Le mode de progression est déjà verrouillé pour cette run.") })
        return
    end

    local scenario = PersistentVars.Scenario
    local alreadyStarted = Player.InCombat()
        or (scenario and ((tonumber(scenario.Round) or 0) > 0 or #(scenario.SpawnedEnemies or {}) > 0))
    if alreadyStarted then
        Net.Respond(event, { false, TA_Text("The mode must be chosen before the first combat of the run.", "Le mode doit être choisi avant le premier combat de la run.") })
        return
    end

    local payload = event.Payload or {}
    local mode = payload.Mode
    if mode ~= RunMode.CLASSIC and mode ~= RunMode.ACCELERATED and mode ~= RunMode.EXPRESS then
        Net.Respond(event, { false, TA_Text("Invalid progression mode.", "Mode de progression invalide.") })
        return
    end

    PersistentVars.RunProgressionMode = mode
    PersistentVars.RunProgressionLocked = true

    if mode == RunMode.ACCELERATED then
        -- Accélérée: RG25 + 150 Ascension Shards on the first selection only.
        -- If Z15 lost only the mode string on a death/reload, allow re-selection
        -- without lowering an already progressed RogueScore or granting the bonus twice.
        if not PersistentVars.RunProgressionInitialBonusGranted then
            setRunStartRogueScoreExact(25)
            Unlock.UpdateCurrency((PersistentVars.Currency or 0) + 150)
            PersistentVars.RunProgressionInitialBonusGranted = true
        elseif (PersistentVars.RogueScore or 0) < 25 then
            setRunStartRogueScoreExact(25)
        end
    elseif mode == RunMode.EXPRESS then
        -- Express: RG50 + 300 Ascension Shards on the first selection only.
        if not PersistentVars.RunProgressionInitialBonusGranted then
            setRunStartRogueScoreExact(50)
            Unlock.UpdateCurrency((PersistentVars.Currency or 0) + 300)
            PersistentVars.RunProgressionInitialBonusGranted = true
        elseif (PersistentVars.RogueScore or 0) < 50 then
            setRunStartRogueScoreExact(50)
        end
    end

    Event.Trigger("RunProgressionModeChanged", mode)
    if broadcastState then broadcastState() end

    local label = TA_Text("Classic", "Classique")
    if mode == RunMode.ACCELERATED then label = TA_Text("Accelerated", "Accélérée")
    elseif mode == RunMode.EXPRESS then label = "Express" end
    Net.Respond(event, { true, TA_Text("Mode " .. label .. " selected and locked for this run.", "Mode " .. label .. " sélectionné et verrouillé pour cette run.") })
end)

Net.On("Start", function(event)
    local scenarioName = event.Payload.Scenario
    local mapName = event.Payload.Map
    local difficultyValue = event.Payload.Difficulty

    local template = table.find(Scenario.GetTemplates(), function(v)
        return v.Name == scenarioName
    end)

    local map = table.find(Map.Get(), function(v)
        return v.Name == mapName
    end)

    if template == nil then
        Net.Respond(event, { false, TA_Text("Scenario error", "Erreur de scénario") })
        return
    end
    if mapName and map == nil then
        Net.Respond(event, { false, TA_Text("Map error", "Erreur de carte") })
        return
    end

    if PersistentVars.RogueModeActive and not PersistentVars.RunProgressionLocked then
        Net.Respond(event, { false, TA_Text("Choose a run mode first: Classic, Accelerated or Express.", "Choisissez d'abord un mode de partie : Classique, Accélérée ou Express.") })
        return
    end

    -- A Roguelike difficulty choice is a run-level decision. Once the run has
    -- started, reject any late UI/state race that tries to replace Bias or
    -- Challenge/Hell during the post-combat transition.
    if PersistentVars.RunDifficultyLocked then
        Net.Respond(event, { false, TA_Text("Difficulty locked for this run.", "Difficulté verrouillée pour cette partie.") })
        return
    end

    if difficultyValue == 0 then
        PersistentVars.HardMode = false
        PersistentVars.SuperHardMode = false
        Event.Trigger("difficultyModeChanged", true)
    elseif difficultyValue == 1 then
        PersistentVars.HardMode = true
        PersistentVars.SuperHardMode = false
        Event.Trigger("difficultyModeChanged", true)
    elseif difficultyValue == 2 then
        PersistentVars.HardMode = false
        PersistentVars.SuperHardMode = true
        Event.Trigger("difficultyModeChanged", true)
    else
        Net.Respond(event, { false, TA_Text("Scenario error", "Erreur de scénario") })
        return
    end

    if PersistentVars.RogueModeActive then
        PersistentVars.RunDifficultyLocked = true
    end

    Scenario.Start(template, map)
    broadcastState()

    Net.Respond(event, { true, __("Scenario %s started.", TA_DisplayScenarioName(template.Name)) })
end)

Net.On("Stop", function(event)
    local s = Scenario.Current()

    if not s then
        Net.Respond(event, { false, __("Scenario not started.") })
        return
    end

    if s:HasStarted() and not Mod.Debug then
        Net.Respond(event, { false, __("Cannot stop while in progress.") })
        return
    end

    Scenario.Stop()
    Net.Respond(event, { true, __("Scenario stopped.") })
end)

Net.On("BuyUnlock", function(event)
    Net.Respond(event, { Unlock.Buy(event.Payload.Id, event:Character(), event.Payload.Character) })
end)

Net.On("BuyMilestoneReward", function(event)
    Net.Respond(event, { Reward.Buy(event.Payload.Id, event:Character(), event.Payload.Character) })
end)

Net.On("ToCamp", function(event)
    if Player.Region() == C.Regions.Act0 then
        Intro.AskTutSkip()
        Net.Send("CloseGUI")
        return
    end

    if Player.InCombat() and not Mod.Debug then
        Net.Respond(event, { false, __("Cannot teleport while in combat.") })
        return
    end
    Player.ReturnToCamp()

    Net.Respond(event, { true })
end)

Net.On("ForwardCombat", function(event)
    local s = Scenario.Current()

    if not s then
        Net.Respond(event, { false, __("Scenario not started.") })
        return
    end

    Scenario.ForwardCombat()

    Net.Respond(event, { true })
end)

Net.On("Teleport", function(event)
    if Player.Region() == C.Regions.Act0 then
        Intro.AskTutSkip()
        Net.Send("CloseGUI")
        return
    end

    if event.Payload and event.Payload.Restrict and PersistentVars.RogueModeActive and not PersistentVars.RunProgressionLocked then
        Net.Respond(event, { false, TA_Text("Choose a run mode first: Classic, Accelerated or Express.", "Choisissez d'abord un mode de partie : Classique, Accélérée ou Express.") })
        return
    end

    local s = Scenario.Current()
    if s and s.IsCampBattle then
        if event.Payload.Restrict and Player.InCombat() and not Mod.Debug then
            Net.Respond(event, { false, __("Cannot teleport while in combat.") })
            return
        end
        Scenario.Teleport()
        Net.Respond(event, { true })
        return
    end

    local mapName = event.Payload.Map

    local map = table.find(Map.Get(), function(v)
        return v.Name == mapName
    end)

    if map == nil then
        Net.Respond(event, { false, __("Map not found.") })
        return
    end

    if event.Payload.Restrict and Player.InCombat() and not Mod.Debug then
        Net.Respond(event, { false, __("Cannot teleport while in combat.") })
        return
    end

    s = Scenario.Current()

    if s and eq(map, s.Map) then
        Scenario.Teleport(event:Character())
    else
        map:Teleport(event:Character())
    end

    Net.Respond(event, { true })
end)

Net.On("WindowOpened", function(event)
    PersistentVars.GUIOpen = true
    Event.Trigger("ModActive")
    SyncState(event.PeerId)
end)
Net.On("WindowClosed", function(event)
    PersistentVars.GUIOpen = false
end)

Event.On("ScenarioStarted", function()
    Net.Send("OpenGUI", "Optional")
end)
Event.On("ScenarioMapEntered", function()
    Net.Send("CloseGUI", "Optional")
end)

Net.On("KillSpawned", function(event)
    Enemy.KillSpawned()

    Net.Respond(event, { true })
end)

Net.On("Ping", function(event)
    local target = event.Payload.Target
    if target then
        local character = event:Character()
        local x, y, z = Osi.GetPosition(target)
        Osi.RequestPing(x, y, z, target, character)
    end

    local pos = event.Payload.Pos
    if pos then
        Osi.RequestPing(pos[1], pos[2], pos[3], nil, event:Character())
    end

    Net.Respond(event, { true })
end)

Net.On("MarkSpawns", function(event)
    local mapName = event.Payload.Map
    local map = table.find(Map.Get(), function(v)
        return v.Name == mapName
    end)
    if map == nil then
        Net.Respond(event, { false, __("Map not found.") })
        return
    end

    map:VFXSpawns(table.keys(map.Spawns), 72)

    if Scenario.Current() then
        Scenario.MarkSpawns(Scenario.Current().Round + 1, 72)
    end

    Net.Respond(event, { true })
end)

Net.On("PingSpawns", function(event)
    local mapName = event.Payload.Map
    local map = table.find(Map.Get(), function(v)
        return v.Name == mapName
    end)
    if map == nil then
        Net.Respond(event, { false, __("Map not found.") })
        return
    end

    map:PingSpawns()

    Net.Respond(event, { true })
end)

broadcastState = function()
    Schedule(SyncState)
end

local function broadcastConfig()
    Schedule(function()
        local c = table.deepclone(Config)
        c.RoguelikeMode = PersistentVars.RogueModeActive
        c.HardMode = PersistentVars.HardMode
        c.SuperHardMode = PersistentVars.SuperHardMode
        c.LoneWolfMode = PersistentVars.LoneWolfMode
		c.GMMode = PersistentVars.GMMode
        c.Debug = Mod.Debug

        Net.Send("Config", c)
    end)
end

Event.On("RogueModeChanged", broadcastConfig)
Event.On("difficultyModeChanged", broadcastConfig)

Event.On("RogueModeChanged", broadcastState)
Event.On("difficultyModeChanged", broadcastState)
Event.On("ScenarioStarted", broadcastState)
Event.On("ScenarioMapEntered", broadcastState)
Event.On("ScenarioRoundStarted", broadcastState)
Event.On("ScenarioEnemyKilled", broadcastState)
Event.On("ScenarioCombatStarted", broadcastState)
Event.On("ScenarioEnded", broadcastState)
Event.On("ScenarioStopped", broadcastState)
Event.On("RogueScoreChanged", broadcastState)
Event.On("RunProgressionModeChanged", broadcastState)

-- V8.4Z16: RunProgressionMode now uses an empty-string template sentinel instead
-- of nil. Hlib removes PersistentVars keys that are not represented in the template;
-- a nil template entry therefore caused the selected mode to disappear after reload/death
-- while RunProgressionLocked survived, making the UI fall back visually/mechanically to Classic.
GameState.OnLoad(function()
    local mode = PersistentVars.RunProgressionMode
    local validMode = mode == RunMode.CLASSIC or mode == RunMode.ACCELERATED or mode == RunMode.EXPRESS

    if validMode then
        return
    end

    -- Recovery for a Z15 save that already suffered the lost-mode bug: keep all run
    -- progression/bonus state, but unlock only the mode selector so the player can
    -- reselect the intended mode once. SetRunProgressionMode guards against duplicate
    -- starting currency and never lowers RG during this recovery.
    if PersistentVars.RunProgressionLocked then
        PersistentVars.RunProgressionMode = ""
        PersistentVars.RunProgressionLocked = false
        return
    end

    -- Older pre-mode runs already in progress still migrate to Classic rather than
    -- being blocked in the middle of a run.
    local scenario = PersistentVars.Scenario
    local alreadyStarted = (PersistentVars.RogueScore or 0) > 0
        or (scenario and ((tonumber(scenario.Round) or 0) > 0 or #(scenario.SpawnedEnemies or {}) > 0))
    if alreadyStarted then
        PersistentVars.RunProgressionMode = RunMode.CLASSIC
        PersistentVars.RunProgressionLocked = true
    else
        PersistentVars.RunProgressionMode = ""
    end
end, true)

Net.On("Config", function(event)
    if event:IsHost() then
        local config = event.Payload
        if config then
            if config.Default then
                config = DefaultConfig
            end

            External.ApplyConfig(config)

            if config.Persist then
                External.SaveConfig()
            end

            if config.Reset then
                External.LoadConfig()
            end

            if config.RoguelikeMode ~= nil then
                if PersistentVars.RogueModeActive ~= config.RoguelikeMode then
                    PersistentVars.RogueModeActive = config.RoguelikeMode
                    Event.Trigger("RogueModeChanged", PersistentVars.RogueModeActive)
                end
            end

            if config.HardMode ~= nil then
                if PersistentVars.RunDifficultyLocked then
                    Player.Notify(TA_Text("Difficulty locked for this run.", "Difficulté verrouillée pour cette partie."))
                    broadcastConfig()
                else
                    PersistentVars.HardMode = config.HardMode
                    if PersistentVars.HardMode == true then
                        config.SuperHardMode = false
                        PersistentVars.SuperHardMode = config.SuperHardMode
                    end
                    broadcastState()
                end
            end

            if config.SuperHardMode ~= nil then
                if PersistentVars.RunDifficultyLocked then
                    Player.Notify(TA_Text("Difficulty locked for this run.", "Difficulté verrouillée pour cette partie."))
                    broadcastConfig()
                else
                    PersistentVars.SuperHardMode = config.SuperHardMode
                    if PersistentVars.SuperHardMode == true then
                        config.HardMode = false
                        PersistentVars.HardMode = config.HardMode
                    end
                    broadcastState()
                end
            end

            if config.LoneWolfMode ~= nil then
                PersistentVars.LoneWolfMode = config.LoneWolfMode
				if PersistentVars.LoneWolfMode == true then
                    config.GMMode = false
                    PersistentVars.GMMode = config.GMMode
                end
                broadcastState()
			end
			
			if config.GMMode ~= nil then
				PersistentVars.GMMode = config.GMMode
				PersistentVars.GameMaster = Player.Host()
				if PersistentVars.GMMode == true then
					Player.Notify(__("%s is now the game master.", Osi.ResolveTranslatedString(Osi.GetDisplayName(PersistentVars.GameMaster))))
                    config.LoneWolfMode = false
                    PersistentVars.LoneWolfMode = config.LoneWolfMode
                end
                broadcastState()
            end
        end
    end

    broadcastConfig()
end)

Net.On("KillNearby", function(event)
    StoryBypass.ClearArea(event:Character())
end)

Net.On("ClearSurfaces", function(event)
    local s = Scenario.Current()
    if s then
        for i, guid in pairs(s.Map.Helpers) do
            WaitTicks(i, function()
                StoryBypass.ClearSurfaces(guid)
            end)
        end
    else
        StoryBypass.ClearSurfaces(event:Character())
    end

    Net.Respond(event, { true })
end)

Net.On("RemoveAllEntities", function(event)
    local count = #StoryBypass.RemoveAllEntities()
    Net.Respond(event, { true, string.format(TA_Text("Removing %d entities.", "Suppression de %d entités."), count) })
end)

Net.On("RecruitOrigin", function(event)
    local name = event.Payload
    local char = table.find(C.OriginCharacters, function(v, k)
        return k == name
    end)
    if char then
        Player.RecruitOrigin(name)
        Net.Respond(event, { true, __("Recruiting %s.", name) })
    else
        Net.Respond(event, { false, string.format("Origin %s not found.", name) })
    end
end)

Net.On("FixFactions", function(event)
    if Player.InCombat() then
        Net.Respond(event, { false, __("Cannot change factions while in combat.") })
    else
        for _, player in pairs(GU.DB.GetPlayers()) do
            Osi.SetFaction(player, C.CompanionFaction)
        end
        Net.Respond(event, { true })
    end
end)

Net.On("FixLongRest", function(event)
    if Player.InCombat() then
        Net.Respond(event, { false, __("Cannot use this function while in combat.") })
    else
        Osi.DB_Camp_Unlocked(1)
        Osi.SetLongRestAvailable(1)
        Osi.SetJoinBlock(0)
        for _, player in pairs(GU.DB.GetPlayers()) do
            Osi.SetIsInDangerZone(player, 0)
            Osi.PROC_SetBlockDismiss(player, 0)
            Osi.DB_InDangerZone:Delete(player, "ENDGAME")
        end
		Osi.DB_INT_EmperorRevealed_WeakToAbsolute:Delete(1)
        Net.Respond(event, { true })
    end
end)

Net.On("CancelLongRest", function(event)
    StoryBypass.EndLongRest()
    Net.Respond(event, { true })
end)

Net.On("CancelDialog", function(event)
    local dialog, instance = Osi.SpeakerGetDialog(event:Character(), 1)

    if dialog then
        StoryBypass.CancelDialog(dialog, instance)
        Net.Respond(event, { true, string.format(TA_Text("Dialog %s cancelled.", "Dialogue %s annulé."), dialog) })
    else
        Net.Respond(event, { false, TA_Text("No dialog found.", "Aucun dialogue trouvé.") })
    end
end)

Net.On("UpdateLootFilter", function(event)
    local rarity, type, bool = table.unpack(event.Payload)
    PersistentVars.LootFilter[type][rarity] = bool

    broadcastState()
    Net.Respond(event, { true, __("Loot filter updated") })
end)

Net.On("PickupAll", function(event)
    local count = 0
    for _, rarity in pairs(C.ItemRarity) do
        count = count + Item.PickupAll(event:Character())
    end

    Net.Respond(event, { true, __("Picked up %d items.", count) })
end)

Net.On("Pickup", function(event)
    local rarity, type = table.unpack(event.Payload)
    local count = Item.PickupAll(event:Character(), rarity, type)

    Net.Respond(event, { true, __("Picked up %d items.", count) })
end)

Net.On("DestroyAll", function(event)
    local count = 0
    for _, rarity in pairs(C.ItemRarity) do
        count = count + Item.DestroyAll(rarity)
    end

    Net.Respond(event, { true, __("Destroyed %d items.", count) })
end)

Net.On("DestroyLoot", function(event)
    local rarity, type = table.unpack(event.Payload)
    local count = Item.DestroyAll(rarity, type)

    Net.Respond(event, { true, __("Destroyed %d items.", count) })
end)

Net.On("GetFilterableModList", function(event)
    local list = {}

    local function t(modId, modName)
        return { Id = modId, Name = modName, Blacklist = false }
    end
    for modId, modName in pairs(Item.GetModList()) do
        if not string.contains(modName, { "Gustav", "GustavDev", "Shared", "SharedDev", "Honour" }) then
            list[modId] = t(modId, modName)
        end
    end

    local filters = External.Templates.GetItemFilters()
    for _, modId in pairs(filters.Mods) do
        if not list[modId] then
            local name = "Not loaded"
            if Ext.Mod.GetMod(modId) then
                name = Ext.Mod.GetMod(modId).Info.Directory
            end

            list[modId] = t(modId, name)
        end

        list[modId].Blacklist = true
    end

    Net.Respond(event, list)
end)

Net.On("UpdateModFilter", function(event)
    local modId, bool = table.unpack(event.Payload)
    local filters = External.Templates.GetItemFilters(true)

    if bool then
        table.insert(filters.Mods, modId)
    else
        table.removevalue(filters.Mods, modId)
    end

    External.File.Export("ItemFilters", filters)

    Item.ClearCache()

    Net.Respond(event, { true, TA_Text("Mod filter updated", "Filtre de mods mis à jour") })
end)

-- V7.2 test utilities ----------------------------------------------------------
Net.On("ClaimDivineContract", function(event)
    local id = event.Payload and event.Payload.Id
    Contracts.ClaimDivine(id, event:Character())
    SyncState()
end)

Net.On("DebugContract", function(event)
    local p = event.Payload or {}
    Contracts.DebugAdd(p.Kind, tonumber(p.Amount) or 0)
    Net.Respond(event, { true })
end)

Net.On("DebugResetContracts", function(event)
    Contracts.ResetDebug()
    Net.Respond(event, { true })
end)

Net.On("DebugResetRewardPurchases", function(event)
    Reward.ResetPurchasesForDebug()
    Net.Respond(event, { true })
end)

Net.On("DebugStartMilestone", function(event)
    local ok, msg = GameMode.DebugStartMilestone(tonumber(event.Payload and event.Payload.RG))
    Net.Respond(event, { ok, msg })
end)

Net.On("DebugCompleteMilestones", function(event)
    local ok, msg = GameMode.DebugCompleteMilestones()
    broadcastState()
    Net.Respond(event, { ok, msg })
end)


-- V8.4A Défense du camp -----------------------------------------------------------
local function rebuildPreparedEncounter()
    return GameMode.RebuildPreparedEncounter()
end

Net.On("GetCampList", function(event)
    local active = Player.ActiveCampId()
    local stage = Player.GetRegionalStage()
    local source = PersistentVars.RegionalProgressionEnabled
        and Player.GetRegionalCamps()
        or Player.GetAvailableCamps()

    if PersistentVars.RegionalProgressionEnabled then
        Player.ClearInvalidRegionalCamp()
        Player.SelectRegionalCamp()
    end

    local result = {}
    for _, camp in ipairs(source) do
        table.insert(result, {
            Id = camp.Id,
            Regions = camp.Regions or {},
            Active = camp.Id == active,
            Locked = camp.Id == PersistentVars.LockedCampId,
        })
    end

    Net.Respond(event, {
        Camps = result,
        Active = active,
        Locked = PersistentVars.LockedCampId,
        RegionalEnabled = PersistentVars.RegionalProgressionEnabled == true,
        StageName = stage and stage.Name or nil,
        StageMinRG = stage and stage.MinRG or nil,
        StageMaxRG = stage and stage.MaxRG or nil,
    })
end)

Net.On("SetLockedCamp", function(event)
    if Player.InCombat() then
        Net.Respond(event, { false, TA_Text("You cannot change camp during combat.", "Impossible de changer de camp pendant un combat.") })
        return
    end

    local campId = event.Payload and event.Payload.Id or nil
    if campId == "" then campId = nil end

    if campId and not Player.IsValidCampId(campId) then
        Net.Respond(event, { false, TA_Text("Invalid camp or unavailable in this save.", "Camp invalide ou indisponible dans cette sauvegarde.") })
        return
    end

    if PersistentVars.RegionalProgressionEnabled
        and campId
        and not Player.IsCampIdAllowedByRegionalProgression(campId)
    then
        local stage = Player.GetRegionalStage()
        Net.Respond(event, {
            false,
            TA_Text("Camp locked by Regional Progression: ", "Camp verrouillé par la progression régionale : ") .. tostring(stage and stage.Name or TA_Text("current region", "région actuelle")) .. "."
        })
        return
    end

    if PersistentVars.RegionalProgressionEnabled and not campId then
        -- "Automatique" means automatic INSIDE the currently unlocked act.
        PersistentVars.LockedCampId = nil
        campId = Player.SelectRegionalCamp()
    end

    local s = Scenario.Current()
    if s and not s:HasStarted() and s.Name == PersistentVars.RogueScenario then
        Scenario.Stop()
    end

    PersistentVars.LockedCampId = campId
    Player.ApplyCampOverride(campId)

    if campId and PersistentVars.RogueModeActive then
        Player.TeleportToSpecificCamp(campId, true)
        -- Camp->camp moves may emit TeleportToFromCamp rather than TeleportedToCamp.
        -- Ensure the normal encounter is still prepared even if Story doesn't emit
        -- the host TeleportedToCamp event.
        Defer(1800, function()
            if PersistentVars.RogueModeActive and not Scenario.Current() and not Player.InCombat() then
                GameMode.StartNext()
            end
            broadcastState()
        end)
    else
        if PersistentVars.RogueModeActive and not Scenario.Current() then
            GameMode.StartNext()
        end
        broadcastState()
    end

    Net.Respond(event, { true, campId and (TA_Text("Camp locked: ", "Camp verrouillé : ") .. campId) or TA_Text("Automatic camp re-enabled.", "Camp automatique réactivé.") })
end)

Net.On("SetRegionalProgressionEnabled", function(event)
    if Player.InCombat() then
        Net.Respond(event, { false, TA_Text("Regional Progression cannot be changed during combat.", "Impossible de modifier la Progression régionale pendant un combat.") })
        return
    end

    if not Player.InCamp() then
        Net.Respond(event, { false, TA_Text("Regional Progression can only be configured from camp.", "La Progression régionale se configure depuis le camp.") })
        return
    end

    local previous = PersistentVars.RegionalProgressionEnabled == true
    local requested = event.Payload and event.Payload.Value == true
    PersistentVars.RegionalProgressionEnabled = requested

    if requested then
        Player.ClearInvalidRegionalCamp()
        Player.SelectRegionalCamp()
    end

    local ok, rebuildError = rebuildPreparedEncounter()
    if not ok then
        PersistentVars.RegionalProgressionEnabled = previous
        if previous then
            Player.ClearInvalidRegionalCamp()
            Player.SelectRegionalCamp()
        end
        GameMode.RebuildPreparedEncounter()
        broadcastState()
        Net.Respond(event, { false, rebuildError or TA_Text("Unable to rebuild the next encounter.", "Impossible de reconstruire la prochaine rencontre.") })
        return
    end

    broadcastState()

    local stage = Player.GetRegionalStage()
    Net.Respond(event, {
        true,
        requested
            and (TA_Text("Regional Progression enabled: ", "Progression régionale activée : ") .. tostring(stage and stage.Name or TA_Text("current region", "région actuelle")) .. ".")
            or TA_Text("Regional Progression disabled: historical map selection restored.", "Progression régionale désactivée : sélection de cartes historique réactivée.")
    })
end)

Net.On("CampBattleCleanup", function(event)
    local s = Scenario.Current()
    if Player.InCombat() or (s and s:HasStarted()) then
        Net.Respond(event, { false, TA_Text("Cleanup is unavailable during an active combat.", "Nettoyage indisponible pendant un combat actif.") })
        return
    end

    Enemy.Cleanup()
    Net.Respond(event, { true, TA_Text("Trials Ascension generated enemies and corpses cleaned up.", "Ennemis et cadavres générés par Trials Ascension nettoyés.") })
end)

Net.On("SetSummonsAutomatic", function(event)
    SummonControl.SetAutomatic(event.Payload and event.Payload.Value == true)
    Net.Respond(event, { true })
end)


local function SpawnV73CustomItem(statName, rootTemplate, nameKey, nameHandle, descHandle)
    local character=Player.Host()
    local template=Ext.Template.GetRootTemplate(rootTemplate)
    if not template then return nil end
    local originalStat=template.Stats
    local x,y,z=Osi.GetPosition(character)

    -- Do not leave a shared vanilla RootTemplate redirected to custom Stats.
    Event.Trigger("TemplateOverwrite",rootTemplate,"Stats",statName)
    local ok,guid=pcall(Osi.CreateAt,rootTemplate,x+1.0,y,z,0,1,"")
    Event.Trigger("TemplateOverwrite",rootTemplate,"Stats",originalStat)
    Defer(100,function() Event.Trigger("TemplateOverwrite",rootTemplate,"Stats",originalStat) end)
    if not ok then guid=nil end

    if guid and guid~="" then
        local e=Ext.Entity.Get(guid); local si=e and e.ServerItem
        if si and si.CreateCacheTemplate then
            local c=si:CreateCacheTemplate()
            if c then
                c.Stats=statName
                if c.DisplayName and c.DisplayName.Handle then c.DisplayName.Handle.Handle=nameHandle end
                if c.Description and c.Description.Handle then c.Description.Handle.Handle=descHandle end
            end
        end
        if Ext.Loca and Ext.Loca.UpdateTranslatedStringKey then Ext.Loca.UpdateTranslatedStringKey(nameKey,nameHandle); Osi.SetStoryDisplayName(guid,nameKey) end
        Osi.ToInventory(guid,character)
    end
    return guid
end

Net.On("DebugSpawnDevMace", function(event)
    local g=SpawnV73CustomItem("TOT_DEV_MACE","b408f445-c150-5284-a980-361249dc3b64","TOT_DEV_MACE_NAME","h73a00000000000000000000000002041","h73a00000000000000000000000002042")
    Net.Respond(event,{g~=nil,g})
end)



-- V7.4K Conqueror prototype: safe test-only kit spawner.
local CONQUEROR_TEST_ITEMS = {
    {"TOT_CONQ_HELMET","8eef2dfe-bfcc-5cfa-a60f-9fe89dd67716","TOT_CONQ_HELMET_NAME","h74k00000000000000000000000000101","h74k00000000000000000000000000102"},
    {"TOT_CONQ_ARMOR","7a5d768d-3bcf-57e5-8733-b7b35be6c87f","TOT_CONQ_ARMOR_NAME","h74k00000000000000000000000000111","h74k00000000000000000000000000112"},
    {"TOT_CONQ_GLOVES","0f90b44b-7e5f-519c-9e87-3dd53daed4fa","TOT_CONQ_GLOVES_NAME","h74k00000000000000000000000000121","h74k00000000000000000000000000122"},
    {"TOT_CONQ_RING","3aca14f5-0476-56ff-806d-6565ccf51117","TOT_CONQ_RING_NAME","h74k00000000000000000000000000151","h74k00000000000000000000000000152"},
    {"TOT_CONQ_BLADE","b9a508ed-661e-5c29-a75f-a1bfb68b9d62","TOT_CONQ_BLADE_NAME","h74k00000000000000000000000000161","h74k00000000000000000000000000162"},
    {"TOT_CONQ_AMULET","9875f590-c985-57e0-a358-8f79bc8059f9","TOT_CONQ_AMULET_NAME","h74k00000000000000000000000000171","h74k00000000000000000000000000172"},
}

local function SpawnConquerorTestItem(character, def)
    local statName, rootTemplate, nameKey, nameHandle, descHandle = table.unpack(def)
    local template = Ext.Template.GetRootTemplate(rootTemplate)
    if not template then return nil, "Missing dedicated RootTemplate: "..rootTemplate end
    local x,y,z = Osi.GetPosition(character)
    local ok, guid = pcall(Osi.CreateAt, rootTemplate, x, y, z, 0, 1, "")
    if not ok or not guid or guid == "" then return nil, tostring(guid) end
    if Ext.Loca and Ext.Loca.UpdateTranslatedStringKey then
        Ext.Loca.UpdateTranslatedStringKey(nameKey,nameHandle)
        Osi.SetStoryDisplayName(guid,nameKey)
    end
    Osi.ToInventory(guid,character)
    return guid
end

Net.On("DebugSpawnConquerorSet", function(event)
    local character=Player.Host()
    local count=0
    local errors={}
    for _,def in ipairs(CONQUEROR_TEST_ITEMS) do
        local guid,err=SpawnConquerorTestItem(character,def)
        if guid then count=count+1 else table.insert(errors,err or def[1]) end
    end
    Net.Respond(event,{count==#CONQUEROR_TEST_ITEMS,string.format(TA_Text("Conqueror Set TEST: %d/%d pieces added%s", "Kit du Conquérant TEST : %d/%d pièces ajoutées%s"),count,#CONQUEROR_TEST_ITEMS,#errors>0 and (" | "..table.concat(errors,"; ")) or "")})
end)

-- V7.5G Sun God set test kit. Uses the same RootTemplate-safe spawn pattern as
-- the validated Conqueror test kit and restores every vanilla template immediately.
local SUN_GOD_TEST_ITEMS = {
    {"TOT_SUN_GOD_SCIMITAR","4b094fdc-d3f1-5f77-a6e4-afb513999557","TOT_SUN_GOD_SCIMITAR_NAME","h74i00000000000000000000000000101","h74i00000000000000000000000000102"},
    {"TOT_SUN_GOD_CAPE","45d29e39-e5cb-5000-8cf2-a62a02590a2b","TOT_SUN_GOD_CAPE_NAME","h74i00000000000000000000000000111","h74i00000000000000000000000000112"},
    {"TOT_SUN_GOD_TUNIC","a1eb4411-a3e9-51e6-9cec-20cfd0dee0ce","TOT_SUN_GOD_TUNIC_NAME","h75g00000000000000000000000000101","h75g00000000000000000000000000102"},
    {"TOT_SUN_GOD_GLOVES","744bab7b-676b-513d-97d9-fddfc80a4eb1","TOT_SUN_GOD_GLOVES_NAME","h75g00000000000000000000000000111","h75g00000000000000000000000000112"},
    {"TOT_SUN_GOD_BOOTS","aaf2d61b-fa42-51ad-bed7-36a1fa5632d1","TOT_SUN_GOD_BOOTS_NAME","h75g00000000000000000000000000121","h75g00000000000000000000000000122"},
    {"TOT_SUN_GOD_RING","d3bc97eb-9344-51dd-a3fa-c3486095321b","TOT_SUN_GOD_RING_NAME","h75g00000000000000000000000000131","h75g00000000000000000000000000132"},
}

Net.On("DebugSpawnSunGodSet", function(event)
    local character=Player.Host()
    local count=0
    local errors={}
    for _,def in ipairs(SUN_GOD_TEST_ITEMS) do
        local guid,err=SpawnConquerorTestItem(character,def)
        if guid then count=count+1 else table.insert(errors,err or def[1]) end
    end
    Net.Respond(event,{count==#SUN_GOD_TEST_ITEMS,string.format(TA_Text("Sun God Set TEST: %d/%d pieces added%s", "Set du Dieu-Soleil TEST : %d/%d pièces ajoutées%s"),count,#SUN_GOD_TEST_ITEMS,#errors>0 and (" | "..table.concat(errors,"; ")) or "")})
end)

-- V7.5K Radiant set test kit.
local RADIANT_TEST_ITEMS = {
    {"TOT_RADIANT_GOD_MACE","3753b38f-1c1e-511f-aa15-4f82ba572e05","TOT_RADIANT_GOD_MACE_NAME","h75k00000000000000000000000000101","h75k00000000000000000000000000102"},
    {"TOT_DAWN_CROWN","6025b07a-8327-5cd7-9300-6b48a67309b5","TOT_DAWN_CROWN_NAME","h73a00000000000000000000000002021","h73a00000000000000000000000002022"},
    {"TOT_RADIANT_ARMOR","952fff3c-932a-5a8e-94c3-4c0ddd041391","TOT_RADIANT_ARMOR_NAME","h74p00000000000000000000000000101","h74p00000000000000000000000000102"},
    {"TOT_RADIANT_GLOVES","7e0bb90f-dc7c-5ab9-8c2e-576db2cfe7e6","TOT_RADIANT_GLOVES_NAME","h74p00000000000000000000000000111","h74p00000000000000000000000000112"},
    {"TOT_RADIANT_BOOTS","d711f7d4-8ff8-56c6-af24-b0d25f89f0ef","TOT_RADIANT_BOOTS_NAME","h74p00000000000000000000000000121","h74p00000000000000000000000000122"},
}

Net.On("DebugSpawnRadiantSet", function(event)
    local character=Player.Host()
    local count=0
    local errors={}
    for _,def in ipairs(RADIANT_TEST_ITEMS) do
        local guid,err=SpawnConquerorTestItem(character,def)
        if guid then count=count+1 else table.insert(errors,err or def[1]) end
    end
    Net.Respond(event,{count==#RADIANT_TEST_ITEMS,string.format(TA_Text("Radiant Set TEST: %d/%d pieces added%s", "Set Radiant TEST : %d/%d pièces ajoutées%s"),count,#RADIANT_TEST_ITEMS,#errors>0 and (" | "..table.concat(errors,"; ")) or "")})
end)

-- V7.5J Celestial Twilight / Frost set test kit.
local TWILIGHT_TEST_ITEMS = {
    {"TOT_TWILIGHT_STAFF","7fdb1116-8b0c-5c4b-aba0-31b9c8c18708","TOT_TWILIGHT_STAFF_NAME","h75j00000000000000000000000000101","h75j00000000000000000000000000102"},
    {"TOT_TWILIGHT_HELM","3a6f4f6a-aa2c-57ff-a6b3-fdc8470c6f26","TOT_TWILIGHT_HELM_NAME","h75j00000000000000000000000000111","h75j00000000000000000000000000112"},
    {"TOT_TWILIGHT_GLOVES","30ff8c75-3cd6-5ec2-9d34-821632917f5d","TOT_TWILIGHT_GLOVES_NAME","h75j00000000000000000000000000121","h75j00000000000000000000000000122"},
    {"TOT_TWILIGHT_RING","fd41fe4f-43b3-51df-8663-99a9ed466ab1","TOT_TWILIGHT_RING_NAME","h75j00000000000000000000000000131","h75j00000000000000000000000000132"},
    {"TOT_RADIANT_CAPE","73aaaf23-2e8b-53df-8eff-998c79156274","TOT_RADIANT_CAPE_NAME","h74p00000000000000000000000000131","h74p00000000000000000000000000132"},
}

Net.On("DebugSpawnTwilightSet", function(event)
    local character=Player.Host()
    local count=0
    local errors={}
    for _,def in ipairs(TWILIGHT_TEST_ITEMS) do
        local guid,err=SpawnConquerorTestItem(character,def)
        if guid then count=count+1 else table.insert(errors,err or def[1]) end
    end
    Net.Respond(event,{count==#TWILIGHT_TEST_ITEMS,string.format(TA_Text("Celestial Twilight Set TEST: %d/%d pieces added%s", "Set du Crépuscule céleste TEST : %d/%d pièces ajoutées%s"),count,#TWILIGHT_TEST_ITEMS,#errors>0 and (" | "..table.concat(errors,"; ")) or "")})
end)


-- V8.3H: one single global equipment audit button.
-- This list intentionally contains every currently implemented Trials Ascension
-- equipment item in this build (sets, milestone rewards, unique/custom gear).
-- Deprecated Conqueror prototype boots/cape are not included because they are no longer
-- part of the active 6-piece Conqueror set.
local ALL_CUSTOM_GEAR_TEST_ITEMS = {
    -- Validated visual-only VFX library test weapons kept for reference
    {"TOT_VFX_TEST_RUSTY_HALBERD","a5a83656-50ac-5376-809a-987b03c729b8","TOT_VFX_TEST_RUSTY_HALBERD_NAME","h84e00000000000000000000000000101","h84e00000000000000000000000000102"},
    {"TOT_VFX_TEST_RUSTY_GREATSWORD","a5a3fe2f-d2c6-50a1-a26a-1946377f114e","TOT_VFX_TEST_RUSTY_GREATSWORD_NAME","h84e00000000000000000000000000111","h84e00000000000000000000000000112"},
    {"TOT_VFX_TEST_GITHYANKI_LONGSWORD","432dc513-cd7a-55cf-ad67-9cb9410d2c34","TOT_VFX_TEST_GITHYANKI_LONGSWORD_NAME","h84e00000000000000000000000000121","h84e00000000000000000000000000122"},
    -- V8.4G - first real Mythic weapons promoted from the validated VFX tests
    {"TOT_ZENITH_HALBERD","c4b2d6e2-04c2-5fb5-a72e-b521d6d19bb4","TOT_ZENITH_HALBERD_NAME","h84g00000000000000000000000000101","h84g00000000000000000000000000102"},
    {"TOT_FUNERAL_TIDE_TRIDENT","548664ad-6323-5b95-b65b-2aed7a4cca2a","TOT_FUNERAL_TIDE_TRIDENT_NAME","h84g00000000000000000000000000111","h84g00000000000000000000000000112"},
    {"TOT_MYTHIC_ABSOLUTE_AMULET","508ad869-d7f5-56a9-9aba-4a8e913a57c7","TOT_MYTHIC_ABSOLUTE_AMULET_NAME","h84h00000000000000000000000000101","h84h00000000000000000000000000102"},
    -- Core / unique gear
    {"TOT_DAKOUSAI_ARMOR","7ec107be-0c0a-5436-b29f-13058e7919f6","TOT_DAKOUSAI_ARMOR_NAME","h73a00000000000000000000000002001","h73a00000000000000000000000002002"},
    {"TOT_THOR_ARMOR","baab82ea-d694-5d08-ab54-e7602dc82f3e","TOT_THOR_ARMOR_NAME","h73a00000000000000000000000002011","h73a00000000000000000000000002012"},
    {"TOT_DAWN_CROWN","6025b07a-8327-5cd7-9300-6b48a67309b5","TOT_DAWN_CROWN_NAME","h73a00000000000000000000000002021","h73a00000000000000000000000002022"},
    {"TOT_PREDATOR_BOOTS","aea0480e-a39f-5dc6-a032-f02a28fb516b","TOT_PREDATOR_BOOTS_NAME","h73a00000000000000000000000002031","h73a00000000000000000000000002032"},
    {"TOT_DEV_MACE","b408f445-c150-5284-a980-361249dc3b64","TOT_DEV_MACE_NAME","h73a00000000000000000000000002041","h73a00000000000000000000000002042"},
    {"TOT_BERSERKER_HELMET","23d6e72b-3dd4-5ea4-aace-50a2311db87f","TOT_BERSERKER_HELMET_NAME","h74p00000000000000000000000000141","h74p00000000000000000000000000142"},

    -- Bard / Monk / utility legendary gear
    {"TOT_BARD_VIRTUOSO_CAP","1f150c06-1046-54ae-931a-460491efff7f","TOT_BARD_VIRTUOSO_CAP_NAME","h74a00000000000000000000000000101","h74a00000000000000000000000000102"},
    {"TOT_BARD_MAESTRO_GLOVES","f46be1e8-44b0-51a1-993b-b15e52b8cf19","TOT_BARD_MAESTRO_GLOVES_NAME","h74a00000000000000000000000000111","h74a00000000000000000000000000112"},
    {"TOT_BARD_ENCORE_BOOTS","fe3c5eb6-7613-59b0-8f5d-376bbc421efd","TOT_BARD_ENCORE_BOOTS_NAME","h74a00000000000000000000000000121","h74a00000000000000000000000000122"},
    {"TOT_BARD_HARMONIC_DUELIST","ab1d7487-f0a5-5cf4-b576-e5e115196d2d","TOT_BARD_HARMONIC_DUELIST_NAME","h74a00000000000000000000000000131","h74a00000000000000000000000000132"},
    {"TOT_MONK_AWAKENED_FIST_BOOTS","ff23cbb1-7883-5112-81cb-f9afa3137371","TOT_MONK_AWAKENED_FIST_BOOTS_NAME","h74a00000000000000000000000000141","h74a00000000000000000000000000142"},
    {"TOT_IMMORTAL_GUARDIAN_RING","244a2e9b-06c8-56bf-ac01-a60168a1d86b","TOT_IMMORTAL_GUARDIAN_RING_NAME","h74a00000000000000000000000000151","h74a00000000000000000000000000152"},
    {"TOT_RING_OF_ELEMENTS","14a59eb7-36ec-543d-a903-625a9cfb16e7","TOT_RING_OF_ELEMENTS_NAME","h74a00000000000000000000000000161","h74a00000000000000000000000000162"},
    {"TOT_HERO_AMULET","cea9128c-3804-5392-a077-dbd5534e48d6","TOT_HERO_AMULET_NAME","h74a00000000000000000000000000171","h74a00000000000000000000000000172"},
    {"TOT_EXOSKELETAL_GAUNTLETS","967601bb-ee10-5a3c-95ff-69b70f54dd95","TOT_EXOSKELETAL_GAUNTLETS_NAME","h74a00000000000000000000000000181","h74a00000000000000000000000000182"},

    -- Necromancer gear
    {"TOT_NECRO_TORCH","b81e0b8a-82d3-5ecf-88a2-59de52ae14d9","TOT_NECRO_TORCH_NAME","h74i00000000000000000000000000121","h74i00000000000000000000000000122"},
    {"TOT_NECRO_HOOD","20fbb5b5-58ca-59a2-870b-3652c5d2d3ef","TOT_NECRO_HOOD_NAME","h74i00000000000000000000000000131","h74i00000000000000000000000000132"},
    {"TOT_NECRO_ARMOR","2398a880-224a-5a1f-8897-f722d8cc8b0a","TOT_NECRO_ARMOR_NAME","h74i00000000000000000000000000141","h74i00000000000000000000000000142"},
    {"TOT_NECRO_STAFF","179f9bb8-6013-5f30-854d-43308db3d071","TOT_NECRO_STAFF_NAME","h84s00000000000000000000000000101","h84s00000000000000000000000000102"},
    {"TOT_NECRO_CAPE","7351e0cb-0b16-5649-81c0-226f62c545d1","TOT_NECRO_CAPE_NAME","h84s00000000000000000000000000111","h84s00000000000000000000000000112"},
    {"TOT_NECRO_BOW","893ed645-4450-5c41-9ab9-d4a1059f5b34","TOT_NECRO_BOW_NAME","h84s00000000000000000000000000121","h84s00000000000000000000000000122"},

    -- Sun God set
    {"TOT_SUN_GOD_SCIMITAR","4b094fdc-d3f1-5f77-a6e4-afb513999557","TOT_SUN_GOD_SCIMITAR_NAME","h74i00000000000000000000000000101","h74i00000000000000000000000000102"},
    {"TOT_SUN_GOD_CAPE","45d29e39-e5cb-5000-8cf2-a62a02590a2b","TOT_SUN_GOD_CAPE_NAME","h74i00000000000000000000000000111","h74i00000000000000000000000000112"},
    {"TOT_SUN_GOD_TUNIC","a1eb4411-a3e9-51e6-9cec-20cfd0dee0ce","TOT_SUN_GOD_TUNIC_NAME","h75g00000000000000000000000000101","h75g00000000000000000000000000102"},
    {"TOT_SUN_GOD_GLOVES","744bab7b-676b-513d-97d9-fddfc80a4eb1","TOT_SUN_GOD_GLOVES_NAME","h75g00000000000000000000000000111","h75g00000000000000000000000000112"},
    {"TOT_SUN_GOD_BOOTS","aaf2d61b-fa42-51ad-bed7-36a1fa5632d1","TOT_SUN_GOD_BOOTS_NAME","h75g00000000000000000000000000121","h75g00000000000000000000000000122"},
    {"TOT_SUN_GOD_RING","d3bc97eb-9344-51dd-a3fa-c3486095321b","TOT_SUN_GOD_RING_NAME","h75g00000000000000000000000000131","h75g00000000000000000000000000132"},

    -- Radiant set
    {"TOT_RADIANT_GOD_MACE","3753b38f-1c1e-511f-aa15-4f82ba572e05","TOT_RADIANT_GOD_MACE_NAME","h75k00000000000000000000000000101","h75k00000000000000000000000000102"},
    {"TOT_RADIANT_ARMOR","952fff3c-932a-5a8e-94c3-4c0ddd041391","TOT_RADIANT_ARMOR_NAME","h74p00000000000000000000000000101","h74p00000000000000000000000000102"},
    {"TOT_RADIANT_GLOVES","7e0bb90f-dc7c-5ab9-8c2e-576db2cfe7e6","TOT_RADIANT_GLOVES_NAME","h74p00000000000000000000000000111","h74p00000000000000000000000000112"},
    {"TOT_RADIANT_BOOTS","d711f7d4-8ff8-56c6-af24-b0d25f89f0ef","TOT_RADIANT_BOOTS_NAME","h74p00000000000000000000000000121","h74p00000000000000000000000000122"},
    {"TOT_RADIANT_CAPE","73aaaf23-2e8b-53df-8eff-998c79156274","TOT_RADIANT_CAPE_NAME","h74p00000000000000000000000000131","h74p00000000000000000000000000132"},

    -- Celestial Twilight / Frost set
    {"TOT_TWILIGHT_STAFF","7fdb1116-8b0c-5c4b-aba0-31b9c8c18708","TOT_TWILIGHT_STAFF_NAME","h75j00000000000000000000000000101","h75j00000000000000000000000000102"},
    {"TOT_TWILIGHT_HELM","3a6f4f6a-aa2c-57ff-a6b3-fdc8470c6f26","TOT_TWILIGHT_HELM_NAME","h75j00000000000000000000000000111","h75j00000000000000000000000000112"},
    {"TOT_TWILIGHT_GLOVES","30ff8c75-3cd6-5ec2-9d34-821632917f5d","TOT_TWILIGHT_GLOVES_NAME","h75j00000000000000000000000000121","h75j00000000000000000000000000122"},
    {"TOT_TWILIGHT_RING","fd41fe4f-43b3-51df-8663-99a9ed466ab1","TOT_TWILIGHT_RING_NAME","h75j00000000000000000000000000131","h75j00000000000000000000000000132"},

    -- Conqueror gear: all 8 custom pieces available for debug testing
    {"TOT_CONQ_HELMET","8eef2dfe-bfcc-5cfa-a60f-9fe89dd67716","TOT_CONQ_HELMET_NAME","h74k00000000000000000000000000101","h74k00000000000000000000000000102"},
    {"TOT_CONQ_ARMOR","7a5d768d-3bcf-57e5-8733-b7b35be6c87f","TOT_CONQ_ARMOR_NAME","h74k00000000000000000000000000111","h74k00000000000000000000000000112"},
    {"TOT_CONQ_GLOVES","0f90b44b-7e5f-519c-9e87-3dd53daed4fa","TOT_CONQ_GLOVES_NAME","h74k00000000000000000000000000121","h74k00000000000000000000000000122"},
    {"TOT_CONQ_BOOTS","6b2d9ab7-0188-4c83-b664-399e2cc1d4a1","TOT_CONQ_BOOTS_NAME","h74k00000000000000000000000000131","h74k00000000000000000000000000132"},
    {"TOT_CONQ_CAPE","ea23bc7d-3034-4a77-b664-c7b9bba5f811","TOT_CONQ_CAPE_NAME","h74k00000000000000000000000000141","h74k00000000000000000000000000142"},
    {"TOT_CONQ_RING","3aca14f5-0476-56ff-806d-6565ccf51117","TOT_CONQ_RING_NAME","h74k00000000000000000000000000151","h74k00000000000000000000000000152"},
    {"TOT_CONQ_BLADE","b9a508ed-661e-5c29-a75f-a1bfb68b9d62","TOT_CONQ_BLADE_NAME","h74k00000000000000000000000000161","h74k00000000000000000000000000162"},
    {"TOT_CONQ_AMULET","9875f590-c985-57e0-a358-8f79bc8059f9","TOT_CONQ_AMULET_NAME","h74k00000000000000000000000000171","h74k00000000000000000000000000172"},


    -- Healer / Ascension set
    {"TOT_HEALER_REVIVING_HANDS","2bb4ce4a-cd65-5ec0-9243-ae8a810d57b2","TOT_HEALER_REVIVING_HANDS_NAME","h83k00000000000000000000000000101","h83k00000000000000000000000000102"},
    {"TOT_HEALER_SALVING_RING","e66f7f9a-a43f-56f0-bd00-c2b3b3daa15a","TOT_HEALER_SALVING_RING_NAME","h83k00000000000000000000000000111","h83k00000000000000000000000000112"},
    {"TOT_HEALER_WHISPERING_PROMISE","74b80c3b-1e75-55d3-afc9-6a8ff2716ea2","TOT_HEALER_WHISPERING_PROMISE_NAME","h83k00000000000000000000000000121","h83k00000000000000000000000000122"},
    {"TOT_HEALER_AID_BOOTS","73f8ffea-c1a0-5981-9711-bd18747f7d9c","TOT_HEALER_AID_BOOTS_NAME","h83k00000000000000000000000000131","h83k00000000000000000000000000132"},
    {"TOT_HEALER_RESTORATION_AMULET","c7885f5d-7217-5edb-a577-893b89c56570","TOT_HEALER_RESTORATION_AMULET_NAME","h83k00000000000000000000000000141","h83k00000000000000000000000000142"},

    -- Milestone reward equipment
    -- V8.3G dedicated RootTemplate: safe to spawn directly through the same helper.
    {"TOT_RG50_TROK_FANG","4ab329ee-2ca8-4f13-8627-4200c55df155","TOT_RG50_TROK_FANG_NAME","h6a10e010g5000g4000ga001g000000000010","h6a10e011g5000g4000ga001g000000000011"},
    {"TOT_RG50_TOXIC_RAIDER_GARB","55c7b18d-a117-5812-be0a-9b88db9e1a34","TOT_RG50_TOXIC_RAIDER_GARB_NAME","h6a10e020g5000g4000ga001g000000000020","h6a10e021g5000g4000ga001g000000000021"},
    {"TOT_RG50_SCAVENGER_RING","96a10f56-30bd-5d96-94dd-36ed97aacc05","TOT_RG50_SCAVENGER_RING_NAME","h6a10e030g5000g4000ga001g000000000030","h6a10e031g5000g4000ga001g000000000031"},
    -- V8.3G dedicated RootTemplate.
    {"TOT_RG100_ASTRAL_CROSSBOW","8c8f7199-5f35-4e09-b4ab-d45bd3c2d595","TOT_RG100_ASTRAL_CROSSBOW_NAME","h72a00000000000000000000000000311","h72a00000000000000000000000000312"},
    {"TOT_RG100_ASTRAL_CLOAK","83226058-e413-54be-8070-f28186679b3d","TOT_RG100_ASTRAL_CLOAK_NAME","h72a00000000000000000000000000313","h72a00000000000000000000000000314"},
    {"TOT_RG150_BOOOAL_AMULET","beb1b67e-680f-5726-90aa-59681caf9e66","TOT_RG150_BOOOAL_AMULET_NAME","h72a00000000000000000000000000411","h72a00000000000000000000000000412"},
}

Net.On("DebugSpawnAllCustomGear", function(event)
    local character = Player.Host()
    local count = 0
    local errors = {}
    for _, def in ipairs(ALL_CUSTOM_GEAR_TEST_ITEMS) do
        local guid, err = SpawnConquerorTestItem(character, def)
        if guid then
            count = count + 1
        else
            table.insert(errors, err or def[1])
        end
    end
    local expected = #ALL_CUSTOM_GEAR_TEST_ITEMS
    Net.Respond(event,{
        count == expected,
        string.format(TA_Text("Trials Ascension equipment audit: %d/%d items added%s", "Audit équipements Trials Ascension : %d/%d objets ajoutés%s"), count, expected, #errors > 0 and (" | "..table.concat(errors,"; ")) or "")
    })
end)

