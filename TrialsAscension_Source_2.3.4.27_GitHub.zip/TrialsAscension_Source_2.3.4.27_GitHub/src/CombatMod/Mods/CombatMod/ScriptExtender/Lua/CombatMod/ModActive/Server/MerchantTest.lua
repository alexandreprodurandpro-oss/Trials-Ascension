-- Bromdir Poing-d’Or, dedicated Trials Ascension camp quartermaster.
-- Keeps Withers untouched. Stock is generated from controlled category pools and refreshed only on Long Rest.

MerchantTest = MerchantTest or {}

local DWARF_TEMPLATE = "8b0bd0b0-ed1b-49cf-be1c-1e366280309a" -- BASE_Dwarves_Male_Hill_Civilian
local WITHERS = "S_GLO_JergalAvatar_0133f2ad-e121-4590-b5f0-a79413919805"
local TRADER_TAG = "TRADER_91d5ebc6-91ea-44db-8a51-216860d69b5b"
local MERCHANT_NAME_KEY = "TOT_BROMDIR_NAME"
local MERCHANT_NAME_HANDLE = "h137cab50g350cg4597g887dgc120eb1f2b92"
local MERCHANT_NAME = "Bromdir Poing-d’Or"
local BROMDIR_MARKER = "TOT_BROMDIR_MARKER"
local GOLD_TEMPLATE = "1c3c9c74-34a1-4685-989e-410dc080be6f" -- OBJ_Goldpile
local LEGACY_NAME_HANDLES = {
    ["TOTBromdirName"] = true,
    ["h1b4f7a9cg84a2g4c85gaf17g54f9b3d7c20"] = true,
    ["h90300c57gbbe6g477bg8209g85a21e44620a"] = true,
}


local ensureBusy = false
local objectStatsCache = nil
local merchantObjectPoolCache = nil
local merchantGearPoolCache = nil
local configuredMerchants = {}

local RARITIES = { "Uncommon", "Rare", "VeryRare", "Legendary" }

-- Bromdir scales with the whole run, not just his equipment.
local RARITY_WEIGHTS = {
    { MinScore = 0,   Weights = { Uncommon = 90.5, Rare = 7,  VeryRare = 2,  Legendary = 0.5 } },
    { MinScore = 51,  Weights = { Uncommon = 70,   Rare = 22, VeryRare = 7,  Legendary = 1   } },
    { MinScore = 101, Weights = { Uncommon = 50,   Rare = 35, VeryRare = 13, Legendary = 2   } },
    { MinScore = 151, Weights = { Uncommon = 30,   Rare = 42, VeryRare = 24, Legendary = 4   } },
    { MinScore = 201, Weights = { Uncommon = 15,   Rare = 40, VeryRare = 38, Legendary = 7   } },
    { MinScore = 301, Weights = { Uncommon = 5,    Rare = 25, VeryRare = 55, Legendary = 15  } },
    { MinScore = 501, Weights = { Uncommon = 2,    Rare = 20, VeryRare = 63, Legendary = 15  } },
}

local STOCK_SCALE = {
    --              craft types/stack   potions/stack   scrolls/stack   arrows/stack   extras/stack
    { MinScore = 0,   Craft = {3,5,2,6},   Potions = {3,5,1,2},  Scrolls = {0,1,1,1},  Arrows = {0,1,1,2},  Extras = {0,1,1,1} },
    { MinScore = 51,  Craft = {5,7,3,7},   Potions = {4,6,1,3},  Scrolls = {1,2,1,1},  Arrows = {2,4,2,4},  Extras = {2,4,1,2} },
    { MinScore = 101, Craft = {7,9,3,8},   Potions = {5,7,1,3},  Scrolls = {2,3,1,2},  Arrows = {3,5,2,5},  Extras = {3,5,1,2} },
    { MinScore = 151, Craft = {9,12,4,9},  Potions = {6,8,2,4},  Scrolls = {3,4,1,2},  Arrows = {4,6,2,5},  Extras = {4,6,1,3} },
    { MinScore = 201, Craft = {12,15,4,10},Potions = {7,10,2,4}, Scrolls = {4,5,1,2},  Arrows = {5,7,2,6},  Extras = {5,7,2,3} },
    { MinScore = 301, Craft = {15,20,5,12},Potions = {9,12,2,5}, Scrolls = {5,7,1,3},  Arrows = {6,8,3,7},  Extras = {6,8,2,4} },
    { MinScore = 501, Craft = {20,25,6,14},Potions = {12,15,3,6},Scrolls = {7,10,1,3}, Arrows = {8,10,3,8}, Extras = {8,10,2,5} },
}

local function stockScale(score)
    local row = STOCK_SCALE[1]
    for _, candidate in ipairs(STOCK_SCALE) do
        if score >= candidate.MinScore then row = candidate end
    end
    return row
end

local HEALING_POTION_TIERS = {
    { MinScore = 0,   Stats = { "OBJ_Potion_Healing" } },
    { MinScore = 51,  Stats = { "OBJ_Potion_Healing_Greater", "OBJ_Potion_Healing" } },
    { MinScore = 101, Stats = { "OBJ_Potion_Healing_Greater", "OBJ_Potion_Healing_Superior" } },
    { MinScore = 151, Stats = { "OBJ_Potion_Healing_Superior", "OBJ_Potion_Healing_Greater" } },
    { MinScore = 201, Stats = { "OBJ_Potion_Healing_Superior", "OBJ_Potion_Healing_Supreme" } },
    { MinScore = 301, Stats = { "OBJ_Potion_Healing_Supreme", "OBJ_Potion_Healing_Superior" } },
    { MinScore = 501, Stats = { "OBJ_Potion_Healing_Supreme" } },
}

-- Raw alchemy ingredients available to Bromdir.
-- Small RG-gated selections complement the monster ingredient loop.
local CRAFT_POOL = {
    { MinScore = 0,   Stat = "CONS_Mushrooms_RoguesMorsel" },
    { MinScore = 0,   Stat = "CONS_Herbs_Balsam" },
    { MinScore = 0,   Stat = "CONS_Mushrooms_DragonEggMushroom" },
    { MinScore = 0,   Stat = "ALCH_Ingredient_Part_MudMephitWing" },
    { MinScore = 0,   Stat = "CONS_Herbs_Daggeroot" },
    { MinScore = 0,   Stat = "CONS_Herbs_Autumncrocus" },

    { MinScore = 51,  Stat = "ALCH_Ingredient_Part_HyenaEar" },
    { MinScore = 51,  Stat = "ALCH_Ingredient_Part_WorgFang" },
    { MinScore = 51,  Stat = "OBJ_Crystal_ChasmCreeper" },
    { MinScore = 51,  Stat = "CONS_Mushrooms_SwarmingToadstool" },

    { MinScore = 101, Stat = "ALCH_Ingredient_Loot_YellowMuskCreeper" },
    { MinScore = 101, Stat = "ALCH_Ingredient_Herb_BlackOleander" },
    { MinScore = 101, Stat = "ALCH_Ingredient_Part_IntellectDevourer" },

    { MinScore = 151, Stat = "ALCH_Ingredient_Mushroom_ShadowrootSac" },
    { MinScore = 151, Stat = "ALCH_Ingredient_Part_ImpPatagium" },
    { MinScore = 151, Stat = "ALCH_Ingredient_Part_MyconidSpore_Haste" },

    { MinScore = 201, Stat = "ALCH_Ingredient_Loot_CloudGiantFinger" },
    { MinScore = 201, Stat = "ALCH_Ingredient_Part_EagleFeather" },

    { MinScore = 301, Stat = "ALCH_Ingredient_Loot_CloudGiantFinger" },
    { MinScore = 301, Stat = "ALCH_Ingredient_Part_EagleFeather" },

    { MinScore = 501, Stat = "ALCH_Ingredient_Loot_KiRinHair" },
    { MinScore = 501, Stat = "ALCH_Ingredient_Loot_DivineBoneShard" },
}

local function validMerchant(guid)
    return guid and guid ~= "" and Ext.Entity.Get(guid) ~= nil and Osi.IsCharacter(guid) == 1
end

local function inventoryItemCount(guid)
    local entity = Ext.Entity.Get(guid)
    if not entity or not entity.InventoryOwner or not entity.InventoryOwner.Inventories[1] then
        return 0
    end
    local count = 0
    for _, _ in pairs(entity.InventoryOwner.Inventories[1].InventoryContainer.Items or {}) do
        count = count + 1
    end
    return count
end

local function isBromdirHandle(handle)
    return handle == MERCHANT_NAME_HANDLE or LEGACY_NAME_HANDLES[handle] == true
end

local function isMarkedBromdir(guid)
    return validMerchant(guid) and Osi.HasActiveStatus(guid, BROMDIR_MARKER) == 1
end

local function findBromdirCandidates()
    local out = {}
    local seen = {}
    local current = PersistentVars.MerchantTestGUID

    local function add(guid)
        if guid and guid ~= "" and validMerchant(guid) and not seen[guid] then
            seen[guid] = true
            table.insert(out, guid)
        end
    end

    -- The persisted GUID is always authoritative when it still exists.
    add(current)

    -- Marker-based discovery is the durable path for all V6.1+ Bromdir instances.
    -- Legacy display handles are kept only to clean up old duplicate instances once.
    for _, entity in ipairs(Ext.Entity.GetAllEntitiesWithComponent("ServerCharacter")) do
        local guid = entity.Uuid and entity.Uuid.EntityUuid
        if guid and Osi.IsCharacter(guid) == 1 then
            local displayHandle = Osi.GetDisplayName(guid)
            if isMarkedBromdir(guid) or isBromdirHandle(displayHandle) then
                add(guid)
            end
        end
    end
    return out
end

local function suppressDuplicate(guid)
    if not validMerchant(guid) then
        return
    end
    Osi.SetCanTrade(guid, 0)
    Osi.SetHasOsirisDialog(guid, 0)
    Osi.BlockNewCrimeReactions(guid, 1)
    Osi.SetVisible(guid, 0)
    -- Keep the duplicate inert instead of deleting a live engine character.
    -- This is safer for save compatibility; future Ensure() passes keep it hidden.
end

local function selectAndCleanupBromdir()
    local current = PersistentVars.MerchantTestGUID
    local candidates = findBromdirCandidates()
    if validMerchant(current) then
        local found = false
        for _, guid in ipairs(candidates) do
            if U.UUID.Equals(guid, current) then
                found = true
                break
            end
        end
        if not found then
            table.insert(candidates, current)
        end
    end

    if #candidates == 0 then
        return nil
    end

    local keep = validMerchant(current) and current or candidates[1]
    if not validMerchant(current) then
        -- Prefer the instance that already owns the shop inventory.
        local bestCount = -1
        for _, guid in ipairs(candidates) do
            local count = inventoryItemCount(guid)
            if count > bestCount then
                bestCount = count
                keep = guid
            end
        end
    end

    for _, guid in ipairs(candidates) do
        if not U.UUID.Equals(guid, keep) then
            suppressDuplicate(guid)
        end
    end

    if PersistentVars.MerchantStockInitialized and (not current or not U.UUID.Equals(current, keep)) then
        PersistentVars.MerchantPendingRestoreGUID = keep
    end
    PersistentVars.MerchantTestGUID = keep
    return keep
end

local function randInt(min, max)
    if max <= min then
        return min
    end
    return min + math.newRandom(max - min + 1) - 1
end


local function getScore()
    return PersistentVars.RogueScore or 0
end

local function rarityWeights(score)
    local data = RARITY_WEIGHTS[1]
    for _, row in ipairs(RARITY_WEIGHTS) do
        if score >= row.MinScore then
            data = row
        end
    end
    return data.Weights
end

local function rollRarity(score)
    local weights = rarityWeights(score)
    local total = 0
    for _, rarity in ipairs(RARITIES) do
        total = total + (weights[rarity] or 0)
    end
    local roll = math.newRandom() * total
    local cursor = 0
    for _, rarity in ipairs(RARITIES) do
        cursor = cursor + (weights[rarity] or 0)
        if roll <= cursor then
            return rarity
        end
    end
    return "Uncommon"
end

local function applySafety(guid)
    Osi.SetImmortal(guid, 1)
    Osi.ApplyStatus(guid, "INVULNERABLE_NOT_SHOWN", -1, 1)
    Osi.SetCanJoinCombat(guid, 0)
    Osi.SetCanFight(guid, 0)
    -- Bromdir may wander normally, but should never run away because of combat/crime AI.
    Osi.BlockFlee(guid)
    Osi.BlockNewCrimeReactions(guid, 1)

    if Osi.SetCanPickpocket then pcall(Osi.SetCanPickpocket, guid, 0) end
    if Osi.SetCanBePickpocketed then pcall(Osi.SetCanBePickpocketed, guid, 0) end
end

local function setMerchantName(guid)
    -- SetStoryDisplayName expects a localized STRING KEY, not a raw translated-string handle.
    -- Script Extender v32 exposes the proper key -> handle mapping API, so we register a
    -- stable key once and then let the game's normal display-name system resolve it.
    Ext.Loca.UpdateTranslatedString(MERCHANT_NAME_HANDLE, MERCHANT_NAME)
    Ext.Loca.UpdateTranslatedStringKey(MERCHANT_NAME_KEY, MERCHANT_NAME_HANDLE)
    Osi.SetStoryDisplayName(guid, MERCHANT_NAME_KEY)
end

local function itemFiltersAllow(name, stat)
    if not stat or stat.RootTemplate == "" or stat.Rarity == "" then
        return false
    end
    if name:match("^_") then
        return false
    end

    local filters = External.Templates.GetItemFilters()
    if string.contains(stat.ModId, filters.Mods, true, true) then
        return false
    end
    if string.contains(name, filters.Names, true) then
        return false
    end

    local temp = Ext.Template.GetTemplate(stat.RootTemplate)
    if not temp or temp.Name:match("DONOTUSE$") then
        return false
    end
    return true
end

local function buildGearPoolCache()
    if merchantGearPoolCache ~= nil then
        return merchantGearPoolCache
    end

    local cache = { Weapon = {}, Armor = {}, Ring = {}, Amulet = {} }
    for _, kind in ipairs({ "Weapon", "Armor", "Ring", "Amulet" }) do
        for _, rarity in ipairs(RARITIES) do
            cache[kind][rarity] = {}
        end
    end

    -- Item.Weapons/Item.Armor already apply CombatMod's normal blacklist and template filters.
    -- Build Bromdir's slot/rarity pools once per session instead of filtering them on every roll.
    local function isNativeGearEntry(item)
        if not item or not item.Name or not item.RootTemplate or item.RootTemplate == "" then
            return false
        end
        local template = Ext.Template.GetTemplate(item.RootTemplate)
        -- Bromdir must never create a hybrid item by temporarily replacing a
        -- vanilla RootTemplate's Stats. If the template does not already use
        -- these exact Stats, keep that custom/modified item out of his shop.
        return template ~= nil and template.Stats == item.Name
    end

    for _, item in ipairs(Item.Weapons(nil)) do
        if item and cache.Weapon[item.Rarity] and isNativeGearEntry(item) then
            table.insert(cache.Weapon[item.Rarity], item)
        end
    end

    for _, item in ipairs(Item.Armor(nil)) do
        if item and cache.Armor[item.Rarity] and isNativeGearEntry(item) then
            local slot = string.lower(item.Slot or "")
            if slot:find("ring", 1, true) ~= nil then
                table.insert(cache.Ring[item.Rarity], item)
            elseif slot:find("amulet", 1, true) ~= nil or slot:find("neck", 1, true) ~= nil then
                table.insert(cache.Amulet[item.Rarity], item)
            elseif slot:find("vanity", 1, true) == nil and slot:find("underwear", 1, true) == nil then
                table.insert(cache.Armor[item.Rarity], item)
            end
        end
    end

    merchantGearPoolCache = cache
    return cache
end

local function gearCandidates(kind, rarity)
    local cache = buildGearPoolCache()
    return (cache[kind] and cache[kind][rarity]) or {}
end

local function getObjectStats()
    if objectStatsCache == nil then
        objectStatsCache = Ext.Stats.GetStats("Object") or {}
    end
    return objectStatsCache
end

local function lower(value)
    return string.lower(value or "")
end

local function classifyObject(name, stat)
    local lname = lower(name)
    local category = lower(stat.ObjectCategory)
    local tab = lower(stat.InventoryTab)
    local useType = lower(stat.ItemUseType)

    local isFood = (category:match("^food") or category:match("^drink")) and name:match("^CONS_")
    local isScroll = useType == "scroll" or lname:find("scroll", 1, true) or category:find("scroll", 1, true)
    local isArrow = useType:find("arrow", 1, true) or lname:find("arrow", 1, true) or category:find("arrow", 1, true)
    local isPotion = useType == "potion" or lname:find("potion", 1, true) or lname:find("elixir", 1, true)
    local isCraft = lname:find("alch_ingredient", 1, true) or lname:find("cons_herbs_", 1, true)
        or lname:find("cons_mushrooms_", 1, true) or lname:find("obj_crystal_chasmcreeper", 1, true)

    if isFood then return "Food" end
    if isCraft then return "Craft" end
    if isScroll then return "Scroll" end
    if isArrow then return "Arrow" end
    if isPotion then return "Potion" end

    -- Deliberately narrow the miscellaneous combat-consumable pool so keys/books/quest junk never enter the shop.
    if tab == "magical"
        or useType:find("grenade", 1, true)
        or useType:find("poison", 1, true)
        or useType:find("coating", 1, true)
        or lname:find("grenade", 1, true)
        or lname:find("bomb", 1, true)
        or lname:find("coating", 1, true)
        or lname:find("poison", 1, true)
        or lname:find("oil", 1, true)
    then
        return "Consumable"
    end

    return nil
end

local function buildObjectPoolCache()
    if merchantObjectPoolCache ~= nil then
        return merchantObjectPoolCache
    end

    local cache = { Potion = {}, Arrow = {}, Consumable = {}, Scroll = {}, Food = {} }
    for _, kind in ipairs({ "Potion", "Arrow", "Consumable", "Scroll" }) do
        for _, rarity in ipairs(RARITIES) do
            cache[kind][rarity] = {}
        end
    end

    -- This is the expensive Object Stats pass. Do it once per session, then every Bromdir
    -- restock only performs cheap RNG selections from the cached tables.
    for _, name in ipairs(getObjectStats()) do
        local stat = Ext.Stats.Get(name)
        if itemFiltersAllow(name, stat) then
            local kind = classifyObject(name, stat)
            local item = { Name = name, RootTemplate = stat.RootTemplate, Rarity = stat.Rarity }
            if kind == "Food" then
                table.insert(cache.Food, item)
            elseif cache[kind] and cache[kind][stat.Rarity] then
                table.insert(cache[kind][stat.Rarity], item)
            end
        end
    end

    merchantObjectPoolCache = cache
    return cache
end

local function objectCandidates(kind, rarity)
    local cache = buildObjectPoolCache()
    return (cache[kind] and cache[kind][rarity]) or {}
end


local function craftCandidates(score)
    local out = {}
    for _, row in ipairs(CRAFT_POOL) do
        if score >= row.MinScore then
            local stat = Ext.Stats.Get(row.Stat)
            if itemFiltersAllow(row.Stat, stat) then
                table.insert(out, { Name = row.Stat, RootTemplate = stat.RootTemplate, Rarity = stat.Rarity })
            end
        end
    end
    return out
end

local function pickUnique(candidates, used)
    local available = table.filter(candidates, function(item)
        return item and not used[item.Name]
    end)
    if #available == 0 then
        return nil
    end
    local item = available[math.newRandom(#available)]
    used[item.Name] = true
    return item
end

local function candidatesWithRarityFallback(kind, desiredRarity, score, isGear)
    local getter = isGear and gearCandidates or objectCandidates
    local list = getter(kind, desiredRarity)
    if #list > 0 then
        return list
    end

    -- If a category has no item at the rolled rarity, try the other non-common rarities.
    -- This preserves the user's "no white except craft/food" rule without creating empty slots.
    for _, rarity in ipairs(RARITIES) do
        if rarity ~= desiredRarity then
            local alt = getter(kind, rarity)
            if #alt > 0 then
                return alt
            end
        end
    end
    return {}
end

local function getInventoryGuids(guid)
    local out = {}
    local entity = Ext.Entity.Get(guid)
    if entity and entity.InventoryOwner and entity.InventoryOwner.Inventories[1] then
        for _, entry in pairs(entity.InventoryOwner.Inventories[1].InventoryContainer.Items or {}) do
            local itemGuid = entry.Item and entry.Item.Uuid and entry.Item.Uuid.EntityUuid
            if itemGuid then out[itemGuid] = true end
        end
    end
    return out
end

local function addExactStatItem(guid, item)
    if not item or not item.Name or not item.RootTemplate or item.RootTemplate == "" then
        return false
    end

    local template = Ext.Template.GetTemplate(item.RootTemplate)
    if not template then return false end

    local originalStat = template.Stats
    local needsOverwrite = originalStat ~= item.Name
    if needsOverwrite then
        Event.Trigger("TemplateOverwrite", item.RootTemplate, "Stats", item.Name)
    end

    local before = getInventoryGuids(guid)
    Osi.TemplateAddTo(item.RootTemplate, guid, 1, 0)

    if needsOverwrite then
        Event.Trigger("TemplateOverwrite", item.RootTemplate, "Stats", originalStat)
    end

    local entity = Ext.Entity.Get(guid)
    if entity and entity.InventoryOwner and entity.InventoryOwner.Inventories[1] then
        for _, entry in pairs(entity.InventoryOwner.Inventories[1].InventoryContainer.Items or {}) do
            local spawned = entry.Item
            local spawnedGuid = spawned and spawned.Uuid and spawned.Uuid.EntityUuid
            if spawnedGuid and not before[spawnedGuid]
                and spawned.ServerItem and spawned.ServerItem.CreateCacheTemplate then
                local ok, cached = pcall(function() return spawned.ServerItem:CreateCacheTemplate() end)
                if ok and cached then cached.Stats = item.Name end
                break
            end
        end
    end
    return true
end

local function healingPotionCandidates(score)
    local tier = HEALING_POTION_TIERS[1]
    for _, row in ipairs(HEALING_POTION_TIERS) do
        if score >= row.MinScore then tier = row end
    end

    local out = {}
    for _, statName in ipairs(tier.Stats) do
        local stat = Ext.Stats.Get(statName)
        if stat and stat.RootTemplate and stat.RootTemplate ~= "" then
            table.insert(out, { Name = statName, RootTemplate = stat.RootTemplate, Rarity = stat.Rarity })
        end
    end
    return out
end

local function addGearRoll(guid, score, used)
    local kinds = { "Weapon", "Armor", "Ring", "Amulet" }
    for _ = 1, 20 do
        local kind = kinds[math.newRandom(#kinds)]
        local rarity = rollRarity(score)
        local candidates = candidatesWithRarityFallback(kind, rarity, score, true)
        local item = pickUnique(candidates, used)
        if item and addExactStatItem(guid, item) then
            return true
        end
    end
    return false
end

local function addItem(guid, item, quantity)
    if not item or not item.RootTemplate or item.RootTemplate == "" then
        return false
    end
    Osi.TemplateAddTo(item.RootTemplate, guid, quantity or 1, 0)
    return true
end

local function addRolledCategory(guid, kind, count, qtyMin, qtyMax, score, used, isGear)
    local added = 0
    local attempts = 0
    while added < count and attempts < count * 12 do
        attempts = attempts + 1
        local rarity = rollRarity(score)
        local candidates = candidatesWithRarityFallback(kind, rarity, score, isGear)
        local item = pickUnique(candidates, used)
        if item then
            addItem(guid, item, randInt(qtyMin, qtyMax))
            added = added + 1
        end
    end
    return added
end

local function addSimpleUniqueCategory(guid, candidates, count, qtyMin, qtyMax, used)
    local added = 0
    while added < count do
        local item = pickUnique(candidates, used)
        if not item then break end
        addItem(guid, item, randInt(qtyMin, qtyMax))
        added = added + 1
    end
    return added
end

local function safeItemAmount(item, itemGuid)
    -- Different Script Extender/Osiris builds expose stack quantity differently.
    -- Never call a missing Osi function directly.
    if Osi.GetStackAmount then
        local ok, value = pcall(Osi.GetStackAmount, itemGuid)
        if ok and type(value) == "number" and value > 0 then
            return value
        end
    end

    -- ECS fallback when a stack amount is exposed on the item component.
    if item then
        local candidates = {
            item.Amount,
            item.StackAmount,
            item.ServerItem and item.ServerItem.Amount,
            item.ServerItem and item.ServerItem.StackAmount,
        }
        for _, value in ipairs(candidates) do
            if type(value) == "number" and value > 0 then
                return value
            end
        end
    end

    return 1
end

local function clearMerchantInventory(guid)
    local entity = Ext.Entity.Get(guid)
    if entity and entity.InventoryOwner and entity.InventoryOwner.Inventories[1] then
        local inventory = entity.InventoryOwner.Inventories[1].InventoryContainer.Items
        -- Copy UUIDs first because deletion mutates the inventory container.
        local items = {}
        for _, entry in pairs(inventory) do
            table.insert(items, entry.Item.Uuid.EntityUuid)
        end
        for _, itemGuid in ipairs(items) do
            GU.Object.Remove(itemGuid)
        end
        entity:Replicate("InventoryOwner")
    end

end

local function protectMerchantInventory(guid)
    local entity = Ext.Entity.Get(guid)
    if not entity or not entity.InventoryOwner or not entity.InventoryOwner.Inventories[1] then
        return
    end

    for _, entry in pairs(entity.InventoryOwner.Inventories[1].InventoryContainer.Items or {}) do
        local itemGuid = entry.Item and entry.Item.Uuid and entry.Item.Uuid.EntityUuid
        if itemGuid and itemGuid ~= "" and Osi.SetCanBePickpocketed then
            pcall(Osi.SetCanBePickpocketed, itemGuid, 0)
        end
    end
end

local function snapshotMerchantInventory(guid)
    if not validMerchant(guid) then
        return
    end
    protectMerchantInventory(guid)
    local entity = Ext.Entity.Get(guid)
    local snapshot = {}
    if entity and entity.InventoryOwner and entity.InventoryOwner.Inventories[1] then
        for _, entry in pairs(entity.InventoryOwner.Inventories[1].InventoryContainer.Items or {}) do
            local item = entry.Item
            local itemGuid = item and item.Uuid and item.Uuid.EntityUuid
            local template = item and item.ServerItem and item.ServerItem.Template and item.ServerItem.Template.Id
            if itemGuid and template and template ~= "" then
                local amount = safeItemAmount(item, itemGuid)
                table.insert(snapshot, { Template = template, Stats = item.ServerItem and item.ServerItem.Stats or nil, Amount = math.max(1, amount) })
            end
        end
    end
    PersistentVars.MerchantInventorySnapshot = snapshot
end

local function restoreMerchantInventory(guid)
    local snapshot = PersistentVars.MerchantInventorySnapshot
    if not validMerchant(guid) or type(snapshot) ~= "table" or #snapshot == 0 then
        return false
    end
    clearMerchantInventory(guid)
    for _, item in ipairs(snapshot) do
        if item.Template and item.Template ~= "" and (item.Amount or 0) > 0 then
            local template = Ext.Template.GetRootTemplate(item.Template)
            local baseStats = template and template.Stats or nil
            if item.Stats and item.Stats ~= "" and item.Stats ~= baseStats then
                -- Preserve per-instance cached Stats (notably the cheap starter arsenal)
                -- without mutating the shared vanilla RootTemplate.
                local x,y,z = Osi.GetPosition(guid)
                for _ = 1, item.Amount do
                    local ok, spawnedGuid = pcall(Osi.CreateAt, item.Template, x, y, z, 0, 1, "")
                    if ok and spawnedGuid and spawnedGuid ~= "" then
                        local entity = Ext.Entity.Get(spawnedGuid)
                        local serverItem = entity and entity.ServerItem
                        if serverItem and serverItem.CreateCacheTemplate then
                            local cached = serverItem:CreateCacheTemplate()
                            if cached then cached.Stats = item.Stats end
                        end
                        Osi.ToInventory(spawnedGuid, guid)
                    end
                end
            else
                Osi.TemplateAddTo(item.Template, guid, item.Amount, 0)
            end
        end
    end
    protectMerchantInventory(guid)
    return true
end


-- V8.3K: cheap permanent starter arsenal. Spawn a vanilla visual, then give only that instance
-- a custom cached Stats entry with ValueOverride=5. No shared vanilla RootTemplate is modified.
local BROMDIR_STARTER_WEAPONS = {
    {"WPN_HandCrossbow","TOT_BROMDIR_STARTER_HAND_CROSSBOW",2},
    {"WPN_Longsword","TOT_BROMDIR_STARTER_LONGSWORD",1},
    {"WPN_Shortsword","TOT_BROMDIR_STARTER_SHORTSWORD",1},
    {"WPN_Dagger","TOT_BROMDIR_STARTER_DAGGER",1},
    {"WPN_Mace","TOT_BROMDIR_STARTER_MACE",1},
    {"WPN_Handaxe","TOT_BROMDIR_STARTER_HANDAXE",1},
    {"WPN_Battleaxe","TOT_BROMDIR_STARTER_BATTLEAXE",1},
    {"WPN_Greataxe","TOT_BROMDIR_STARTER_GREATAXE",1},
    {"WPN_Greatsword","TOT_BROMDIR_STARTER_GREAT_SWORD",1},
    {"WPN_Spear","TOT_BROMDIR_STARTER_SPEAR",1},
    {"WPN_LightCrossbow","TOT_BROMDIR_STARTER_LIGHT_CROSSBOW",1},
    {"WPN_Shortbow","TOT_BROMDIR_STARTER_SHORTBOW",1},
}
local function addCheapStarterWeapon(merchantGuid, vanillaStat, customStat, amount)
    local stat = Ext.Stats.Get(vanillaStat)
    local root = stat and stat.RootTemplate
    if not root or root == "" then
        L.Warn("Bromdir starter missing", vanillaStat)
        return 0
    end

    -- V8.3V: ne plus faire CreateAt() aux pieds de Bromdir.
    -- On utilise le même chemin sûr que le stock normal : TemplateAddTo()
    -- ajoute l'objet directement dans son inventaire, puis addExactStatItem()
    -- applique le Stats custom uniquement à l'instance créée.
    local added = 0
    local item = { Name = customStat, RootTemplate = root }
    for _ = 1, (amount or 1) do
        if addExactStatItem(merchantGuid, item) then
            added = added + 1
        else
            L.Warn("Bromdir starter inventory add failed", vanillaStat, customStat)
        end
    end
    return added
end
local function addStarterArsenal(merchantGuid)
    local total=0
    for _,d in ipairs(BROMDIR_STARTER_WEAPONS) do total=total+addCheapStarterWeapon(merchantGuid,d[1],d[2],d[3]) end
    return total
end

function MerchantTest.RefreshStock(reason)
    local guid = PersistentVars.MerchantTestGUID
    if not validMerchant(guid) then
        return false
    end

    local score = getScore()
    clearMerchantInventory(guid)

    -- Physical gold stack: the trader budget now persists as a normal inventory item.
    local merchantGold = randInt(2500, 4500)
    Osi.TemplateAddTo(GOLD_TEMPLATE, guid, merchantGold, 0)

    -- V8.3K: permanent cheap common starter arsenal, regenerated only on initial stock/Long Rest.
    addStarterArsenal(guid)

    local used = {}

    -- 1-3 equipment pieces TOTAL. No mandatory ring anymore.
    local gearCount = randInt(1, 3)
    for _ = 1, gearCount do
        addGearRoll(guid, score, used)
    end

    -- Everything except equipment scales in quantity as well as quality.
    local scale = stockScale(score)

    -- Potions: healing tier rises with RG; the rest stays random and RG-scaled.
    local potionCount = randInt(scale.Potions[1], scale.Potions[2])
    local healCandidates = healingPotionCandidates(score)
    local healSlots = (#healCandidates > 0) and math.min(2, potionCount) or 0
    if healSlots > 0 then
        addSimpleUniqueCategory(guid, healCandidates, healSlots, scale.Potions[3], scale.Potions[4], used)
    end
    local remainingPotionSlots = potionCount - healSlots
    if remainingPotionSlots > 0 then
        addRolledCategory(guid, "Potion", remainingPotionSlots, scale.Potions[3], scale.Potions[4], score, used, false)
    end

    -- Craft: number of different resources AND quantity per resource rise with RG.
    -- Example: a Swarming Toadstool line can be a small 2-6 pile early, then scale gradually.
    addSimpleUniqueCategory(
        guid, craftCandidates(score),
        randInt(scale.Craft[1], scale.Craft[2]),
        scale.Craft[3], scale.Craft[4], used
    )

    -- Scrolls return to Bromdir, but remain much rarer than craft supplies.
    if scale.Scrolls[2] > 0 then
        addRolledCategory(
            guid, "Scroll",
            randInt(scale.Scrolls[1], scale.Scrolls[2]),
            scale.Scrolls[3], scale.Scrolls[4], score, used, false
        )
    end

    -- Special arrows become meaningfully available from RG 51-100 onward.
    if scale.Arrows[2] > 0 then
        addRolledCategory(
            guid, "Arrow",
            randInt(scale.Arrows[1], scale.Arrows[2]),
            scale.Arrows[3], scale.Arrows[4], score, used, false
        )
    end

    -- Elixirs / combat consumables: deliberately modest at RG 1-50, then useful.
    if scale.Extras[2] > 0 then
        addRolledCategory(
            guid, "Consumable",
            randInt(scale.Extras[1], scale.Extras[2]),
            scale.Extras[3], scale.Extras[4], score, used, false
        )
    end

    PersistentVars.MerchantStockInitialized = true
    PersistentVars.MerchantStockGeneration = (PersistentVars.MerchantStockGeneration or 0) + 1
    PersistentVars.MerchantTestStocked = true -- legacy compatibility
    protectMerchantInventory(guid)
    snapshotMerchantInventory(guid)

    L.Info("Merchant V2 stock generated:", reason or "unknown", "RG", score, "Gold", merchantGold,
        "Generation", PersistentVars.MerchantStockGeneration)
    return true
end

local function setupMerchant(guid)
    if not validMerchant(guid) then
        return false
    end

    if not configuredMerchants[guid] then
        Osi.SetTag(guid, TRADER_TAG)
        applySafety(guid)
        setMerchantName(guid)
        Osi.ApplyStatus(guid, BROMDIR_MARKER, -1, 1)
        configuredMerchants[guid] = true
    end

    -- A previously suppressed duplicate can later become the authoritative candidate on an old save.
    -- Re-assert only presentation/trade flags; this never touches stock.
    Osi.SetCanTrade(guid, 1)
    Osi.SetHasOsirisDialog(guid, 1)
    Osi.SetVisible(guid, 1)

    if not PersistentVars.MerchantStockInitialized then
        MerchantTest.RefreshStock("initial")
    elseif PersistentVars.MerchantPendingRestoreGUID == guid then
        -- Restore only a truly recreated Bromdir. An existing merchant that the
        -- players legitimately emptied must never refill outside a Long Rest.
        local generation = PersistentVars.MerchantStockGeneration or 0
        Defer(1200, function()
            if PersistentVars.MerchantPendingRestoreGUID ~= guid or not validMerchant(guid) then return end
            if inventoryItemCount(guid) > 0 then
                PersistentVars.MerchantPendingRestoreGUID = nil
                protectMerchantInventory(guid)
                return
            end
            if PersistentVars.MerchantLastRestoredGUID == guid
                and PersistentVars.MerchantLastRestoredGeneration == generation then
                PersistentVars.MerchantPendingRestoreGUID = nil
                return
            end
            -- Mark before TemplateAddTo to make closely-spaced camp events idempotent.
            PersistentVars.MerchantLastRestoredGUID = guid
            PersistentVars.MerchantLastRestoredGeneration = generation
            PersistentVars.MerchantPendingRestoreGUID = nil
            restoreMerchantInventory(guid)
        end)
    elseif type(PersistentVars.MerchantInventorySnapshot) ~= "table"
        or #PersistentVars.MerchantInventorySnapshot == 0 then
        -- Upgrade old saves in-place without changing their current shop inventory.
        snapshotMerchantInventory(guid)
    end

    L.Info("Merchant V2 ready:", MERCHANT_NAME, guid)
    return true
end

local function safeRegion(guid)
    if not guid or guid == "" or not Ext.Entity.Get(guid) then
        return nil
    end
    local ok, region = pcall(Osi.GetRegion, guid)
    if ok and region and region ~= "" then
        return region
    end
    return nil
end

local function campAnchor()
    local host = Player.Host()
    if not host or host == "" or not Ext.Entity.Get(host) then
        return nil
    end
    local hostRegion = safeRegion(host)
    -- Withers is preferred only when he is actually loaded in the host's current region.
    if Ext.Entity.Get(WITHERS) and safeRegion(WITHERS) == hostRegion then
        return WITHERS
    end
    return host
end

local function readableInventory(guid)
    local entity = Ext.Entity.Get(guid)
    return entity and entity.InventoryOwner and entity.InventoryOwner.Inventories[1] ~= nil
end

local function nearAnchor(guid, anchor)
    if not validMerchant(guid) or not anchor or anchor == "" or not Ext.Entity.Get(anchor) then
        return false
    end
    local merchantRegion = safeRegion(guid)
    local anchorRegion = safeRegion(anchor)
    if not merchantRegion or not anchorRegion or merchantRegion ~= anchorRegion then
        return false
    end
    local ok, distance = pcall(Osi.GetDistanceTo, guid, anchor)
    return ok and type(distance) == "number" and distance >= 0 and distance <= 30
end

local function spawnLocalBromdir(anchor)
    anchor = anchor or campAnchor()
    if not anchor then
        L.Error("Merchant V2: no current-camp anchor available")
        return nil
    end

    local x, y, z = Osi.GetPosition(anchor)
    x = x + 3.0
    z = z + 2.0
    local host = Player.Host()
    local vx, vy, vz = Osi.FindValidPosition(x, y, z, 80, host, 1)
    if vx and vy and vz then
        x, y, z = vx, vy, vz
    end

    local guid = Osi.CreateAt(DWARF_TEMPLATE, x, y, z, 0, 1, "")
    if not validMerchant(guid) then
        L.Error("Merchant V2: failed to spawn dwarf using template", DWARF_TEMPLATE)
        return nil
    end

    PersistentVars.MerchantTestGUID = guid
    if PersistentVars.MerchantStockInitialized then
        PersistentVars.MerchantPendingRestoreGUID = guid
    end
    Osi.ApplyStatus(guid, BROMDIR_MARKER, -1, 1)
    setupMerchant(guid)
    return guid
end

function MerchantTest.Ensure()
    if ensureBusy then
        return PersistentVars.MerchantTestGUID
    end
    ensureBusy = true

    -- Keep one authoritative Bromdir, then force that same character to follow the player
    -- into the currently loaded camp. This also fixes two camp layouts that share a region.
    local existing = selectAndCleanupBromdir()
    local anchor = campAnchor()

    if validMerchant(existing) then
        -- Preserve the exact live inventory before a cross-level move whenever the inventory
        -- component is actually readable. Never manufacture/reroll stock here.
        if PersistentVars.MerchantStockInitialized and readableInventory(existing) then
            snapshotMerchantInventory(existing)
        end

        if anchor then
            local ok, err = pcall(Osi.TeleportTo, existing, anchor, "", 1, 1, 1, 1, 1)
            if not ok then
                L.Warn("Merchant V2: Bromdir teleport request failed; local fallback scheduled", err)
            end

            Defer(1500, function()
                if validMerchant(existing) and nearAnchor(existing, anchor) then
                    setupMerchant(existing)
                    PersistentVars.MerchantTestGUID = existing
                    ensureBusy = false
                    L.Info("Merchant V2: Bromdir followed current camp", safeRegion(existing))
                    return
                end

                -- Cross-level transfer failed (the SCL2 failure mode): leave the old character
                -- inert, then create one local instance. setupMerchant() restores the saved
                -- inventory snapshot and never calls RefreshStock outside Long Rest.
                if validMerchant(existing) then
                    suppressDuplicate(existing)
                end
                if PersistentVars.MerchantTestGUID and U.UUID.Equals(PersistentVars.MerchantTestGUID, existing) then
                    PersistentVars.MerchantTestGUID = nil
                end
                local recreated = spawnLocalBromdir(anchor)
                ensureBusy = false
                if recreated then
                    L.Info("Merchant V2: recreated Bromdir in current camp after failed transfer", recreated)
                end
            end)
            return existing
        end

        setupMerchant(existing)
        ensureBusy = false
        return existing
    end

    local guid = spawnLocalBromdir(anchor)
    ensureBusy = false
    return guid
end

local function openInteraction(player, merchant)
    if not validMerchant(merchant) then
        return
    end

    -- Stop any queued story movement before opening trade so Bromdir does not walk away
    -- in the middle of an interaction. His normal camp wandering is otherwise preserved.
    Osi.PurgeOsirisQueue(merchant, 1)

    -- Multiplayer-safe: open the trade window directly for the character who clicked Bromdir.
    -- Avoid Player.AskConfirmation(), which targets the host in multiplayer.
    Osi.ActivateTrade(player, merchant, 1, 3, "", "")
end

local function ensureAfterCampArrival(uuid)
    if not U.UUID.Equals(uuid, Player.Host()) then
        return
    end
    Defer(3500, function()
        MerchantTest.Ensure()
    end)
end

Ext.Osiris.RegisterListener("TeleportedToCamp", 1, "after", ensureAfterCampArrival)
Event.On("ReturnToCamp", function()
    Defer(3500, function()
        MerchantTest.Ensure()
    end)
end)

-- Cross-act safety net (including Act 3/BGO/CTY camps). Some level transitions can
-- complete without the normal TeleportedToCamp callback. Only act when the host is
-- actually in camp, so this never drags Bromdir onto combat maps. Ensure() preserves
-- the live inventory and never rerolls stock.
Ext.Osiris.RegisterListener("EnteredLevel", 3, "after", function(object, rootTemplate, level)
    if not U.UUID.Equals(object, Player.Host()) then
        return
    end
    Defer(4000, function()
        if Player.InCamp() then
            MerchantTest.Ensure()
        end
    end)
end)

-- Stock resets only on a completed long rest, as validated for Merchant V1.
Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    Defer(500, function()
        MerchantTest.Ensure()
        -- Ensure() may be moving/recreating Bromdir across camp levels. Refresh only the
        -- authoritative current instance after that handoff. Long Rest remains the sole reroll.
        Defer(1800, function()
            local guid = PersistentVars.MerchantTestGUID
            if validMerchant(guid) then
                MerchantTest.RefreshStock("long rest")
            end
        end)
    end)
end)

Ext.Osiris.RegisterListener("DialogStartRequested", 2, "after", function(target, player)
    local merchant = PersistentVars.MerchantTestGUID
    if validMerchant(merchant) and U.UUID.Equals(target, merchant) then
        openInteraction(player, merchant)
    end
end)

Ext.Osiris.RegisterListener("RequestTrade", 4, "after", function(character, trader, tradeMode, itemsTagFilter)
    local merchant = PersistentVars.MerchantTestGUID
    if validMerchant(merchant) and U.UUID.Equals(trader, merchant) then
        Osi.ActivateTrade(character, trader, 1, tradeMode, "", itemsTagFilter or "")
    end
end)


-- Hard anti-pickpocket gate.
-- Item-level CanBePickpocketed flags are the primary protection; request hooks
-- are an additional guard against spam/races in the vanilla story pipeline.
local function blockBromdirPickpocket(player, npc)
    local merchant = PersistentVars.MerchantTestGUID
    if validMerchant(merchant) and U.UUID.Equals(npc, merchant) then
        protectMerchantInventory(merchant)
        Osi.StartPickpocket(player, npc, 0)
        return true
    end
    return false
end

Ext.Osiris.RegisterListener("RequestPickpocket", 2, "before", function(player, npc)
    blockBromdirPickpocket(player, npc)
end)

Ext.Osiris.RegisterListener("RequestPickpocket", 2, "after", function(player, npc)
    if blockBromdirPickpocket(player, npc) then
        L.Info("Bromdir pickpocket blocked.")
    end
end)

Ext.Osiris.RegisterListener("CharacterPickpocketSuccess", 6, "after", function(player, npc, item, itemTemplate, amount, goldValue)
    local merchant = PersistentVars.MerchantTestGUID
    if validMerchant(merchant) and U.UUID.Equals(npc, merchant) then
        if item and item ~= "" and Osi.IsItem(item) == 1 then
            Osi.ToInventory(item, merchant)
            if Osi.SetCanBePickpocketed then
                pcall(Osi.SetCanBePickpocketed, item, 0)
            end
        end

        protectMerchantInventory(merchant)
        snapshotMerchantInventory(merchant)

        Defer(50, function()
            if validMerchant(merchant) then
                protectMerchantInventory(merchant)
                snapshotMerchantInventory(merchant)
            end
        end)
    end
end)

Ext.Osiris.RegisterListener("TradeEnds", 2, "after", function(character, trader)
    local merchant = PersistentVars.MerchantTestGUID
    if validMerchant(merchant) and U.UUID.Equals(trader, merchant) then
        protectMerchantInventory(merchant)
        snapshotMerchantInventory(merchant)
    end
end)
