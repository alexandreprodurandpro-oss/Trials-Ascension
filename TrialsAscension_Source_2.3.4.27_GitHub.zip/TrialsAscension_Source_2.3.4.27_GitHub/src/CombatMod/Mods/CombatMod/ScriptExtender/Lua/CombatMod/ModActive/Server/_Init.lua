Scenario = {}
Enemy = {}
Map = {}
Item = {}
GameMode = {}
StoryBypass = {}
Unlock = {}
Reward = {}
Contracts = {}
SummonControl = {}

function LogRandom(key, value, max)
    if not max then
        max = 10
    end

    if not PersistentVars.RandomLog[key] then
        PersistentVars.RandomLog[key] = {}
    end

    table.insert(PersistentVars.RandomLog[key], value)
    if #PersistentVars.RandomLog[key] > max then
        table.remove(PersistentVars.RandomLog[key], 1)
    end
end

GameState.OnSave(function()
    PersistentVars.Config = Config

    for obj, _ in pairs(PersistentVars.SpawnedEnemies) do
        if not Ext.Entity.Get(obj) then
            L.Debug("Cleaning up SpawnedEnemies", obj)
            PersistentVars.SpawnedEnemies[obj] = nil
        end
    end

    for obj, _ in pairs(PersistentVars.SpawnedItems) do
        if
            GU.Object.IsOwned(obj) or Osi.IsItem(obj) ~= 1 -- was used
        then
            L.Debug("Cleaning up SpawnedItems", obj)
            PersistentVars.SpawnedItems[obj] = nil
        end
    end
end)

GameState.OnLoad(function()
    Enemy.RestoreFromSave(PersistentVars.SpawnedEnemies)

    if eq(PersistentVars.Scenario, {}) then
        PersistentVars.Scenario = nil
    end

    if PersistentVars.Scenario ~= nil then
        Scenario.RestoreFromSave(PersistentVars.Scenario)
    end

    Player.AskConfirmation(TA_Text([[
Regenerate enemy, item, and map tables?
If you've recently updated, this is recommended.
Old data may need to be cleared, and new data may need to be pulled in.]], [[
Régénérer les tables d'ennemis, d'objets et de cartes ?
Si vous venez de mettre le mod à jour, cette opération est recommandée.
Les anciennes données peuvent devoir être nettoyées et de nouvelles données chargées.]])):After(function(confirmed)
            if confirmed then
                Templates.RefreshGameplayTables("GameState.OnLoad")
                Net.Send("GetTemplates")
                Net.Send("GetSelection")
            end
        end)
end, true)

Require("CombatMod/ModActive/Server/Templates")
Require("CombatMod/ModActive/Server/Scenario")
Require("CombatMod/ModActive/Server/Enemy")
Require("CombatMod/ModActive/Server/Map")
Require("CombatMod/ModActive/Server/Item")
Require("CombatMod/ModActive/Server/SunGodSet")
Require("CombatMod/ModActive/Server/CelestialTwilightSet")
Require("CombatMod/ModActive/Server/RadiantSet")
Require("CombatMod/ModActive/Server/ConquerorSet")
Require("CombatMod/ModActive/Server/HealerSet")
Require("CombatMod/ModActive/Server/BardSet")
Require("CombatMod/ModActive/Server/NecromancerSet")
Require("CombatMod/ModActive/Server/Jam4Companion")
Require("CombatMod/ModActive/Server/CantripAction")
Require("CombatMod/ModActive/Server/StoryBypass")
Require("CombatMod/ModActive/Server/GameMode")
Require("CombatMod/ModActive/Server/Reward")
Require("CombatMod/ModActive/Server/Contracts")
Require("CombatMod/ModActive/Server/SummonControl")
Require("CombatMod/ModActive/Server/NetEvents")
Require("CombatMod/ModActive/Server/DebugCommands")
Require("CombatMod/ModActive/Server/Unlock")
Require("CombatMod/ModActive/Server/Player")
Require("CombatMod/ModActive/Server/MerchantTest")

-- collect stats
Event.On("ScenarioEnded", function(scenario)
    table.insert(PersistentVars.History, {
        HardMode = PersistentVars.HardMode,
        SuperHardMode = PersistentVars.SuperHardMode,
        LoneWolfMode = PersistentVars.LoneWolfMode,
		GMMode = PersistentVars.GMMode,
        RogueScore = PersistentVars.RogueScore,
        Currency = PersistentVars.Currency,
        Scenario = {
            Enemies = table.size(scenario.KilledEnemies),
            Rounds = scenario.Round - 1,
            Map = scenario.Map.Name,
        },
    })
end)

