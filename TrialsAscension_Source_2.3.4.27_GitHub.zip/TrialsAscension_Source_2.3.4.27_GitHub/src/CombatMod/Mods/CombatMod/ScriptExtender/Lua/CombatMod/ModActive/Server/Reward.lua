Reward = Reward or {}

local function ensureState()
    -- V7.1: one shared virtual milestone currency. Migrate V7 GoblinTokens once.
    if type(PersistentVars.ConquestTokens) ~= "number" then PersistentVars.ConquestTokens = 0 end
    if not PersistentVars.ConquestTokensMigratedV71 then
        if type(PersistentVars.GoblinTokens) == "number" and PersistentVars.GoblinTokens > 0 then
            PersistentVars.ConquestTokens = PersistentVars.ConquestTokens + PersistentVars.GoblinTokens
            PersistentVars.GoblinTokens = 0
        end
        PersistentVars.ConquestTokensMigratedV71 = true
    end
    if type(PersistentVars.MilestoneRewards) ~= "table" then
        PersistentVars.MilestoneRewards = {}
    end
    if PersistentVars.MilestoneRewards.GoblinGear == nil then
        PersistentVars.MilestoneRewards.GoblinGear = false
    end
    if PersistentVars.MilestoneRewards.GoblinAgility == nil then
        PersistentVars.MilestoneRewards.GoblinAgility = false
    end
    if PersistentVars.MilestoneRewards.GoblinStinkyFinger == nil then
        PersistentVars.MilestoneRewards.GoblinStinkyFinger = false
    end
    if PersistentVars.MilestoneRewards.GnollHuntingPack == nil then
        PersistentVars.MilestoneRewards.GnollHuntingPack = false
    end
    if PersistentVars.MilestoneRewards.GnollPackBite == nil then
        PersistentVars.MilestoneRewards.GnollPackBite = false
    end
    if PersistentVars.MilestoneRewards.GnollPredatorEye == nil then
        PersistentVars.MilestoneRewards.GnollPredatorEye = false
    end
    for _, id in ipairs({"GithAstralArsenal","GithAstralParry","GithAstralMind","BOOOALCurrency","RG200SunGodSet","RG200RadiantSet","RG200TwilightSet"}) do
        if PersistentVars.MilestoneRewards[id] == nil then PersistentVars.MilestoneRewards[id] = false end
    end
end

-- V8.3G: dedicated custom RootTemplates for permanent Trials Ascension weapons.
-- These items no longer redirect shared vanilla RootTemplates at runtime.
local CUSTOM_WEAPON_ROOTS = {
    TOT_RG50_TROK_FANG = "4ab329ee-2ca8-4f13-8627-4200c55df155",
    TOT_RG100_ASTRAL_CROSSBOW = "8c8f7199-5f35-4e09-b4ab-d45bd3c2d595",
}

local function spawnDedicatedCustomWeapon(character, statName)
    local rootTemplate = CUSTOM_WEAPON_ROOTS[statName]
    if not rootTemplate then return nil end
    local x, y, z = Osi.GetPosition(character)
    local okCreate, guid = pcall(Osi.CreateAt, rootTemplate, x + (math.random() - 0.5) * 1.5, y, z + (math.random() - 0.5) * 1.5, 0, 1, "")
    if not okCreate then guid = nil end
    if guid and guid ~= "" then
        local ix, iy, iz = Osi.GetPosition(guid)
        Osi.RequestPing(ix, iy, iz, guid, "")
    end
    return guid
end

local function spawnGoblinGear(character)
    -- Same V6.3 FIX V2 item path, moved here unchanged so this test does not alter the gear itself.
    local function spawnCustom(statName, rootTemplate, vanillaStat, nameKey, nameHandle, descriptionHandle)
        local template = Ext.Template.GetRootTemplate(rootTemplate)
        if not template then return nil end
        local originalStat = template.Stats or vanillaStat
        local x, y, z = Osi.GetPosition(character)

        -- Shared vanilla RootTemplates are only redirected for the synchronous CreateAt call.
        -- The spawned entity then gets its own cache template, and the shared template is restored
        -- immediately (plus a second safety restore next tick).
        Event.Trigger("TemplateOverwrite", rootTemplate, "Stats", statName)
        local okCreate, guid = pcall(Osi.CreateAt, rootTemplate, x + (math.random() - 0.5) * 1.5, y, z + (math.random() - 0.5) * 1.5, 0, 1, "")
        Event.Trigger("TemplateOverwrite", rootTemplate, "Stats", originalStat)
        Defer(100, function() Event.Trigger("TemplateOverwrite", rootTemplate, "Stats", originalStat) end)

        if not okCreate then guid = nil end
        if guid and guid ~= "" then
            local entity = Ext.Entity.Get(guid)
            local serverItem = entity and entity.ServerItem
            if serverItem and serverItem.CreateCacheTemplate then
                local cached = serverItem:CreateCacheTemplate()
                if cached then
                    cached.Stats = statName
                    if cached.DisplayName and cached.DisplayName.Handle then
                        cached.DisplayName.Handle.Handle = nameHandle
                    end
                    if cached.Description and cached.Description.Handle then
                        cached.Description.Handle.Handle = descriptionHandle
                    end
                end
            end

            if Ext.Loca and Ext.Loca.UpdateTranslatedStringKey then
                Ext.Loca.UpdateTranslatedStringKey(nameKey, nameHandle)
                Osi.SetStoryDisplayName(guid, nameKey)
            end

            local ix, iy, iz = Osi.GetPosition(guid)
            Osi.RequestPing(ix, iy, iz, guid, "")
        end
        return guid
    end

    spawnDedicatedCustomWeapon(character, "TOT_RG50_TROK_FANG")
    spawnCustom("TOT_RG50_TOXIC_RAIDER_GARB", "55c7b18d-a117-5812-be0a-9b88db9e1a34", "MAG_BarbMonk_Defensive_Cloth", "TOT_RG50_TOXIC_RAIDER_GARB_NAME", "h6a10e020g5000g4000ga001g000000000020", "h6a10e021g5000g4000ga001g000000000021")
    spawnCustom("TOT_RG50_SCAVENGER_RING", "96a10f56-30bd-5d96-94dd-36ed97aacc05", "ARM_RingOfPoisonResistance", "TOT_RG50_SCAVENGER_RING_NAME", "h6a10e030g5000g4000ga001g000000000030", "h6a10e031g5000g4000ga001g000000000031")
end


local function spawnRewardItem(character, statName, rootTemplate, nameKey, nameHandle, descriptionHandle)
    local template = Ext.Template.GetRootTemplate(rootTemplate)
    if not template then return nil end
    local x,y,z = Osi.GetPosition(character)
    local okCreate, guid = pcall(Osi.CreateAt, rootTemplate, x + (math.random()-0.5)*1.2, y, z + (math.random()-0.5)*1.2, 0, 1, "")
    if not okCreate then guid=nil end
    if guid and guid ~= "" then
        if Ext.Loca and Ext.Loca.UpdateTranslatedStringKey then
            Ext.Loca.UpdateTranslatedStringKey(nameKey,nameHandle)
            Osi.SetStoryDisplayName(guid,nameKey)
        end
        local ix,iy,iz=Osi.GetPosition(guid); Osi.RequestPing(ix,iy,iz,guid,"")
    end
    return guid
end

local RG200_SET_ITEMS = {
    RG200SunGodSet = {
        {"TOT_SUN_GOD_SCIMITAR","4b094fdc-d3f1-5f77-a6e4-afb513999557","TOT_SUN_GOD_SCIMITAR_NAME","h74i00000000000000000000000000101","h74i00000000000000000000000000102"},
        {"TOT_SUN_GOD_CAPE","45d29e39-e5cb-5000-8cf2-a62a02590a2b","TOT_SUN_GOD_CAPE_NAME","h74i00000000000000000000000000111","h74i00000000000000000000000000112"},
        {"TOT_SUN_GOD_TUNIC","a1eb4411-a3e9-51e6-9cec-20cfd0dee0ce","TOT_SUN_GOD_TUNIC_NAME","h75g00000000000000000000000000101","h75g00000000000000000000000000102"},
        {"TOT_SUN_GOD_GLOVES","744bab7b-676b-513d-97d9-fddfc80a4eb1","TOT_SUN_GOD_GLOVES_NAME","h75g00000000000000000000000000111","h75g00000000000000000000000000112"},
        {"TOT_SUN_GOD_BOOTS","aaf2d61b-fa42-51ad-bed7-36a1fa5632d1","TOT_SUN_GOD_BOOTS_NAME","h75g00000000000000000000000000121","h75g00000000000000000000000000122"},
        {"TOT_SUN_GOD_RING","d3bc97eb-9344-51dd-a3fa-c3486095321b","TOT_SUN_GOD_RING_NAME","h75g00000000000000000000000000131","h75g00000000000000000000000000132"},
    },
    RG200RadiantSet = {
        {"TOT_RADIANT_GOD_MACE","3753b38f-1c1e-511f-aa15-4f82ba572e05","TOT_RADIANT_GOD_MACE_NAME","h75k00000000000000000000000000101","h75k00000000000000000000000000102"},
        {"TOT_DAWN_CROWN","6025b07a-8327-5cd7-9300-6b48a67309b5","TOT_DAWN_CROWN_NAME","h73a00000000000000000000000002021","h73a00000000000000000000000002022"},
        {"TOT_RADIANT_ARMOR","952fff3c-932a-5a8e-94c3-4c0ddd041391","TOT_RADIANT_ARMOR_NAME","h74p00000000000000000000000000101","h74p00000000000000000000000000102"},
        {"TOT_RADIANT_GLOVES","7e0bb90f-dc7c-5ab9-8c2e-576db2cfe7e6","TOT_RADIANT_GLOVES_NAME","h74p00000000000000000000000000111","h74p00000000000000000000000000112"},
        {"TOT_RADIANT_BOOTS","d711f7d4-8ff8-56c6-af24-b0d25f89f0ef","TOT_RADIANT_BOOTS_NAME","h74p00000000000000000000000000121","h74p00000000000000000000000000122"},
    },
    RG200TwilightSet = {
        {"TOT_TWILIGHT_STAFF","7fdb1116-8b0c-5c4b-aba0-31b9c8c18708","TOT_TWILIGHT_STAFF_NAME","h75j00000000000000000000000000101","h75j00000000000000000000000000102"},
        {"TOT_TWILIGHT_HELM","3a6f4f6a-aa2c-57ff-a6b3-fdc8470c6f26","TOT_TWILIGHT_HELM_NAME","h75j00000000000000000000000000111","h75j00000000000000000000000000112"},
        {"TOT_TWILIGHT_GLOVES","30ff8c75-3cd6-5ec2-9d34-821632917f5d","TOT_TWILIGHT_GLOVES_NAME","h75j00000000000000000000000000121","h75j00000000000000000000000000122"},
        {"TOT_TWILIGHT_RING","fd41fe4f-43b3-51df-8663-99a9ed466ab1","TOT_TWILIGHT_RING_NAME","h75j00000000000000000000000000131","h75j00000000000000000000000000132"},
        {"TOT_RADIANT_CAPE","73aaaf23-2e8b-53df-8eff-998c79156274","TOT_RADIANT_CAPE_NAME","h74p00000000000000000000000000131","h74p00000000000000000000000000132"},
    },
}

local function spawnRG200Set(character, id)
    for _,def in ipairs(RG200_SET_ITEMS[id] or {}) do
        spawnRewardItem(character, def[1], def[2], def[3], def[4], def[5])
    end
end

local Rewards = {
    GoblinGear = {
        Cost = 2,
        Requirement = "GoblinMilestone50Done",
        Character = false,
        OnBuy = function(character)
            spawnGoblinGear(character)
        end,
    },
    GoblinAgility = {
        Cost = 1,
        Requirement = "GoblinMilestone50Done",
        Character = true,
        OnBuy = function(character)
            Osi.AddPassive(character, "TOT_RG50_AGILITY_UNLOCK")
            Osi.ApplyStatus(character, "TOT_UI_RG50_AGILITY", -1, 1, character)
        end,
    },
    GoblinStinkyFinger = {
        Cost = 1,
        Requirement = "GoblinMilestone50Done",
        Character = true,
        OnBuy = function(character)
            Osi.AddPassive(character, "TOT_RG50_STINKY_FINGER_UNLOCK")
            Osi.ApplyStatus(character, "TOT_UI_RG50_STINKY_FINGER", -1, 1, character)
        end,
    },
    GnollHuntingPack = {
        Cost = 2,
        Requirement = "GnollMilestone75Done",
        Character = true,
        OnBuy = function(character)
            -- Give the ground-targeted summon spell instead of auto-casting it,
            -- so the player chooses where the pack appears.
            if Osi.HasPassive(character, "TOT_HuntingPackSummoner") ~= 1 then
                Osi.AddPassive(character, "TOT_HuntingPackSummoner")
            end
            Osi.ApplyStatus(character, "TOTR_HUNTING_PACK", -1, 1, character)
        end,
    },
    GnollPackBite = {
        Cost = 1,
        Requirement = "GnollMilestone75Done",
        Character = true,
        OnBuy = function(character)
            if Osi.HasPassive(character, "TOT_RG75_PACK_BITE_UNLOCK") ~= 1 then
                Osi.AddPassive(character, "TOT_RG75_PACK_BITE_UNLOCK")
            end
            Osi.ApplyStatus(character, "TOT_UI_RG75_PACK_BITE", -1, 1, character)
        end,
    },
    GnollPredatorEye = {
        Cost = 1, Requirement = "GnollMilestone75Done", Character = true,
        OnBuy = function(character)
            if Osi.HasPassive(character, "TOT_RG75_PREDATOR_EYE_UNLOCK") ~= 1 then Osi.AddPassive(character, "TOT_RG75_PREDATOR_EYE_UNLOCK") end
            Osi.ApplyStatus(character, "TOT_UI_RG75_PREDATOR_EYE", -1, 1, character)
        end,
    },
    GithAstralArsenal = {
        Cost = 3, Requirement = "GithMilestone100Done", Character = false,
        OnBuy = function(character)
            spawnDedicatedCustomWeapon(character,"TOT_RG100_ASTRAL_CROSSBOW")
            spawnRewardItem(character,"TOT_RG100_ASTRAL_CLOAK","83226058-e413-54be-8070-f28186679b3d","TOT_RG100_ASTRAL_CLOAK_NAME","h72a00000000000000000000000000313","h72a00000000000000000000000000314")
        end,
    },
    GithAstralParry = { Cost=1, Requirement="GithMilestone100Done", Character=true, OnBuy=function(character) if Osi.HasPassive(character,"TOT_ASTRAL_PARRY")~=1 then Osi.AddPassive(character,"TOT_ASTRAL_PARRY") end end },
    GithAstralMind = { Cost=1, Requirement="GithMilestone100Done", Character=true, OnBuy=function(character) if Osi.HasPassive(character,"TOT_ASTRAL_MIND")~=1 then Osi.AddPassive(character,"TOT_ASTRAL_MIND") end end },
    BOOOALArtifact = {
        Cost=3, Requirement="BOOOALMilestone150Done", Character=false,
        OnBuy=function(character) spawnRewardItem(character,"TOT_RG150_BOOOAL_AMULET","beb1b67e-680f-5726-90aa-59681caf9e66","TOT_RG150_BOOOAL_AMULET_NAME","h72a00000000000000000000000000411","h72a00000000000000000000000000412") end,
    },
    BOOOALCurrency = {
        Cost=1, Requirement="BOOOALMilestone150Done", Character=false,
        OnBuy=function(character)
            local newCurrency = (PersistentVars.Currency or 0) + 250
            if Unlock and Unlock.UpdateCurrency then
                Unlock.UpdateCurrency(newCurrency)
            else
                PersistentVars.Currency = newCurrency
            end
        end,
    },
    BOOOALDeepBlood = { Cost=1, Requirement="BOOOALMilestone150Done", Character=true, OnBuy=function(character) if Osi.HasPassive(character,"TOT_DEEP_BLOOD")~=1 then Osi.AddPassive(character,"TOT_DEEP_BLOOD") end end },
    RG200SunGodSet = { Cost=5, Requirement="ColossusMilestone200Done", Character=false, OnBuy=function(character) spawnRG200Set(character,"RG200SunGodSet") end },
    RG200RadiantSet = { Cost=5, Requirement="ColossusMilestone200Done", Character=false, OnBuy=function(character) spawnRG200Set(character,"RG200RadiantSet") end },
    RG200TwilightSet = { Cost=5, Requirement="ColossusMilestone200Done", Character=false, OnBuy=function(character) spawnRG200Set(character,"RG200TwilightSet") end },
}

function Reward.Buy(id, buyer, target)
    ensureState()

    local reward = Rewards[id]
    if not reward then
        return false, __("Reward not found.")
    end

    if Osi.IsInCombat(buyer) == 1 or Scenario.HasStarted() then
        return false, __("Cannot buy while in combat.")
    end

    if PersistentVars.MilestoneRewards[id] then
        return false, __("Reward already purchased.")
    end

    if reward.Requirement and not PersistentVars[reward.Requirement] then
        return false, Localization.Get("h71a00000000000000000000000000024")
    end

    if reward.Cost > PersistentVars.ConquestTokens then
        return false, Localization.Get("h71a00000000000000000000000000021")
    end

    local character = target or buyer
    reward.OnBuy(character)
    PersistentVars.ConquestTokens = math.max(0, PersistentVars.ConquestTokens - reward.Cost)
    PersistentVars.MilestoneRewards[id] = true

    Osi.PlaySoundResource(buyer, "a6571b9a-0b79-6712-6326-a0e3134ed0ad")
    Osi.ApplyStatus(buyer, "WAR_GODS_BLESSING", 1)
    if reward.Character then
        Osi.ApplyStatus(character, "WAR_GODS_BLESSING", 1)
    end

    SyncState()
    return true, PersistentVars.ConquestTokens
end


GameState.OnLoad(function()
    ensureState()
end)


function Reward.ResetPurchasesForDebug()
    ensureState()
    for id,_ in pairs(PersistentVars.MilestoneRewards) do PersistentVars.MilestoneRewards[id]=false end
    SyncState()
end

