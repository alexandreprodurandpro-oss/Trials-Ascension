Require("CombatMod/Shared")

Mod.PersistentVarsTemplate = {
    Asked = false,
    Active = false,
    RogueModeActive = false,
    RogueScenario = "",
    SpawnedEnemies = {},
    SpawnedItems = {},
    Scenario = {},
    Config = {},
    LastScenario = nil,
    RogueScore = 0,
    RunProgressionMode = "", -- empty until selection; non-nil sentinel is required so Hlib preserves it across reload/death
    RunProgressionLocked = false, -- selected progression speed cannot be changed during the run
    RunProgressionInitialBonusGranted = false, -- guards the one-time fast-run starting bonus
    RunDifficultyLocked = false, -- once a Roguelike run starts, Bias/Challenge/Hell cannot be changed until Roguelike is disabled
    GoblinMilestone100Done = false, -- legacy V6.1 flag retained for save compatibility; no longer used
    GoblinMilestone50Done = false, -- RG50 Goblin Raid completed
    GnollMilestone75Done = false, -- RG75 Gnoll Hunt completed
    GithMilestone100Done = false, -- RG100 Githyanki Patrol completed
    BOOOALMilestone150Done = false, -- RG150 Cult of BOOOAL completed
    ColossusMilestone200Done = false, -- RG200 La Fosse des Colosses completed
    ConquestTokens = 0, -- shared virtual milestone currency; never exists as an inventory item
    GoblinTokens = 0, -- legacy V7 token field retained only for one-time migration
    ConquestTokensMigratedV71 = false,
    MilestoneRewards = {
        GoblinGear = false,
        GoblinAgility = false,
        GoblinStinkyFinger = false,
        GnollHuntingPack = false,
        GnollPackBite = false,
        GnollPredatorEye = false,
        GithAstralArsenal = false,
        GithAstralParry = false,
        GithAstralMind = false,
    },
    Contracts = { Kills=0, BossKills=0, Combats=0, PerfectClears=0, NoRestStreak=0, AsmodeusKills=0, SimulatedLevel=0, Completed={} },
    DivineRewardsUnlocked = false,
    SummonsAutomatic = true,
    RegionalProgressionEnabled = true, -- groups normal encounters by act to reduce level-load churn
    LockedCampId = nil, -- Trials Ascension main camp; constrained by RogueScore while regional progression is enabled
    MerchantTestGUID = nil, -- Bromdir Poing-d’Or merchant spawned near Withers in camp
    MerchantTestStocked = false, -- legacy V0 field retained for save compatibility
    MerchantStockInitialized = false, -- true after Bromdir receives his first generated stock
    MerchantStockGeneration = 0, -- incremented on each long-rest restock
    MerchantInventorySnapshot = {}, -- exact current Bromdir inventory, restored only if NPC instance is recreated
    Jam4 = { -- secret creator Easter Egg; successful quiz parks Jam4_ as a camp NPC (recruitment paused)
        State = "NotMet",
        GUID = nil,
        Recruited = false,
        AtCamp = false,
        Failed = false,
        EnemyPending = false, -- failed quiz schedules one level-12 punishment encounter
        EligibleCombats = 0,
        QuizStep = 0,
        QuizPlayer = nil,
    },
    HardMode = false, -- applies additional difficulty to the game
    LoneWolfMode = false, -- rebalanced enemy tiers and placement for solo players
	GMMode = false, -- host controls monsters, is not counted in scaling functions
	GameMaster = "",
    SuperHardMode = false,
    GUIOpen = false,
    History = {},
    RandomLog = { -- log last random values to prevent repeating the same
        Maps = {},
        Items = {},
    },
    LootFilter = {
        CombatObject = table.map(C.ItemRarity, function(v, k)
            return true, v
        end),
        Object = table.map(C.ItemRarity, function(v, k)
            return true, v
        end),
        Armor = table.map(C.ItemRarity, function(v, k)
            return v ~= "Common", v
        end),
        Weapon = table.map(C.ItemRarity, function(v, k)
            return v ~= "Common", v
        end),
    },
    Currency = 0,
    RegionsCleared = {},
    Unlocked = {
        ExpMultiplier = false,
        LootMultiplier = false,
        CurrencyMultiplier = false,
        RogueScoreMultiplier = false,
    },
    Unlocks = {},
}

DefaultConfig = {
    BypassStory = true, -- skip dialogues, combat and interactions that aren't related to a scenario
    LootIncludesCampSlot = false, -- include camp clothes in item lists
    Debug = false,
    RandomizeSpawnOffset = 3,
    ExpMultiplier = 3,
    SpawnItemsAtPlayer = false,
    GroupDistantEnemies = false,
    TurnOffNotifications = false,
    ClearAllEntities = true,
    AutoResurrect = true,
    MulitplayerRestrictUnlocks = false,
    AutoTeleport = 30,
    ScalingModifier = 30,
}
Config = table.deepclone(DefaultConfig)

-- V8.4Z15: run-speed helper. Classic is exactly the base behavior.
-- Fast modes scale only normal progression; unique rewards and Conquest Tokens stay untouched.
RunMode = RunMode or {}
RunMode.CLASSIC = "Classic"
RunMode.ACCELERATED = "Accelerated"
RunMode.EXPRESS = "Express"
RunMode.ACCELERATED_MULTIPLIER = 1.75
RunMode.EXPRESS_MULTIPLIER = 2.50

function RunMode.Multiplier()
    if not PersistentVars then return 1.0 end
    if PersistentVars.RunProgressionMode == RunMode.EXPRESS then
        return RunMode.EXPRESS_MULTIPLIER
    elseif PersistentVars.RunProgressionMode == RunMode.ACCELERATED then
        return RunMode.ACCELERATED_MULTIPLIER
    end
    return 1.0
end

function RunMode.Scale(value)
    local n = tonumber(value) or 0
    return math.floor((n * RunMode.Multiplier()) + 0.5)
end

External = {}
Templates = {}

Require("CombatMod/Server/External")

External.LoadConfig()
External.File.ExportIfNeeded("Config", Config)

External.LoadLootRates()

Intro = {}
Player = {}
Commands = {}

Require("CombatMod/Server/Intro")
Require("CombatMod/Server/Player")
Require("CombatMod/Server/Commands")
Require("CombatMod/Server/ModEvents")

GameState.OnLoad(function()
    External.LoadConfig()
    local tutorialCC = GU.DB.TryGet("DB_TUT_CharacterCreation_Started", 1, nil, 1)[1]
    if PersistentVars.Asked == false and not tutorialCC then
        Intro.AskOnboarding()
    end
    PersistentVars.Asked = PersistentVars.Active

    if not eq(PersistentVars.Config, {}) then
        External.ApplyConfig(table.filter(PersistentVars.Config, function(v, k)
            return k ~= "Dev" and k ~= "Debug"
        end, true))
    end
end, true)

ModEvent.Register("ModInit")


local ATT_MIN_VERSION = { 1, 1, 9, 2 }
local ATT_MOD_UUID = "fa49db03-caa7-49c8-7c76-e6c38b60267a"

local function versionAtLeast(version, minimum)
    if type(version) ~= "table" then
        return false
    end

    for i = 1, #minimum do
        local current = tonumber(version[i]) or 0
        local required = tonumber(minimum[i]) or 0

        if current > required then
            return true
        elseif current < required then
            return false
        end
    end

    return true
end

local function checkAdvancedTabletopSpells()
    if not Ext.Mod.IsModLoaded(ATT_MOD_UUID) then
        Player.AskConfirmation(TA_Text([[
AdvancedTabletopSpells is not loaded.
Trials Ascension requires AdvancedTabletopSpells 1.1.9.2 or newer.

Please quit the game, install the dependency, then restart Baldur's Gate 3.]], [[
AdvancedTabletopSpells n'est pas chargé.
Trials Ascension nécessite AdvancedTabletopSpells 1.1.9.2 ou une version supérieure.

Veuillez quitter le jeu, installer la dépendance, puis relancer Baldur's Gate 3.]]))
        return false
    end

    local mod = Ext.Mod.GetMod(ATT_MOD_UUID)
    local attInfo = mod and mod.Info or nil
    local version = attInfo and attInfo.ModVersion or nil

    if not versionAtLeast(version, ATT_MIN_VERSION) then
        local found = version and string.format(
            "%d.%d.%d.%d",
            tonumber(version[1]) or 0,
            tonumber(version[2]) or 0,
            tonumber(version[3]) or 0,
            tonumber(version[4]) or 0
        ) or TA_Text("unknown", "inconnue")

        Player.AskConfirmation(TA_Text(
            "The loaded version of AdvancedTabletopSpells is too old (" .. found .. ").\n\n" ..
            "Trials Ascension requires AdvancedTabletopSpells 1.1.9.2 or newer.",
            "La version d'AdvancedTabletopSpells chargée est trop ancienne (" .. found .. ").\n\n" ..
            "Trials Ascension nécessite AdvancedTabletopSpells 1.1.9.2 ou une version supérieure."
        ))
        return false
    end

    return true
end

local isActive = false
function IsActive()
    return isActive
end

local function init()
    if isActive then
        return
    end
    isActive = true

	checkAdvancedTabletopSpells()
		

    Require("CombatMod/ModActive/Server/_Init")

    Event.Trigger(GameState.EventLoad)

    L.Info(L.RainbowText(Mod.Prefix .. " is now active. Have fun!"))

    Event.Trigger("ModInit")
end

Event.On("ModActive", function()
    if not PersistentVars.Active then
        Player.Notify(__("%s is now active.", Mod.Prefix), true)
    end

    PersistentVars.Active = true

    init()
end, true)

Event.On("ModActive", function()
    -- client only listens once for this event
    Net.Send("ModActive")
end)

GameState.OnLoad(function()
    L.Debug("Check if mod is active", PersistentVars.Active)
    if PersistentVars.Active then
        Event.Trigger("ModActive")
		checkAdvancedTabletopSpells()
    end
end)

Require("CombatMod/Overwrites")
