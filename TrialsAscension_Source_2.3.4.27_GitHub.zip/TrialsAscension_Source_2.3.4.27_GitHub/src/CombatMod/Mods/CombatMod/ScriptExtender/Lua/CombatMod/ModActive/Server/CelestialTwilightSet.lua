CelestialTwilightSet = CelestialTwilightSet or {}

-- V7.5J: five-piece Celestial Twilight set.
-- The cloak is the already existing TOT_RADIANT_CAPE (displayed as Celestial Twilight Cloak).
local SET = {
    ["Helmet"] = "TOT_TWILIGHT_HELM",
    ["Gloves"] = "TOT_TWILIGHT_GLOVES",
    ["Cloak"] = "TOT_RADIANT_CAPE",
}

local TIERS = {
    {Count=3, Passive="TOT_TWILIGHT_SET_3_PASSIVE", Status="TOT_TWILIGHT_SET_3_STATUS"},
    {Count=5, Passive="TOT_TWILIGHT_SET_5_PASSIVE", Status="TOT_TWILIGHT_SET_5_STATUS"},
}

local function equippedStat(character, slot)
    local guid = Osi.GetEquippedItem(character, slot)
    if not guid or guid == "" then return nil end
    local entity = Ext.Entity.Get(guid)
    return entity and entity.ServerItem and entity.ServerItem.Stats or nil
end

function CelestialTwilightSet.CountPieces(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return 0 end
    local count = 0
    for slot, stat in pairs(SET) do
        if equippedStat(character, slot) == stat then count = count + 1 end
    end
    -- Set weapons count in either hand, but only once.
    if equippedStat(character, "Melee Main Weapon") == "TOT_TWILIGHT_STAFF"
        or equippedStat(character, "Melee Offhand Weapon") == "TOT_TWILIGHT_STAFF" then
        count = count + 1
    end
    if equippedStat(character, "Ring") == "TOT_TWILIGHT_RING" or equippedStat(character, "Ring2") == "TOT_TWILIGHT_RING" then
        count = count + 1
    end
    return count
end

local function setTier(character, tier, active)
    if active then
        if Osi.HasPassive(character, tier.Passive) ~= 1 then Osi.AddPassive(character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) ~= 1 then Osi.ApplyStatus(character, tier.Status, -1, 1, character) end
    else
        if Osi.HasPassive(character, tier.Passive) == 1 then Osi.RemovePassive(character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) == 1 then Osi.RemoveStatus(character, tier.Status) end
    end
end

function CelestialTwilightSet.Update(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return end
    local count = CelestialTwilightSet.CountPieces(character)
    for _, tier in ipairs(TIERS) do setTier(character, tier, count >= tier.Count) end
end

local function scheduledUpdate(character)
    Schedule(function() CelestialTwilightSet.Update(character) end)
end

Ext.Osiris.RegisterListener("Equipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("Unequipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    for _, character in pairs(GU.DB.GetPlayers()) do CelestialTwilightSet.Update(character) end
end)
Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character) scheduledUpdate(character) end)

GameState.OnLoad(function()
    Schedule(function()
        for _, character in pairs(GU.DB.GetPlayers()) do CelestialTwilightSet.Update(character) end
    end)
end, true)
