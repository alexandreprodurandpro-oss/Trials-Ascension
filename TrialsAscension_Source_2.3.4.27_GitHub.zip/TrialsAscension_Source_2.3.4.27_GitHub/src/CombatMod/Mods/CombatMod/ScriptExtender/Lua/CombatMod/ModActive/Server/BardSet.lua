BardSet = BardSet or {}

-- Trials Ascension V8.4Q - one bonus only, active at 4/4 pieces.
local PIECES = {
    Helmet = "TOT_BARD_VIRTUOSO_CAP",
    Gloves = "TOT_BARD_MAESTRO_GLOVES",
    Boots = "TOT_BARD_ENCORE_BOOTS",
}
local WEAPON = "TOT_BARD_HARMONIC_DUELIST"
local PASSIVE = "TOT_BARD_SET_4_PASSIVE"
local STATUS = "TOT_BARD_SET_4_STATUS"

local function equippedStat(character, slot)
    local guid = Osi.GetEquippedItem(character, slot)
    if not guid or guid == "" then return nil end
    local entity = Ext.Entity.Get(guid)
    return entity and entity.ServerItem and entity.ServerItem.Stats or nil
end

function BardSet.CountPieces(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return 0 end
    local count = 0
    for slot, stat in pairs(PIECES) do
        if equippedStat(character, slot) == stat then count = count + 1 end
    end
    if equippedStat(character, "Melee Main Weapon") == WEAPON
        or equippedStat(character, "Melee Offhand Weapon") == WEAPON then
        count = count + 1
    end
    return count
end

function BardSet.Update(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return end
    local active = BardSet.CountPieces(character) >= 4
    if active then
        if Osi.HasPassive(character, PASSIVE) ~= 1 then Osi.AddPassive(character, PASSIVE) end
        if Osi.HasAppliedStatus(character, STATUS) ~= 1 then Osi.ApplyStatus(character, STATUS, -1, 1, character) end
    else
        if Osi.HasPassive(character, PASSIVE) == 1 then Osi.RemovePassive(character, PASSIVE) end
        if Osi.HasAppliedStatus(character, STATUS) == 1 then Osi.RemoveStatus(character, STATUS) end
    end
end

local function scheduledUpdate(character)
    Schedule(function() BardSet.Update(character) end)
end

Ext.Osiris.RegisterListener("Equipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("Unequipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    for _, character in pairs(GU.DB.GetPlayers()) do BardSet.Update(character) end
end)
GameState.OnLoad(function()
    Schedule(function()
        for _, character in pairs(GU.DB.GetPlayers()) do BardSet.Update(character) end
    end)
end, true)
