SunGodSet = SunGodSet or {}

-- V7.5G: six-piece Sun God set currently consists of:
-- scimitar, cloak, tunic, gloves, boots and ring.
local SET = {
    ["Cloak"] = "TOT_SUN_GOD_CAPE",
    ["Breast"] = "TOT_SUN_GOD_TUNIC",
    ["Gloves"] = "TOT_SUN_GOD_GLOVES",
    ["Boots"] = "TOT_SUN_GOD_BOOTS",
}

local TIERS = {
    {Count=3, Passive="TOT_SUN_SET_3_PASSIVE", Status="TOT_SUN_SET_3_STATUS"},
    {Count=5, Passive="TOT_SUN_SET_5_PASSIVE", Status="TOT_SUN_SET_5_STATUS"},
    {Count=6, Passive="TOT_SUN_SET_6_PASSIVE", Status="TOT_SUN_SET_6_STATUS"},
}

local function equippedStat(character, slot)
    local guid = Osi.GetEquippedItem(character, slot)
    if not guid or guid == "" then return nil end
    local entity = Ext.Entity.Get(guid)
    return entity and entity.ServerItem and entity.ServerItem.Stats or nil
end

function SunGodSet.CountPieces(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return 0 end
    local count = 0
    for slot, stat in pairs(SET) do
        if equippedStat(character, slot) == stat then count = count + 1 end
    end
    -- Set weapons count in either hand, but only once.
    if equippedStat(character, "Melee Main Weapon") == "TOT_SUN_GOD_SCIMITAR"
        or equippedStat(character, "Melee Offhand Weapon") == "TOT_SUN_GOD_SCIMITAR" then
        count = count + 1
    end
    -- Rings can occupy either ring slot, but the set ring counts only once.
    if equippedStat(character, "Ring") == "TOT_SUN_GOD_RING" or equippedStat(character, "Ring2") == "TOT_SUN_GOD_RING" then
        count = count + 1
    end
    return count
end

local function setTier(character, tier, active)
    if active then
        if Osi.HasPassive(character, tier.Passive) ~= 1 then Osi.AddPassive(character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) ~= 1 then Osi.ApplyStatus(character, tier.Status, -1, 1, character) end
    else
        if Osi.HasPassive(character, tier.Passive) == 1 then Osi.RemovePassive(character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) == 1 then Osi.RemoveStatus(character, tier.Status) end
    end
end

function SunGodSet.Update(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return end
    local count = SunGodSet.CountPieces(character)
    for _, tier in ipairs(TIERS) do
        setTier(character, tier, count >= tier.Count)
    end
end

local function scheduledUpdate(character)
    Schedule(function() SunGodSet.Update(character) end)
end

-- Native Osiris equipment events: refresh immediately after changing gear.
Ext.Osiris.RegisterListener("Equipped", 2, "after", function(_, character)
    scheduledUpdate(character)
end)
Ext.Osiris.RegisterListener("Unequipped", 2, "after", function(_, character)
    scheduledUpdate(character)
end)

-- Safety refreshes for load/rest/party changes; these never grant a tier unless
-- the required pieces are actually equipped.
Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    for _, character in pairs(GU.DB.GetPlayers()) do
        SunGodSet.Update(character)
    end
end)
Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character)
    scheduledUpdate(character)
end)

GameState.OnLoad(function()
    Schedule(function()
        for _, character in pairs(GU.DB.GetPlayers()) do
            SunGodSet.Update(character)
        end
    end)
end, true)
