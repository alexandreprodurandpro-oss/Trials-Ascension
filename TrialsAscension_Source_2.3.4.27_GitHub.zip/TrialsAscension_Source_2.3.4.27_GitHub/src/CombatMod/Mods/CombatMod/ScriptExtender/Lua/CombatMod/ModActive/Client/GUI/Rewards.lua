Rewards = {}

local H = {
    Tab = "h6a10e101g5000g4000ga001g000000000101",
    Owned = "h71a00000000000000000000000000001",
    TokenCost = "h71a00000000000000000000000000002",
    Purchased = "h6a10e108g5000g4000ga001g000000000108",
    Buy = "h6a10e109g5000g4000ga001g000000000109",
    ChooseCharacter = "h6a10e110g5000g4000ga001g000000000110",
    Permanent = "h6a10e111g5000g4000ga001g000000000111",
    Stackable = "h6a10e112g5000g4000ga001g000000000112",
    Affects = "h6a10e113g5000g4000ga001g000000000113",
    Effect = "h6a10e114g5000g4000ga001g000000000114",
    LongRest = "h71a00000000000000000000000000003",
    Yes = "h6a10e115g5000g4000ga001g000000000115",
    No = "h6a10e116g5000g4000ga001g000000000116",
    Character = "h6a10e117g5000g4000ga001g000000000117",
    Equipment = "h6a10e118g5000g4000ga001g000000000118",
    WeaponsUnarmed = "h6a10e119g5000g4000ga001g000000000119",
    Summon = "h71a00000000000000000000000000004",
    Attacks = "h71a00000000000000000000000000005",
    ReSummon = "h71a00000000000000000000000000006",
    GoblinSection = "h84i00000000000000000000000000101",
    GoblinVictory = "h84i00000000000000000000000000102",
    GoblinLocked = "h84i00000000000000000000000000103",
    GoblinGain = "h84i00000000000000000000000000104",
    GnollSection = "h84i00000000000000000000000000111",
    GnollVictory = "h84i00000000000000000000000000112",
    GnollLocked = "h84i00000000000000000000000000113",
    GnollGain = "h84i00000000000000000000000000114",
    EffectGear = "h6a10e120g5000g4000ga001g000000000120",
    EffectAgility = "h6a10e121g5000g4000ga001g000000000121",
    EffectStinky = "h6a10e122g5000g4000ga001g000000000122",
    EffectPack = "h71a00000000000000000000000000013",
    EffectPackBite = "h71a00000000000000000000000000014",
    EffectPredatorEye = "h71a00000000000000000000000000015",
    GithSection="h84i00000000000000000000000000121", GithVictory="h84i00000000000000000000000000122", GithLocked="h84i00000000000000000000000000123", GithGain="h84i00000000000000000000000000124",
    BOOOALSection="h84i00000000000000000000000000141", BOOOALVictory="h84i00000000000000000000000000142", BOOOALLocked="h84i00000000000000000000000000143", BOOOALGain="h84i00000000000000000000000000144",
    EffectBOOOALArtifact="h72a00000000000000000000000000614", EffectBOOOALCurrency="h72a00000000000000000000000000615", EffectDeepBlood="h72a00000000000000000000000000616",
    RG200Section="h84i00000000000000000000000000151", RG200Victory="h84i00000000000000000000000000152", RG200Locked="h84i00000000000000000000000000153", RG200Gain="h84i00000000000000000000000000154",
}

local Sections = {
    {
        Title = H.GoblinSection,
        DoneField = "GoblinMilestone50Done",
        Victory = H.GoblinVictory,
        Gain = H.GoblinGain,
        Locked = H.GoblinLocked,
        Rewards = {
            { Id="GoblinGear", RequiredField="GoblinMilestone50Done", NameHandle="h6a10e001g5000g4000ga001g000000000001", DescHandle="h6a10e002g5000g4000ga001g000000000002", Icon="Item_WPN_HUM_Dagger_A_2", Cost=2, Character=false, AffectsHandle=H.Equipment, EffectHandle=H.EffectGear },
            { Id="GoblinAgility", RequiredField="GoblinMilestone50Done", NameHandle="h6a10e003g5000g4000ga001g000000000003", DescHandle="h6a10e004g5000g4000ga001g000000000004", Icon="Action_Jump", Cost=1, Character=true, AffectsHandle=H.Character, EffectHandle=H.EffectAgility },
            { Id="GoblinStinkyFinger", RequiredField="GoblinMilestone50Done", NameHandle="h6a10e005g5000g4000ga001g000000000005", DescHandle="h6a10e006g5000g4000ga001g000000000006", Icon="Spell_Necromancy_RayOfSickness", Cost=1, Character=true, AffectsHandle=H.WeaponsUnarmed, EffectHandle=H.EffectStinky },
        },
    },
    {
        Title = H.GnollSection,
        DoneField = "GnollMilestone75Done",
        Victory = H.GnollVictory,
        Gain = H.GnollGain,
        Locked = H.GnollLocked,
        Rewards = {
            { Id="GnollHuntingPack", RequiredField="GnollMilestone75Done", NameHandle="h71a00000000000000000000000000030", DescHandle="h71a00000000000000000000000000031", Icon="Spell_Enchantment_DominateBeast", Cost=2, Character=true, AffectsHandle=H.Summon, EffectHandle=H.EffectPack, LongRestHandle=H.ReSummon },
            { Id="GnollPackBite", RequiredField="GnollMilestone75Done", NameHandle="h71a00000000000000000000000000032", DescHandle="h71a00000000000000000000000000033", Icon="statIcons_BoooalsBenediction", Cost=1, Character=true, AffectsHandle=H.WeaponsUnarmed, EffectHandle=H.EffectPackBite },
            { Id="GnollPredatorEye", RequiredField="GnollMilestone75Done", NameHandle="h71a00000000000000000000000000034", DescHandle="h71a00000000000000000000000000035", Icon="PassiveFeature_Generic_Blood", Cost=1, Character=true, AffectsHandle=H.Attacks, EffectHandle=H.EffectPredatorEye },
        },
    },
    {
        Title=H.GithSection, DoneField="GithMilestone100Done", Victory=H.GithVictory, Locked=H.GithLocked, Gain=H.GithGain,
        Rewards={
            {Id="GithAstralArsenal",RequiredField="GithMilestone100Done",NameHandle="h72a00000000000000000000000000301",DescHandle="h72a00000000000000000000000000302",Icon="Item_WPN_HUM_HandCrossbow_A_1",Cost=3,Character=false,AffectsHandle=H.Equipment,EffectHandle=H.EffectAstralArsenal},
            {Id="GithAstralParry",RequiredField="GithMilestone100Done",NameHandle="h72a00000000000000000000000000321",DescHandle="h72a00000000000000000000000000322",Icon="PassiveFeature_Parry",Cost=1,Character=true,AffectsHandle=H.Character,EffectHandle=H.EffectAstralParry},
            {Id="GithAstralMind",RequiredField="GithMilestone100Done",NameHandle="h72a00000000000000000000000000331",DescHandle="h72a00000000000000000000000000332",Icon="Spell_Divination_DetectThoughts",Cost=1,Character=true,AffectsHandle=H.Character,EffectHandle=H.EffectAstralMind},
        },
    },
    {
        Title=H.BOOOALSection, DoneField="BOOOALMilestone150Done", Victory=H.BOOOALVictory, Locked=H.BOOOALLocked, Gain=H.BOOOALGain,
        Rewards={
            {Id="BOOOALArtifact",RequiredField="BOOOALMilestone150Done",NameHandle="h72a00000000000000000000000000401",DescHandle="h72a00000000000000000000000000402",Icon="Spell_Necromancy_Blight",Cost=3,Character=false,AffectsHandle=H.Equipment,EffectHandle=H.EffectBOOOALArtifact},
            {Id="BOOOALCurrency",RequiredField="BOOOALMilestone150Done",NameHandle="h72a00000000000000000000000000421",DescHandle="h72a00000000000000000000000000422",Icon="Item_LOOT_COINS_Electrum_Pile_Small_A",Cost=1,Character=false,EffectHandle=H.EffectBOOOALCurrency},
            {Id="BOOOALDeepBlood",RequiredField="BOOOALMilestone150Done",NameHandle="h72a00000000000000000000000000431",DescHandle="h72a00000000000000000000000000432",Icon="Spell_Abjuration_DispelMagic",Cost=1,Character=true,AffectsHandle=H.Character,EffectHandle=H.EffectDeepBlood},
        },
    },
    {
        Title=H.RG200Section, DoneField="ColossusMilestone200Done", Victory=H.RG200Victory, Locked=H.RG200Locked, Gain=H.RG200Gain,
        Rewards={
            {Id="RG200SunGodSet",RequiredField="ColossusMilestone200Done",NameHandle="h75k00000000000000000000000000311",DescHandle="h75k00000000000000000000000000312",Icon="Spell_Evocation_Fireball",Cost=5,Character=false,AffectsHandle=H.Equipment},
            {Id="RG200RadiantSet",RequiredField="ColossusMilestone200Done",NameHandle="h75k00000000000000000000000000321",DescHandle="h75k00000000000000000000000000312",Icon="Spell_Evocation_Sunbeam",Cost=5,Character=false,AffectsHandle=H.Equipment},
            {Id="RG200TwilightSet",RequiredField="ColossusMilestone200Done",NameHandle="h75k00000000000000000000000000331",DescHandle="h75k00000000000000000000000000312",Icon="Spell_Evocation_ConeOfCold",Cost=5,Character=false,AffectsHandle=H.Equipment},
        },
    },
}

local function buyRequest(reward, character, button)
    button:SetStyle("Alpha", 0.2)
    Net.Request("BuyMilestoneReward", { Id = reward.Id, Character = character }):After(function(event)
        local ok, res = table.unpack(event.Payload)
        if not ok then Event.Trigger("Error", res) else Event.Trigger("Success", Localization.Get(reward.NameHandle)) end
        pcall(function() button:SetStyle("Alpha", 1) end)
    end)
end

local function addBuyForCharacter(root, reward, button)
    local popup = root:AddPopup("")
    popup.IDContext = U.RandomId()
    popup:AddSeparatorText(Localization.Get(H.ChooseCharacter))

    -- V7.2: rebuild the list every time the selector opens. At initial GUI creation
    -- GE.GetPCs() can still be incomplete (especially companions); a static list
    -- therefore went stale until a later entity refresh / Long Rest.
    local list = {}
    local function rebuild()
        for _, child in pairs(list) do
            pcall(function() child:Destroy() end)
        end
        list = {}
        for _, u in ipairs(ClientUnlock.GetCharacters()) do
            local name = u.CustomName and u.CustomName.Name or Localization.Get(u.DisplayName.NameKey.Handle.Handle)
            local uuid = u.Uuid.EntityUuid
            local b = popup:AddButton("  " .. name .. "  ")
            b.IDContext = U.RandomId()
            table.insert(list, b)
            b.OnClick = function() buyRequest(reward, uuid, b) end
        end
    end

    button.OnClick = function()
        rebuild()
        popup:Open()
    end
end

local function addDetailLine(root, labelHandle, valueHandle)
    if not valueHandle then return end
    local row = root:AddGroup(U.RandomId())
    row:AddText(Localization.Get(labelHandle))
    local value = row:AddText(Localization.Get(valueHandle)); value.SameLine = true
end

local function tile(root, reward, visualIndex)
    local grp = CombatTheme.Card(root, "RewardCard_" .. reward.Id, visualIndex or 1, 222)
    local desc = Localization.Get(reward.DescHandle)
    local name = grp:AddText(Localization.Get(reward.NameHandle))
    local nameTip = name:Tooltip(); nameTip:SetStyle("WindowPadding", 30, 10); nameTip:AddText(desc)
    grp:AddDummy(1, 3)
    local icon = grp:AddImage(reward.Icon, {64,64})
    local tip = icon:Tooltip(); tip:SetStyle("WindowPadding", 30, 10); tip:AddText(desc)
    grp:AddText(string.format(Localization.Get(H.TokenCost), reward.Cost))
    local status = grp:AddText("")
    local btn = grp:AddButton(Localization.Get(H.Buy)); btn.IDContext=U.RandomId(); btn.Label="    "..Localization.Get(H.Buy).."    "
    if reward.Character then addBuyForCharacter(grp,reward,btn) else btn.OnClick=function() buyRequest(reward,nil,btn) end end
    grp:AddSeparator()
    addDetailLine(grp,H.Permanent,H.Yes)
    addDetailLine(grp,H.Stackable,H.No)
    addDetailLine(grp,H.Affects,reward.AffectsHandle)
    addDetailLine(grp,H.Effect,reward.EffectHandle)
    addDetailLine(grp,H.LongRest,reward.LongRestHandle)
    local function update(state)
        local isBought=(state.MilestoneRewards ~= nil and state.MilestoneRewards[reward.Id] == true)
        local unlocked = (not reward.RequiredField) or state[reward.RequiredField] == true
        status.Label=isBought and Localization.Get(H.Purchased) or ""
        status.Visible=isBought
        btn.Visible=(not isBought) and unlocked
    end
    Event.On("StateChange",update):Exec(State)
end

local function addSection(root, section)
    root:AddSeparatorText(Localization.Get(section.Title))
    local status=root:AddText("")
    local function statusText(state) return Localization.Get(state[section.DoneField] and section.Victory or section.Locked) end
    Components.Computed(status,function(_,state) return statusText(state) end,"StateChange")
    if State then status.Label=statusText(State) end
    if section.Gain then
        local gain = root:AddText(Localization.Get(section.Gain))
        gain:SetColor("Text", { 0.86, 0.70, 0.30, 1.00 })
    end
    root:AddDummy(1,6)
    Components.Layout(root,3,1,function(layout)
        layout.Table.Borders=true
        for i,reward in ipairs(section.Rewards) do tile(layout.Cells[1][i],reward,i) end
    end)
    root:AddDummy(1,10)
end

function Rewards.Main(tab)
    local root=tab:AddTabItem(Localization.Get(H.Tab)):AddChildWindow(""):AddGroup("")
    root.PositionOffset={5,5}
    local owned=root:AddSeparatorText("")
    Components.Computed(owned,function(_,state) return string.format(Localization.Get(H.Owned),state.ConquestTokens or state.GoblinTokens or 0) end,"StateChange")
    if State then owned.Label=string.format(Localization.Get(H.Owned),State.ConquestTokens or State.GoblinTokens or 0) end
    for _,section in ipairs(Sections) do addSection(root,section) end
end
