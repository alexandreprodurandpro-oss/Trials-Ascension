local function TrialsAscensionGodName()
    local buy = __("Buy")
    if buy == "Acheter" then return "Dieu de l'Ascension" end
    return "God of Ascension"
end

local function getUnlocks()
    return Unlock.Get()
end

-- Custom unlock: Maître des invocations.
-- V6 uses a native owner aura with SummonOwner(...) instead of polling every character each turn.
-- Keep this small compatibility helper so old saves that already own the passive receive the aura marker.
local function ensureSummonMasterAura(character)
    if Osi.HasPassive(character, "TOT_SUMMON_MASTER_OWNER") == 1
        and Osi.HasAppliedStatus(character, "TOT_SUMMON_MASTER_AURA") ~= 1 then
        Osi.ApplyStatus(character, "TOT_SUMMON_MASTER_AURA", -1, 1, character)
    end
end


-- V6 UI polish: older saves may already own the passive without its visible marker.
local function refreshCustomUnlockMarkers(character)
    if Osi.HasPassive(character, "TOT_ACTION_POINT_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_ACTION_POINT") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_ACTION_POINT", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_ASSASSIN_MASTERY_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_ASSASSIN_MASTERY") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_ASSASSIN_MASTERY", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_LIVING_BULWARK_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_LIVING_BULWARK") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_LIVING_BULWARK", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_MACABRE_FAVOR_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_MACABRE_FAVOR") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_MACABRE_FAVOR", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_RG50_AGILITY_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_RG50_AGILITY") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_RG50_AGILITY", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_RG50_STINKY_FINGER_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_RG50_STINKY_FINGER") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_RG50_STINKY_FINGER", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_RG75_PACK_BITE_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_RG75_PACK_BITE") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_RG75_PACK_BITE", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_RG75_PREDATOR_EYE_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_UI_RG75_PREDATOR_EYE") ~= 1 then
        Osi.ApplyStatus(character, "TOT_UI_RG75_PREDATOR_EYE", -1, 1, character)
    end
    -- V7.4W: real mechanics are permanent passives; these statuses are UI-only.
    if Osi.HasPassive(character, "TOT_ARCANE_ESSENCE_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_ARCANE_ESSENCE_001") ~= 1 then
        Osi.ApplyStatus(character, "TOT_ARCANE_ESSENCE_001", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_CEREBRAL_EROSION_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_CEREBRAL_EROSION_001") ~= 1 then
        Osi.ApplyStatus(character, "TOT_CEREBRAL_EROSION_001", -1, 1, character)
    end
    if Osi.HasPassive(character, "TOT_PRIMORDIAL_SAP_UNLOCK") == 1 and Osi.HasAppliedStatus(character, "TOT_PRIMORDIAL_SAP_001") ~= 1 then
        Osi.ApplyStatus(character, "TOT_PRIMORDIAL_SAP_001", -1, 1, character)
    end
    ensureSummonMasterAura(character)
end

Ext.Osiris.RegisterListener("LevelGameplayStarted", 2, "after", function(levelName, isEditorMode)
    Defer(1200, function()
        for _, entity in ipairs(Ext.Entity.GetAllEntitiesWithComponent("ServerCharacter")) do
            local guid = entity.Uuid and entity.Uuid.EntityUuid
            if guid and Osi.IsPlayer(guid) == 1 then
                refreshCustomUnlockMarkers(guid)
            end
        end
    end)
end)

local function unlockTadpole(object)
    local e = Ext.Entity.Get(object)
    if not e.Tadpoled then
        e:CreateComponent("Tadpoled")
        e:Replicate("Tadpoled")
    end

    -- give tadpole on first unlock
    if Osi.GetTadpolePowersCount(object) < 1 then
        Osi.AddTadpole(object, 1)
        Osi.AddTadpole(object, 1)
    end

    Osi.SetTag(object, "089d4ca5-2cf0-4f54-84d9-1fdea055c93f")
    Osi.SetTag(object, "efedb058-d4f5-4ab8-8add-bd5e32cdd9cd")
    Osi.SetTag(object, "c15c2234-9b19-453e-99cc-00b7358b9fce")
    Osi.SetTadpoleTreeState(object, 2)
    Osi.AddTadpolePower(object, "TAD_IllithidPersuasion", 1)
    Osi.SetFlag("GLO_Daisy_State_AstralIndividualAccepted_9c5367df-18c8-4450-9156-b818b9b94975", object)
end

local function hagHair()
    local hairs = {}
    local icons = {
        "Item_Quest_HAG_HagHair_Strength",
        "Item_Quest_HAG_HagHair_Dexterity",
        "Item_Quest_HAG_HagHair_Constitution",
        "Item_Quest_HAG_HagHair_Intelligence",
        "Item_Quest_HAG_HagHair_Wisdom",
        "Item_Quest_HAG_HagHair_Charisma",
    }
    for nr, stat in pairs({
        "STR",
        "DEX",
        "CON",
        "INT",
        "WIS",
        "CHA",
    }) do
        local id = "BuyHair" .. stat
        table.insert(hairs, {
            Id = id,
            Name = Localization.Get("hec30ce0dgb76bg45cagaf40gad771ff7902b_" .. nr) .. " +1",
            Icon = icons[nr],
            Cost = 60,
            Amount = 10,
            Character = true,
            OnBuy = function(self, character)
                Osi.ApplyStatus(character, "HAG_HAIR_" .. stat, -1)

                for _, unlock in pairs(getUnlocks()) do
                    if unlock.Id:match("^BuyHair") and unlock.Id ~= id then
                        unlock.Bought = unlock.Bought + 1
                    end
                end
            end,
        })
    end

    return hairs
end

-- V8.4Z15: legacy Progression multipliers and Quick Start/Run accélérée purchases
-- were retired. Run speed is now selected once from the Combat tab.
-- V8.4Z16: Reset Stock is intentionally kept as an independent shop utility.
local shopUtilities = {
    {
        Id = "BuyStockPlus",
        Name = __("Reset Stock"),
        Icon = "Item_BOOK_SignedTradeVisa",
        Description = __("Restores the stock of compatible standard Unlocks. Does not affect milestone rewards purchased with Tokens. Information: bonuses already applied to characters are not removed."),
        Cost = 1000,
        Amount = nil,
        Character = false,
        OnBuy = function(self, character)
            if self.Bought > 0 then
                for _, u in pairs(getUnlocks()) do
                    if string.contains(u.Id, { "^Buy", "TadAwaken" }) then
                        if u.Id ~= "BuyStockPlus" and u.Cost > 0 and u.Amount ~= nil and u.Amount > 0 then
                            L.Debug(u.Id)
                            u.Bought = 0
                        end
                    end
                end
            end
        end,
    },
}

--- @type table<number, Unlock>
return table.extend({
    {
        Id = "UnlockTadpole",
        Name = __("Unlock Tadpole Power"),
        Icon = "TadpoleSuperPower_IllithidPowers",
        Cost = 10,
        Requirement = 25,
        Amount = nil,
        Character = true,
        OnBuy = function(self, character)
            unlockTadpole(character)
        end,
    },
    {
        Id = "TadpoleCeremorph",
        Name = __("Start Ceremorphosis"),
        Icon = "TadpoleSuperPower_IllithidPersuasion",
        Description = __("Includes %s", __("Unlock Tadpole Power")),
        Cost = 300,
        Amount = nil,
        Character = true,
        Requirement = 45,
        OnBuy = function(self, character)
            unlockTadpole(character)
            Osi.SetTag(character, "c0cd4ed8-11d1-4fb1-ae3a-3a14e41267c8")
            Osi.ApplyStatus(character, "TAD_PARTIAL_CEREMORPH", -1)
            -- Osi.RemoveCustomMaterialOverride(character, "398ca8ae-c3c0-47f5-8e45-d9402e198389")
        end,
    },
    {
        Id = "BuyAscension", -- God V2: one shop stock, repeatable after Reset Stock
        Name = TrialsAscensionGodName(),
        Icon = "statIcons_GaleGod",
        Description = __("Divine blessing: +2 to all abilities, AC, Attack Rolls, Saving Throws and spell damage, plus +30 max HP per purchase."),
        Requirement = 150,
        Cost = 1000,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- Each purchase applies a DIFFERENT permanent status.
            -- This avoids relying on same-Status stacking semantics and mirrors the
            -- existing permanent-unlock approach used by the Hag Hair bonuses.
            -- 200 slots is intentionally far beyond any realistic run (130,000 currency).
            for stack = 1, 200 do
                local status = string.format("TOT_GOD_V2_%03d", stack)
                if Osi.HasAppliedStatus(character, status) ~= 1 then
                    Osi.ApplyStatus(character, status, -1, 1, character)
                    return
                end
            end
            L.Warn("God V2: all 200 permanent stack slots are already used for " .. tostring(character))
        end,
    },
    {
        Id = "BuyMindflayerForm",
        Name = Localization.Get("hd58a2099g6c22g499fga7acgab8d6fda5615"),
        Icon = "TadpoleSuperPower_Ceremorphosis",
        Cost = 1500,
        Amount = 1,
        Character = true,
        Requirement = 225,
        OnBuy = function(self, character)
			if Osi.HasAppliedStatus(character, "EPI_GALEGOD") == 1 then
				Osi.RemoveStatus(character, "EPI_GALEGOD")
				Osi.ApplyStatus(character, "MIND_FLAYER_FORM", -1)
				Osi.ApplyStatus(character, "EPI_GALEGOD_MINDFLAYER", -1)
			else
				Osi.ApplyStatus(character, "MIND_FLAYER_FORM", -1)
			end
            -- takes a bit to transform
            WaitTicks(100, function()
                self:OnReapply()
            end)
        end,
        OnReapply = function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                GC.RemoveSpell(uuid, "Target_END_Mindflayer_CrownDomination")
            end
        end,
    },
    {
        Id = "TadAwaken",
        Name = __("Awakened Illithid Powers"),
        Icon = "PassiveFeature_CRE_GithInfirmary_Awakened",
        Description = __("Use all Illithid Powers with Bonus Actions."),
        Cost = 100,
        Requirement = 50,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddPassive(character, "CRE_GithInfirmary_Awakened")
        end,
    },
    {
        Id = "BuyTadInstinct",
        Name = Localization.Get("ha5b687efgdea0g441bg9b23gea473a021ef3"),
        Description = Localization.Get("hcf1ccad1gddf7g447agaf91gf473f16583a0"),
        Icon = "TadpoleSuperPower_SurvivalInstinct",
        Cost = 40,
        Requirement = 50,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddSpell(character, "Target_SurvivalInstinct", 1)
        end,
    },
    {
        Id = "BuyEmperor",
        Name = __("Spawn Mindflayer Companion"),
        Description = __("Spawns the Emperor as controllable party follower. After each Long Rest, you'll receive a spell to resummon them."),
        Icon = "TadpoleSuperPower_IllithidExpertise",
        Cost = 350,
        Requirement = 75,
        TemplateId = "1467fb3e-b769-41b1-8207-53e42b5b7aaf",
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.UseSpell(character, "Target_TOT_Summon_Emperor", character)
            Osi.AddPassive(character, "TOT_EmperorSummoner")
        end,
    },
    {
        Id = "BuyNightsong",
        Name = __("Sword of the Silverlight"),
        Description = __("Spawns Dame Aylin as controllable party follower. After each Long Rest, you'll receive a spell to resummon them."),
        Icon = "Action_EndGameAlly_NightsongSummon",
        Cost = 400,
        Requirement = 75,
        TemplateId = "4b1ea015-1c6c-4bd4-aff7-ff1b118ca459",
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.UseSpell(character, "Target_TOT_Summon_Aylin", character)
            Osi.AddPassive(character, "TOT_AylinSummoner")
        end,
    },
    {
        Id = "BuyOwlbear",
        Name = __("Battle-Ready Owlbear"),
        Description = __("Your owlbear cub is all grown up and ready to rage. Spawns the Armoured Owlbear as controllable party follower. After each Long Rest, you'll receive a spell to resummon them."),
        Icon = "Action_EndGameAlly_OwlbearCubSummon",
        Cost = 300,
        Requirement = 75,
        TemplateId = "f5d6b4e5-e0ea-44cb-b69b-a52d639cc4c9",
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.UseSpell(character, "Target_TOT_Summon_Owlbear", character)
            Osi.AddPassive(character, "TOT_OwlbearSummoner")
        end,
    },
    {
        Id = "Tadpole",
        Name = __("Get a Tadpole"),
        Icon = "Item_LOOT_Druid_Autopsy_Set_Tadpole",
        Cost = 30,
        Amount = nil,
        Character = false,
        OnBuy = function(self, character)
            Osi.AddTadpole(character, 1)
        end,
    },
    {
        Id = "BuyExp",
        Name = "1000 EXP",
        Icon = "Action_Dash_Bonus",
        Cost = 40,
        Amount = 4,
        Character = false,
        OnBuy = function(self, character)
            Player.GiveExperience(1000)
        end,
    },
    {
        Id = "BuyLoot",
        Name = __("Roll Loot %dx", 10),
        Icon = "Item_CONT_GEN_Chest_Jewel_B",
        Cost = 30,
        Amount = 10,
        Character = false,
        OnBuy = function(self, character)
            local loot = Item.GenerateLoot(10, {
                EquipmentOnly = true,
                Objects = {},
                Armor = { Uncommon = 50, Rare = 30, VeryRare = 16, Legendary = 4 },
                Weapons = { Uncommon = 50, Rare = 30, VeryRare = 16, Legendary = 4 },
            })

            local x, y, z = Osi.GetPosition(character)
            Item.SpawnLoot(loot, x, y, z)
        end,
    },
    {
        Id = "BuyLootRare",
        Name = __("Roll Rare Loot %dx", 5),
        Icon = "Item_CONT_GEN_Chest_Jewel_C",
        Cost = 50,
        Requirement = 50,
        Amount = 6,
        Character = false,
        OnBuy = function(self, character)
            local loot = Item.GenerateLoot(5, {
                EquipmentOnly = true,
                Objects = {},
                Armor = { Rare = 1 },
                Weapons = { Rare = 1 },
            })

            local x, y, z = Osi.GetPosition(character)
            Item.SpawnLoot(loot, x, y, z)
        end,
    },
    {
        Id = "BuyLootEpic",
        Name = __("Roll Epic Loot %dx", 3),
        Icon = "Item_CONT_GEN_Chest_Jewel_A",
        Cost = 100,
        Requirement = 50,
        Amount = 3,
        Character = false,
        OnBuy = function(self, character)
            local loot = Item.GenerateLoot(3, {
                EquipmentOnly = true,
                Objects = {},
                Armor = { VeryRare = 1 },
                Weapons = { VeryRare = 1 },
            })

            local x, y, z = Osi.GetPosition(character)
            Item.SpawnLoot(loot, x, y, z)
        end,
    },
    {
        Id = "BuyLootLegendary",
        Name = __("Roll Legendary Loot %dx", 1),
        Icon = "Item_CONT_GEN_Chest_Jewel_D",
        Cost = 100,
        Requirement = 50,
        Amount = 3,
        Character = false,
        OnBuy = function(self, character)
            local loot = Item.GenerateLoot(1, {
                EquipmentOnly = true,
                Objects = {},
                Armor = { Legendary = 1 },
                Weapons = { Legendary = 1 },
            })

            local x, y, z = Osi.GetPosition(character)
            Item.SpawnLoot(loot, x, y, z)
        end,
    },
    {
        Id = "BuySupplies",
        Name = __("Buy 40 Camp Supplies"),
        Icon = "Item_CONT_GEN_CampSupplySack",
        Cost = 40,
        Amount = nil,
        Character = false,
        OnBuy = function(self, character)
            Osi.PROC_CAMP_GiveFreeSupplies()
        end,
    },

    {
       Id = "ShortRestRecovery",
       Name = __("Restore some extra resources on Short Rest"),
       Description = __("Causes a limited amount of Long Rest resources to be regained on each Short Rest. The amount scales with character level."),
       Icon = "Action_EndGame_IsobelHeal",
       Cost = 250,
       Requirement = 100,
       Amount = 1,
       Character = false,
       OnBuy = function(self, character)
           self:OnInit()
       end,
       Register = U.Once(function(self)
           Ext.Osiris.RegisterListener("ShortRested", 1, "after", function(character)
               local entity = Ext.Entity.Get(character)
               local resources = get(entity.ActionResources, "Resources", {})
               for uuid, list in pairs(resources) do
                   for _, resource in pairs(list) do
                       L.Dump(
                           "Restoring Resource",
                           character,
                           get(Ext.StaticData.Get(resource.ResourceUUID, "ActionResource"), "Name", "Unknown")
                       )
-- Prevent Coffeelocking, otherwise Sorcerer is disproportionately more powerful than all other casters
                       Osi.RemoveStatus(character, "SPELLSLOT_1")
                       Osi.RemoveStatus(character, "SPELLSLOT_2")
                       Osi.RemoveStatus(character, "SPELLSLOT_3")
                       Osi.RemoveStatus(character, "SPELLSLOT_4")
                       Osi.RemoveStatus(character, "SPELLSLOT_5")
                       Osi.RemoveStatus(character, "SORCERYPOINT_1")
                       Osi.RemoveStatus(character, "SORCERYPOINT_2")
                       Osi.RemoveStatus(character, "SORCERYPOINT_3")
                       Osi.RemoveStatus(character, "SORCERYPOINT_4")
                       Osi.RemoveStatus(character, "SORCERYPOINT_5")
                       if resource.ResourceUUID == "d136c5d9-0ff0-43da-acce-a74a07f8d6bf" and resource.Level > math.max(2, math.ceil(Player.Level()/3.3)) then
                           L.Dump(
                           "Spell slot too high level",
                           character,
                           get(Ext.StaticData.Get(resource.ResourceUUID, "ActionResource"), "Name", "Unknown")
                           )
                       elseif resource.ResourceUUID == "46886ba5-6505-4875-a747-ac14118e1e08" then
                           local toRestore = math.max(1, math.ceil(resource.MaxAmount / 2.5))
                           resource.Amount = math.min(Player.Level(), math.floor(resource.Amount + toRestore))
                       else
                           local toRestore = math.max(1, math.ceil(resource.MaxAmount / 2.5))
                           resource.Amount = math.min(resource.MaxAmount, math.floor(resource.Amount + toRestore))
                       end
                   
                   end
               end
               entity:Replicate("ActionResources")
           end)
       end),
       OnInit = function(self)
           if self.Bought > 0 then
               self:Register()
           end
       end,
    },
--    {
--         Id = "BuyRestore",
--         Name = __("Fully Restore Character"),
--         Icon = "Action_EndGame_IsobelHeal",
--         Description = __("Heal character and restore used spells."),
--         Cost = 20,
--         Amount = nil,
--         Character = true,
--         OnBuy = function(self, character)
--              for _, p in pairs(GE.GetParty()) do
--                  Osi.PROC_CharacterFullRestore(p.Uuid.EntityUuid)
--                  Osi.UseSpell(p.Uuid.EntityUuid, "Shout_DivineIntervention_Healing", p.Uuid.EntityUuid)
--              end
--              Osi.PROC_GLO_PartyMembers_TempRestore(character)
--              Osi.PROC_CharacterFullRestore(character)
--              Osi.ApplyStatus(character, "ALCH_POTION_REST_SLEEP_GREATER_RESTORATION", 1)
--        end,
--    },
    {
        Id = "Moonshield",
        Name = __("Get Pixie Blessing"),
        Description = __("Counter the Shadow Curse."),
        Icon = "statIcons_Moonshield",
        Cost = 30,
        Amount = 1,
        Character = false,
        OnBuy = function(self, character)
            for _, p in pairs(GE.GetParty()) do
                Osi.ApplyStatus(p.Uuid.EntityUuid, "GLO_PIXIESHIELD", -1)
                Osi.SetTag(p.Uuid.EntityUuid, C.ShadowCurseTag)
            end
        end,
        OnReapply = function(self) ---@param self Unlock
            if self.Bought > 0 then
                self:OnBuy()
            end
        end,
    },
    {
        Id = "BreakOath",
        Name = __("Break/Restore Oath"),
        Icon = "statIcons_OathBroken",
        Description = __("Needs to be a Paladin."),
        Cost = 10,
        Amount = nil,
        Character = true,
        OnBuy = function(self, character)
            -- Osi.PROC_GLO_PaladinOathbreaker_BrokeOath(character)
            Osi.PROC_GLO_PaladinOathbreaker_BecomesOathbreaker(character)
            Osi.PROC_GLO_PaladinOathbreaker_RedemptionObtained(character)
            Osi.StartRespecToOathbreaker(character)
        end,
    },
    {
        Id = "BuyGodBlessing",
        Name = Localization.Get("h86fef9afgeb0eg45e8g8388gd8e9f7c619b7"),
        Icon = "GenericIcon_Intent_Buff",
        Description = Localization.Get(
            "he4120ec1gc489g4f2fg947cgbe6449fed394",
            Ext.Stats.Get("LOW_STORMSHORETABERNACLE_GODBLESSED").DescriptionParams
        ), --"Gain Ascendant Bite and Misty Escape (Vampire Ascendant).",), --"Gain +2 bonus to all Saving throws.",
        Cost = 60,
        Requirement = 50,
        Amount = nil,
        Character = true,
        OnBuy = function(self, character)
            Osi.ApplyStatus(character, "LOW_STORMSHORETABERNACLE_GODBLESSED", -1)
        end,
    },
    {
        Id = "BuyLoviatar",
        Name = Localization.Get("h80729873g86d9g4ddbga01egeebe788f1733"),
        Description = Localization.Get("hef31fe63ga576g45c0ga580gf2b0d8fa0b35"),
        Icon = "statIcons_GOB_CalmnessInPain",
        Cost = 40,
        Amount = nil,
        Character = true,
        OnBuy = function(self, character)
            Osi.ApplyStatus(character, "GOB_CALMNESS_IN_PAIN", -1) -- removed on death
        end,
    },
    {
        Id = "BuyScratch", -- repurposed: Surcroît d’action
        Name = __("Action Surplus"),
        -- Verified vanilla icon: Target_MainHandAttack uses this exact icon asset.
        Icon = "Target_MainHandAttack",
        Description = __("Grants +1 permanent Action every turn."),
        Cost = 900,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- Unique passive: re-adding the same passive does not grant another Action Point.
            Osi.AddPassive(character, "TOT_ACTION_POINT_UNLOCK")
            Osi.ApplyStatus(character, "TOT_UI_ACTION_POINT", -1, 1, character)
        end,
    },
    {
        Id = "BuyAssassinMastery",
        Name = __("Assassin Mastery"),
        -- Verified vanilla Assassin-related passive icon (Assassinate: Initiative).
        Icon = "PassiveFeature_Generic_Death",
        Description = __("Grants +1 permanent Bonus Action and +2d4 Piercing damage with weapons and unarmed attacks."),
        Cost = 550,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- Unique passive: non-cumulable on the same character.
            Osi.AddPassive(character, "TOT_ASSASSIN_MASTERY_UNLOCK")
            Osi.ApplyStatus(character, "TOT_UI_ASSASSIN_MASTERY", -1, 1, character)
        end,
    },
    {
        Id = "BuySummonMastery",
        Name = __("Summon Mastery"),
        -- Vanilla Scratch / Gribouille familiar icon.
        Icon = "Spell_Conjuration_FindFamiliar_Dog",
        Description = __("Your summons gain +10 HP, +2 to Attack Rolls and +1d4 Bludgeoning damage with melee weapon or unarmed attacks."),
        Cost = 150,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- Unique owner passive: buying again on the same character does not stack.
            Osi.AddPassive(character, "TOT_SUMMON_MASTER_OWNER")
            Osi.ApplyStatus(character, "TOT_SUMMON_MASTER_AURA", -1, 1, character)
        end,
    },
    {
        Id = "BuyLivingBulwark",
        Name = __("Living Bulwark"),
        Icon = "Spell_Abjuration_ShieldOfFaith",
        Description = __("Grants +25 max HP, +1 AC, +1 to all Saving Throws, immunity to Stunned and Prone, and Advantage on WIS and CON Saving Throws."),
        Cost = 400,
        Requirement = 100,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- Unique permanent defensive passive.
            Osi.AddPassive(character, "TOT_LIVING_BULWARK_UNLOCK")
            Osi.ApplyStatus(character, "TOT_UI_LIVING_BULWARK", -1, 1, character)
        end,
    },
    {
        Id = "BuyMacabreFavor",
        Name = __("Macabre Favor"),
        Icon = "Spell_Necromancy_InflictWounds",
        Description = __("Grants +1 AC and adds your WIS modifier to Radiant and Necrotic damage dealt by spells, including cantrips. Weapon damage is not affected."),
        Cost = 200,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- Unique permanent passive: non-cumulable on the same character.
            Osi.AddPassive(character, "TOT_MACABRE_FAVOR_UNLOCK")
            Osi.ApplyStatus(character, "TOT_UI_MACABRE_FAVOR", -1, 1, character)
        end,
    },



    {
        Id = "BuyIntellectDevourerCompanion",
        Name = Localization.Get("h71c08839ga8ccg45e7g825ag5b57ac274b1e"),
        Icon = "Spell_ConjureUs",
        Description = __("Gain ability to conjure an intellect devourer companion"),
        Cost = 120,
        Requirement = 50,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddSpell(character, "Target_ConjureIntellectDevour", 1, 0);
        end,
    },
    {
        Id = "BuyResonanceStone", -- repurposed: Arcane Essence
        Name = __("Arcane Essence"),
        Icon = "Item_TOOL_MF_Resonance_Crystal_A", -- keep the original Resonance Stone icon
        Description = __("Grants +2 Spell Save DC, +2 Spell Attack Rolls and +2 spell damage, but reduces AC by 2."),
        Cost = 250,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasPassive(character, "TOT_ARCANE_ESSENCE_UNLOCK") ~= 1 then
                Osi.AddPassive(character, "TOT_ARCANE_ESSENCE_UNLOCK")
            end
            if Osi.HasAppliedStatus(character, "TOT_ARCANE_ESSENCE_001") ~= 1 then
                Osi.ApplyStatus(character, "TOT_ARCANE_ESSENCE_001", -1, 1, character)
            end
        end,
        OnReapply = Debounce(100, function(self)
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyAnimateDeadZone",
        Name = Localization.Get("hca33cd78g2509g4736gb3cegc9af2d4faba5"),
        Icon = "PassiveFeature_Generic_Death",
        Description = Localization.Get("he14e8628g1c7fg4e46gadacga197c3410657"),
        Cost = 30,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.ApplyStatus(character, "ANIMATEDEAD_ZONE", -1)
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyFrogMind", -- repurposed: Cerebral Erosion
        Name = __("Cerebral Erosion"),
        Icon = "Item_DEC_MF_Brain_Jar_Memory_A",
        Description = __("Adds +1d4 Psychic damage to weapon and unarmed attacks and grants +1 to INT and WIS Saving Throws."),
        Cost = 180,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasPassive(character, "TOT_CEREBRAL_EROSION_UNLOCK") ~= 1 then
                Osi.AddPassive(character, "TOT_CEREBRAL_EROSION_UNLOCK")
            end
            if Osi.HasAppliedStatus(character, "TOT_CEREBRAL_EROSION_001") ~= 1 then
                Osi.ApplyStatus(character, "TOT_CEREBRAL_EROSION_001", -1, 1, character)
            end
        end,
        OnReapply = Debounce(100, function(self)
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyShadowEntangle", -- repurposed: Primordial Sap
        Name = __("Primordial Sap"),
        Icon = "Spell_Conjuration_Entangled",
        Description = __("Grants +25 max HP, heals 1d4 HP at the start of each turn and adds +1d4 to healing from spells."),
        Cost = 300,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasPassive(character, "TOT_PRIMORDIAL_SAP_UNLOCK") ~= 1 then
                Osi.AddPassive(character, "TOT_PRIMORDIAL_SAP_UNLOCK")
            end
            if Osi.HasPassive(character, "TOT_PRIMORDIAL_SAP_001_REGEN_PASSIVE") ~= 1 then
                Osi.AddPassive(character, "TOT_PRIMORDIAL_SAP_001_REGEN_PASSIVE")
            end
            if Osi.HasPassive(character, "TOT_PRIMORDIAL_SAP_001_HEAL_PASSIVE") ~= 1 then
                Osi.AddPassive(character, "TOT_PRIMORDIAL_SAP_001_HEAL_PASSIVE")
            end
            if Osi.HasAppliedStatus(character, "TOT_PRIMORDIAL_SAP_001") ~= 1 then
                Osi.ApplyStatus(character, "TOT_PRIMORDIAL_SAP_001", -1, 1, character)
            end
        end,
        OnReapply = Debounce(100, function(self)
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyVoloErsatz",
        Name = Localization.Get("h232cc24ega0f9g4f4dgb5d3g46ab59579d4b"),
        Description = Localization.Get("h9d8550edg6d54g4113gbbdcge6d99b8b2a2f"),
        Icon = "Item_DEN_VoloOperation_ErsatzEye",
        Cost = 25,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddPassive(character, "CAMP_Volo_ErsatzEye")
        end,
    },
    {
        Id = "BuyBrand",
        Name = Localization.Get("h7cc7adeag848fg491cga683g0faeaea082c3"),
        Icon = "Item_TOOL_GOB_Branding_Tool_A",
        Description = __("Bear the Absolute's Brand."),
        Cost = 20,
        Amount = 2,
        Character = true,
        OnBuy = function(self, character)
            Osi.SetTag(character, "310f7186-bb0b-4905-b8f6-dfc2fe62570a")
        end,
    },
    {
        Id = "BuyBOOOALBlessing",
        Name = Localization.Get("hc6ac3045g2c16g4d9dgb178gfa9c8c0928b6"),
        Icon = "statIcons_BoooalsBenediction",
        Description = Localization.Get("hf9325d87g8da3g4472g9791gdd55a4bad685"), --"Advantage on Attack rolls against Bleeding cratures.",
        Cost = 50,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.ApplyStatus(character, "UND_BOOOALBLESSING", -1)
        end,
    },
    {
        Id = "BuyFalseLife",
        Name = Localization.Get("hcb11494cg5afbg4068g8de7g50ccdae27cfe"),
        Icon = "GenericIcon_Intent_Healing",
        Description = Localization.Get("hce17bfdcg2d30g4a97g9850g0219c6a5116a", 20), --"Grants 20 Temporary HP after Long Rest.",
        Cost = 80,
        Requirement = 75,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddPassive(character, "CursedTome_FalseLife")
        end,
    },
    {
        Id = "BuyWakeTheDead",
        Name = Localization.Get("h107871e3gd9c6g4091g828fg3608cb2cb03f"),
        Description = Localization.Get(
            "h0d543bfeg7506g45e8g84fag0350fb67b494",
            Ext.Stats.Get("Target_CursedTome_WakeTheDead").DescriptionParams
        ), --"Gain Ascendant Bite and Misty Escape (Vampire Ascendant).",
        Icon = "Spell_WakeTheDead",
        Cost = 80,
        Requirement = 100,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddSpell(character, "Target_CursedTome_WakeTheDead", 1)
        end,
    },
    {
        Id = "BuyVampireAscendant",
        Name = Localization.Get("h7c8ce380g0d56g4807gb60cg58e283b4ecdb"),
        Icon = "Action_Monster_Bulette_Bite",
        Description = Localization.Get(
            "hf9a3c136gfa53g4170g9eeega20ced9c9111",
            Ext.Stats.Get("LOW_Astarion_VampireAscendant").DescriptionParams
        ), --"Gain Ascendant Bite and Misty Escape (Vampire Ascendant).",
        Cost = 300,
        Requirement = 75,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddPassive(character, "LOW_Astarion_VampireAscendant")
        end,
    },
    {
        Id = "BuyBloodyInheritance",
        Name = Localization.Get("hc4d08908g6040g4e50g889cg0ef6e267b6e0"),
        Icon = "PassiveFeature_Generic_Blood",
        Description = Localization.Get("h473ffdccgc70fg4761gaa67gbf0fb07d475f"), --"Gain Stunning Gaze and Critical Hit requirement reduced by 2.",
        Cost = 100,
        Requirement = 75,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasAppliedStatus(character, "END_ALLYABILITIES_BHAALBUFF") ~= 1 then
                Osi.ApplyStatus(character, "END_ALLYABILITIES_BHAALBUFF", -1)
            end
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuySweetStoneFeatures",
        Name = Localization.Get("h9d318df0g739eg4313gbc3cgc77a3afc702e"),
        Icon = "Spell_Enchantment_Bless",
        Description = Localization.Get("h0be556d1g0e1bg48ddg9ce4g86d3891c06e2"),
        Cost = 180,
        Requirement = 75,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            -- V7.2: custom permanent blessing; no dependency on vanilla Bless / circus statue status.
            if Osi.HasAppliedStatus(character, "WYR_CIRCUS_STATUEBLESS") == 1 then
                Osi.RemoveStatus(character, "WYR_CIRCUS_STATUEBLESS")
            end
            if Osi.HasPassive(character, "TOT_STONE_IMAGE_BLESSING") ~= 1 then
                Osi.AddPassive(character, "TOT_STONE_IMAGE_BLESSING")
            end
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyVolosGuide",
        Name = Localization.Get("h397d3e3fgf2c3g4f5cg8974g7784ef35cc21"),
        Icon = "PassiveFeature_PactOfTheTome",
        Description = __("With steadfast application of knowledge from Volo's preeminent work, affected entities gain +2 to Attack Rolls, Saving Throws, and Ability Checks."),
        Cost = 400,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasAppliedStatus(character, "END_ALLYBUFF_VOLO") ~= 1 then
                Osi.ApplyStatus(character, "END_ALLYBUFF_VOLO", -1)
            end
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyThanielBuff",
        Name = Localization.Get("h221a4b23g1fe7g4c43g834bg2863ae271223"),
        Icon = "statIcons_Momentum",
        Description = __("The reunited soul Thaniel provides a +1 to all Ability Scores and an additional 2m movement speed."),
        Cost = 275,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasAppliedStatus(character, "END_ALLYBUFF_HALSIN") ~= 1 then
                Osi.ApplyStatus(character, "END_ALLYBUFF_HALSIN", -1)
            end
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyMolBuff",
        Name = Localization.Get("hd6eee16fgaf11g483bgb572g1923ad837611"),
        Icon = "Action_Monster_Cambion_FireRay",
        Description = __("Equipped with Mol's tricks of the trade. Reduce Fire damage by 5 and gain the ability to cast Rays of Fire."),
        Cost = 350,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasAppliedStatus(character, "END_ALLYABILITIES_MOLBUFF") ~= 1 then
                Osi.ApplyStatus(character, "END_ALLYABILITIES_MOLBUFF", -1)
            end
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuyArabellaBuff",
        Name = Localization.Get("hcec0f370geccfg445egaf70g1974159ff90b"),
        Icon = "Spell_Abjuration_FreedomOfMovement",
        Description = __("One must remove all obstacles to follow one's destiny - Arabella's favour grants affected entities the benefits of Freedom of Movement."),
        Cost = 350,
        Requirement = 150,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            if Osi.HasAppliedStatus(character, "END_ALLYABILITIES_ARABELLABUFF") ~= 1 then
                Osi.ApplyStatus(character, "END_ALLYABILITIES_ARABELLABUFF", -1)
            end
        end,
        OnReapply = Debounce(100, function(self) ---@param self Unlock
            for uuid, _ in pairs(self.BoughtBy) do
                self:OnBuy(uuid)
            end
        end),
    },
    {
        Id = "BuySlayer",
        Name = Localization.Get("h7ee059fega56bg48d4g99abg0a1ee50238d1"),
        Description = Localization.Get("h67dd3fb6ge300g42f0gaea3g0ecb374132c7", 10),
        Icon = "Action_DarkUrge",
        Requirement = 75,
        Cost = 200,
        Amount = 1,
        Character = true,
        OnBuy = function(self, character)
            Osi.AddSpell(character, "Shout_DarkUrge_Slayer", 1)
            Osi.SetTag(character, "f09707c1-7c58-4611-a06b-ce34dd2826c6")
        end,
    },
}, hagHair(), shopUtilities)
