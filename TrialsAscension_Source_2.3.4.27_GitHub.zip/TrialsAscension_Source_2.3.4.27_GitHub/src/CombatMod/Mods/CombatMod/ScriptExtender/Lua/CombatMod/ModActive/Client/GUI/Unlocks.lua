ClientUnlock = {}

local function AscensionPowersLabel()
    local buy = __("Buy")
    if buy == "Acheter" then return "Pouvoirs de l'Ascension" end
    return "Ascension Powers"
end

local POWER_GRADES = {
    TA_Text("Novice", "Novice"), TA_Text("Aspirant", "Aspirant"), TA_Text("Initiate", "Initié"),
    TA_Text("Veteran", "Vétéran"), TA_Text("Champion", "Champion"), TA_Text("Herald", "Héraut"),
    TA_Text("Mythic", "Mythique"), TA_Text("Ascendant", "Ascendant"), TA_Text("God", "Dieu"),
}

local POWER_GRADE_COLORS = {
    { 0.72, 0.72, 0.66, 1.00 },
    { 0.58, 0.76, 0.66, 1.00 },
    { 0.42, 0.68, 0.86, 1.00 },
    { 0.38, 0.58, 0.86, 1.00 },
    { 0.66, 0.46, 0.84, 1.00 },
    { 0.82, 0.42, 0.66, 1.00 },
    { 0.86, 0.42, 0.38, 1.00 },
    { 0.92, 0.62, 0.24, 1.00 },
    { 0.78, 0.18, 0.16, 1.00 },
}

local function powerTier(value)
    local tier = tonumber(value) or 1
    if tier < 1 then tier = 1 end
    if tier > #POWER_GRADES then tier = #POWER_GRADES end
    return tier
end

local function powerFormatNumber(value)
    local n = math.floor(tonumber(value) or 0)
    local s = tostring(math.abs(n))
    local out = s
    while true do
        local nextValue, count = out:gsub("^(%d+)(%d%d%d)", "%1 %2")
        out = nextValue
        if count == 0 then break end
    end
    return (n < 0 and "-" or "") .. out
end

---@param tab ExtuiTabBar
function ClientUnlock.Main(tab)
    ---@type ExtuiTabItem
    local root = tab:AddTabItem(AscensionPowersLabel())

    local progression = root:AddTable("AscensionPowersProgression", 3)
    pcall(function() progression:SetStyle("CellPadding", 14, 8) end)
    local row = progression:AddRow()

    local gradeCell = row:AddCell()
    local gradeLabel = gradeCell:AddText(TA_Text("CURRENT TIER", "GRADE ACTUEL"))
    gradeLabel:SetColor("Text", { 0.58, 0.54, 0.48, 1.00 })
    local gradeValue = gradeCell:AddText(TA_Text("Tier 1 - Novice", "Palier 1 - Novice"))

    local rgCell = row:AddCell()
    local rgLabel = rgCell:AddText("ROGUESCORE")
    rgLabel:SetColor("Text", { 0.58, 0.54, 0.48, 1.00 })
    local rgValue = rgCell:AddText("0")
    rgValue:SetColor("Text", { 0.42, 0.72, 0.92, 1.00 })

    local shardCell = row:AddCell()
    local shardLabel = shardCell:AddText(TA_Text("ASCENSION SHARDS", "ÉCLATS D'ASCENSION"))
    shardLabel:SetColor("Text", { 0.58, 0.54, 0.48, 1.00 })
    shardCell:AddImage("Item_LOOT_COINS_Electrum_Pile_Small_A", { 42, 42 })
    local shardValue = shardCell:AddText("0")
    shardValue.SameLine = true
    shardValue:SetColor("Text", { 0.95, 0.72, 0.28, 1.00 })

    pcall(function() gradeValue:SetStyle("FontScale", 1.18) end)
    pcall(function() rgValue:SetStyle("FontScale", 1.18) end)
    pcall(function() shardValue:SetStyle("FontScale", 1.18) end)

    Event.On("StateChange", function(state)
        state = state or {}
        local tier = powerTier(state.AscensionTier)
        gradeValue.Label = string.format(TA_Text("Tier %d - %s", "Palier %d - %s"), tier, POWER_GRADES[tier])
        gradeValue:SetColor("Text", POWER_GRADE_COLORS[tier])
        rgValue.Label = powerFormatNumber(state.RogueScore or 0)
        shardValue.Label = powerFormatNumber(state.Currency or 0)
    end):Exec(State)

    root:AddDummy(1, 8)

    local handler
    handler = Event.On("StateChange", function(state)
        local unlocks = state.Unlocks
        if table.size(unlocks) == 0 then
            return
        end
        handler:Unregister()

        local cols = 3
        local nrows = math.ceil(table.size(unlocks) / cols)
        Components.Layout(root, cols, nrows, function(layout)
            layout.Table.Borders = true
            layout.Table.ScrollY = true
            for i, unlock in ipairs(table.values(unlocks)) do
                local c = (i - 1) % cols
                local r = math.ceil(i / cols)
                local cell = layout.Cells[r][c + 1]
                ClientUnlock.Tile(cell, unlock, i)
            end
        end)
    end)
end


-- Compact, player-facing details for buffs, passives, summons and progression utilities.
-- Keep these client-side: they only describe server mechanics and do not alter gameplay.
ClientUnlock.AdvancedInfo = {
    BuyHairSTR = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+1 Strength." },
    BuyHairDEX = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+1 Dexterity." },
    BuyHairCON = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+1 Constitution." },
    BuyHairINT = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+1 Intelligence." },
    BuyHairWIS = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+1 Wisdom." },
    BuyHairCHA = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+1 Charisma." },
    BuyStockPlus = { Type = "Shop", Effect = "Restores stock for compatible standard Unlocks.", DoesNotAffect = "Milestone rewards purchased with Tokens.", Info = "Does not remove bonuses already applied to characters." },

    UnlockTadpole = { Type = "Illithid", Permanent = "Yes", Stackable = "No", Effect = "Unlocks tadpole powers for the selected character." },
    TadpoleCeremorph = { Type = "Illithid", Permanent = "Yes", Stackable = "No", Effect = "Starts ceremorphosis and includes tadpole power access." },
    BuyAscension = { Type = "Character", Permanent = "Yes", Stackable = "Yes", Effect = "+2 abilities/AC/Attack Rolls/saves/spell damage and +30 max HP." },
    BuyMindflayerForm = { Type = "Transformation", Permanent = "Yes", Stackable = "No", Effect = "Unlocks the Mind Flayer transformation." },
    TadAwaken = { Type = "Illithid", Permanent = "Yes", Stackable = "No", Effect = "Illithid powers can be used with Bonus Actions." },
    BuyTadInstinct = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Grants the Survival Instinct illithid benefit." },

    BuyEmperor = { Type = "Summon", Permanent = "Yes", Stackable = "No", Effect = "1 Mind Flayer companion.", LongRest = "Resummon spell restored." },
    BuyNightsong = { Type = "Summon", Permanent = "Yes", Stackable = "No", Effect = "1 Dame Aylin companion.", LongRest = "Resummon spell restored." },
    BuyOwlbear = { Type = "Summon", Permanent = "Yes", Stackable = "No", Effect = "1 Armoured Owlbear companion.", LongRest = "Resummon spell restored." },
    BuyIntellectDevourerCompanion = { Type = "Summon", Permanent = "Yes", Stackable = "No", Effect = "Unlocks the intellect devourer companion summon." },

    Tadpole = { Type = "Illithid resource", Effect = "Adds 1 tadpole." },
    BuyExp = { Type = "Experience", Effect = "Grants 1000 EXP." },
    BuyLoot = { Type = "Equipment", Effect = "Generates 10 random equipment items.", Info = "Equipment only; no consumables, potions or scrolls." },
    BuyLootRare = { Type = "Rare equipment", Effect = "Generates 5 random Rare equipment items.", Info = "Equipment only; no consumables, potions or scrolls." },
    BuyLootEpic = { Type = "Very Rare equipment", Effect = "Generates 3 random Very Rare equipment items.", Info = "Equipment only; no consumables, potions or scrolls." },
    BuyLootLegendary = { Type = "Legendary equipment", Effect = "Generates 1 random Legendary equipment item.", Info = "Equipment only; no consumables, potions or scrolls." },
    BuySupplies = { Type = "Camp", Effect = "Adds 40 Camp Supplies." },

    ShortRestRecovery = { Type = "Recovery", Permanent = "Yes", Stackable = "No", Effect = "Restores some Long Rest resources on each Short Rest." },
    Moonshield = { Type = "Utility", Permanent = "Yes", Stackable = "No", Effect = "Protects against the Shadow Curse." },
    BreakOath = { Type = "Service", Effect = "Breaks or restores the selected Paladin's oath." },
    BuyGodBlessing = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "+2 to all Saving Throws." },
    BuyLoviatar = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Applies Loviatar's Love to the selected character." },

    BuyScratch = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "+1 Action every turn." },
    BuyAssassinMastery = { Type = "Weapons + unarmed", Permanent = "Yes", Stackable = "No", Effect = "+1 Bonus Action and +2d4 Piercing damage." },
    BuySummonMastery = { Type = "Your summons", Permanent = "Yes", Stackable = "No", Effect = "+10 HP, +2 Attack Rolls and +1d4 melee Bludgeoning damage." },
    BuyLivingBulwark = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "+25 HP, +1 AC, +1 saves; Stunned/Prone immunity; WIS/CON save advantage." },
    BuyMacabreFavor = { Type = "Radiant/Necrotic spells", Permanent = "Yes", Stackable = "No", Effect = "+1 AC and adds WIS modifier to spell damage." },
    BuyResonanceStone = { Type = "Spells", Permanent = "Yes", Stackable = "No", Effect = "+2 spell DC/attack/damage, -2 AC." },
    BuyAnimateDeadZone = { Type = "Necromancy", Permanent = "Yes", Stackable = "No", Effect = "Unlocks the associated undead ability." },
    BuyFrogMind = { Type = "Weapons + unarmed", Permanent = "Yes", Stackable = "No", Effect = "+1d4 Psychic damage and +1 INT/WIS saves." },
    BuyShadowEntangle = { Type = "Character + healing spells", Permanent = "Yes", Stackable = "No", Effect = "+25 HP, heals 1d4 each turn, +1d4 spell healing." },

    BuyVoloErsatz = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Grants Volo's Ersatz Eye benefit." },
    BuyBrand = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Applies the Absolute's Brand." },
    BuyBOOOALBlessing = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Advantage on attacks against Bleeding creatures." },
    BuyFalseLife = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Grants 20 temporary HP after Long Rest." },
    BuyWakeTheDead = { Type = "Necromancy", Permanent = "Yes", Stackable = "No", Effect = "Unlocks Wake the Dead." },
    BuyVampireAscendant = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Grants Vampire Ascendant abilities." },
    BuyBloodyInheritance = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Grants Stunning Gaze and improves critical hit threshold." },
    BuySweetStoneFeatures = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "+1d4 to Attack Rolls and Saving Throws; uses the vanilla stone blessing." },
    BuyVolosGuide = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "+2 Attack Rolls, Saving Throws and Ability Checks." },
    BuyThanielBuff = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "+1 all abilities and +2 m movement." },
    BuyMolBuff = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Reduces Fire damage by 5 and grants Rays of Fire." },
    BuyArabellaBuff = { Type = "Character", Permanent = "Yes", Stackable = "No", Effect = "Grants Freedom of Movement benefits." },
    BuySlayer = { Type = "Transformation", Permanent = "Yes", Stackable = "No", Effect = "Unlocks the Slayer transformation." },
}

-- Visual classification used only by the Unlocks UI.
-- This does not change unlock mechanics, prices, requirements or server state.
ClientUnlock.CategoryColors = {
    ["Character"] = { 0.55, 0.76, 0.86, 1.00 }, -- cool silver-blue; deliberately distinct from gold Cost
    ["Shop"] = { 0.74, 0.58, 0.34, 1.00 },
    ["Illithid"] = { 0.78, 0.38, 0.92, 1.00 },
    ["Illithid resource"] = { 0.78, 0.38, 0.92, 1.00 },
    ["Transformation"] = { 0.92, 0.30, 0.28, 1.00 },
    ["Summon"] = { 0.36, 0.64, 0.92, 1.00 }, -- invocation blue
    ["Experience"] = { 0.40, 0.78, 0.98, 1.00 },
    ["Equipment"] = { 0.72, 0.72, 0.64, 1.00 }, -- warm steel, not the same gold as Cost
    ["Rare equipment"] = { 0.34, 0.58, 0.96, 1.00 },
    ["Very Rare equipment"] = { 0.72, 0.38, 0.94, 1.00 },
    ["Legendary equipment"] = { 0.88, 0.52, 0.26, 1.00 }, -- copper-orange
    ["Camp"] = { 0.42, 0.76, 0.42, 1.00 },
    ["Recovery"] = { 0.42, 0.76, 0.42, 1.00 },
    ["Utility"] = { 0.40, 0.76, 0.82, 1.00 },
    ["Service"] = { 0.72, 0.70, 0.66, 1.00 },
    ["Weapons + unarmed"] = { 0.90, 0.45, 0.30, 1.00 },
    ["Your summons"] = { 0.36, 0.64, 0.92, 1.00 }, -- invocation blue
    ["Necromancy"] = { 0.66, 0.42, 0.82, 1.00 },
    ["Spells"] = { 0.58, 0.52, 0.94, 1.00 },
    ["Radiant/Necrotic spells"] = { 0.82, 0.54, 0.88, 1.00 },
    ["Character + healing spells"] = { 0.46, 0.82, 0.54, 1.00 },
}

function ClientUnlock.GetCategory(unlock)
    local info = ClientUnlock.AdvancedInfo[unlock.Id]
    return (info and info.Type) or "Unlock"
end

function ClientUnlock.GetCategoryColor(unlock)
    return ClientUnlock.CategoryColors[ClientUnlock.GetCategory(unlock)] or { 0.78, 0.72, 0.62, 1.00 }
end

local function safeTextColor(widget, color)
    pcall(function() widget:SetColor("Text", color) end)
end

local function advLine(label, value)
    if not value then return nil end
    return string.format("%s: %s", __(label), __(value))
end

function ClientUnlock.GetAdvancedText(unlock)
    local info = ClientUnlock.AdvancedInfo[unlock.Id]
    if not info then return nil end

    local lines = {}
    local function add(label, value)
        local line = advLine(label, value)
        if line then table.insert(lines, line) end
    end

    add("Type", info.Type)
    add("Permanent", info.Permanent)
    add("Stackable", info.Stackable)
    add("Duration", info.Duration)
    add("Usage", info.Usage)
    add("Effect", info.Effect)
    add("Long Rest", info.LongRest)
    add("Does not affect", info.DoesNotAffect)
    add("Information", info.Info)
    return table.concat(lines, "\n")
end

function ClientUnlock.GetDetailedTooltip(unlock)
    local details = ClientUnlock.GetAdvancedText(unlock)
    if unlock.Description and details then
        return string.format("%s\n\n%s", unlock.Description, details)
    end
    return details or unlock.Description
end

function ClientUnlock.GetStock(unlock)
    local stock = unlock.Amount - unlock.Bought
    if stock > 0 then
        local text = __("Stock: %s", unlock.Amount - unlock.Bought .. "/" .. unlock.Amount)

        if unlock.Persistent then
            text = string.format("%s (%s)", text, __("Permanent"))
        end

        return text
    end
    if unlock.Persistent then
        return __("Active")
    end
    return __("Out of stock")
end


function ClientUnlock.GetCardHeight(unlock)
    local info = ClientUnlock.AdvancedInfo[unlock.Id]
    local lines = 0

    if unlock.Requirement then
        if type(unlock.Requirement) == "table" then
            lines = lines + #unlock.Requirement
        else
            lines = lines + 1
        end
    end

    if info then
        if info.Permanent then lines = lines + 1 end
        if info.Stackable then lines = lines + 1 end
        if info.Duration then lines = lines + 1 end
        if info.Usage then lines = lines + 1 end
        if info.Effect then lines = lines + 1 end
        if info.LongRest then lines = lines + 1 end
        if info.DoesNotAffect then lines = lines + 1 end
        if info.Info then lines = lines + 1 end
    end

    local h = 260 + (lines * 22)
    if h < 300 then h = 300 end
    if h > 420 then h = 420 end
    return h
end

function ClientUnlock.Tile(root, unlock, visualIndex)
    visualIndex = visualIndex or 1
    local grp, cardAccent = CombatTheme.Card(root, "UnlockCard_" .. unlock.Id, visualIndex, 246)

    local detailedTooltip = ClientUnlock.GetDetailedTooltip(unlock)

    -- Icon + quick visual identity.
    local icon = grp:AddImage(unlock.Icon, { 64, 64 })
    if detailedTooltip then
        ---@type ExtuiTooltip
        local t = icon:Tooltip()
        t:SetStyle("WindowPadding", 30, 10)
        t:AddText(detailedTooltip)
    end

    local summary = grp:AddGroup(unlock.Id .. "_summary")
    summary.SameLine = true

    local category = summary:AddText(string.format("[%s]", __(ClientUnlock.GetCategory(unlock))))
    safeTextColor(category, ClientUnlock.GetCategoryColor(unlock))
    summary:AddText("   ").SameLine = true
    local cost = summary:AddText(__("Cost: %s", unlock.Cost))
    safeTextColor(cost, { 0.95, 0.72, 0.28, 1.00 })

    local buyLabel = summary:AddText("  ")
    safeTextColor(buyLabel, { 0.70, 0.66, 0.58, 1.00 })

    if unlock.Amount ~= nil then
        local amount = Components.Computed(buyLabel, function(root, unlock)
            return ClientUnlock.GetStock(unlock)
        end)
        amount.Update(unlock)

        Event.On("StateChange", function(state)
            for _, new in pairs(state.Unlocks) do
                if new.Id == unlock.Id then
                    amount.Update(new)
                end
            end
        end):Exec(State)
    end

    grp:AddSeparator()

    -- Unlock name is now the strongest line of the card.
    local text = grp:AddText(unlock.Name)
    safeTextColor(text, { 0.98, 0.94, 0.84, 1.00 })
    if detailedTooltip then
        local t = text:Tooltip()
        t:SetStyle("WindowPadding", 30, 10)
        t:AddText(detailedTooltip)
    end

    grp:AddSeparator()
    do
        local unlock = unlock

        local bottomText = grp:AddText("")
        -- Requirements are deliberately red: they are conditions, not bonuses.
        safeTextColor(bottomText, { 0.94, 0.30, 0.28, 1.00 })

        local function checkVisable()
            bottomText.Visible = not unlock.Unlocked and unlock.Bought < 1
        end
        checkVisable()

        if unlock.Requirement then
            if type(unlock.Requirement) ~= "table" then
                unlock.Requirement = { unlock.Requirement }
            end

            for _, req in pairs(unlock.Requirement) do
                if type(req) == "number" then
                    bottomText.Label = bottomText.Label .. __("%d RogueScore required", req) .. "\n"
                elseif type(req) == "string" then
                    local u = table.find(State.Unlocks, function(u)
                        return u.Id == req
                    end)
                    if u then
                        bottomText.Label = bottomText.Label .. __("%s required", u.Name) .. "\n"
                    end
                end
            end
        end

        grp:AddDummy(1, 2)

        local cond = Components.Conditional(grp, function()
            if unlock.Character then
                return ClientUnlock.BuyChar(grp, unlock)
            end

            return ClientUnlock.Buy(grp, unlock)
        end)
        cond.Update(unlock.Unlocked)

        Event.On("StateChange", function(state)
            for _, new in pairs(state.Unlocks) do
                if new.Id == unlock.Id then
                    unlock = new
                    cond.Update(unlock.Unlocked)
                    checkVisable()
                end
            end
        end):Exec(State)
    end

    local info = ClientUnlock.AdvancedInfo[unlock.Id]
    if info then
        grp:AddSeparator()

        -- Keep the mechanical information visible in the card for easy scanning,
        -- while also preserving the hover tooltip for a full summary.
        local function addInfoLine(label, value, color)
            if not value then return end
            local line = grp:AddText(string.format("%s: %s", __(label), __(value)))
            if color then safeTextColor(line, color) end
        end

        addInfoLine("Type", info.Type, ClientUnlock.GetCategoryColor(unlock))
        addInfoLine("Permanent", info.Permanent, { 0.72, 0.74, 0.66, 1.00 })
        addInfoLine("Stackable", info.Stackable, { 0.72, 0.74, 0.66, 1.00 })
        addInfoLine("Duration", info.Duration, { 0.72, 0.74, 0.66, 1.00 })
        addInfoLine("Usage", info.Usage, { 0.72, 0.74, 0.66, 1.00 })
        addInfoLine("Effect", info.Effect, { 0.90, 0.84, 0.70, 1.00 })
        addInfoLine("Long Rest", info.LongRest, { 0.62, 0.78, 0.92, 1.00 })
        addInfoLine("Does not affect", info.DoesNotAffect, { 0.72, 0.70, 0.66, 1.00 })
        addInfoLine("Information", info.Info, { 0.72, 0.70, 0.66, 1.00 })
    end
end

function ClientUnlock.Buy(root, unlock)
    local grp = root:AddGroup(U.RandomId())

    ---@type ExtuiButton
    local btn = grp:AddButton(__("Buy"))
    btn.IDContext = U.RandomId()
    btn.Label = string.format("    %s    ", __("Buy"))

    if unlock.Amount ~= nil then
        Event.On("StateChange", function(state)
            for _, new in pairs(state.Unlocks) do
                if new.Id == unlock.Id then
                    btn.Visible = new.Bought < new.Amount
                    return
                end
            end
        end):Exec(State)
    end

    btn.OnClick = function()
        btn:SetStyle("Alpha", 0.2)
        Net.Request("BuyUnlock", { Id = unlock.Id }):After(function(event)
            local ok, res = table.unpack(event.Payload)

            if not ok then
                Event.Trigger("Error", res)
            else
                Event.Trigger("Success", __("Unlock %s bought.", unlock.Name))
            end
            btn:SetStyle("Alpha", 1)
        end)
    end

    grp:AddText("").SameLine = true

    grp:AddDummy(1, 2)

    return grp
end

function ClientUnlock.GetCharacters()
    local characters = table.values(GE.GetPCs())

    table.sort(characters, function(a, b)
        return a.Uuid.EntityUuid < b.Uuid.EntityUuid
    end)

    return characters
end

function ClientUnlock.BuyChar(root, unlock)
    local grp = root:AddGroup(U.RandomId())

    ---@type ExtuiButton
    local btn = grp:AddButton(__("Buy"))
    btn.IDContext = U.RandomId()
    btn.Label = string.format("    %s    ", __("Buy"))

    ---@type ExtuiPopup
    local popup = grp:AddPopup("")
    popup.IDContext = U.RandomId()
    popup:AddSeparatorText(__("Buy for character"))

    local list = {}
    local function createPopup(unlock)
        for _, b in pairs(list) do
            b:Destroy()
        end
        list = {}

        for i, u in ipairs(ClientUnlock.GetCharacters()) do
            local name
            if u.CustomName then
                name = u.CustomName.Name
            else
                name = Localization.Get(u.DisplayName.NameKey.Handle.Handle)
            end

            local uuid = u.Uuid.EntityUuid

            ---@type ExtuiButton
            local b = popup:AddButton("")
            b.IDContext = U.RandomId()
            b.Label = string.format("%s", name)
            table.insert(list, b)
            b.Size = { 200, 0 }

            local ping = popup:AddButton("")
            ping.IDContext = U.RandomId()
            ping.Label = __("Ping")
            ping.OnClick = function()
                Net.Send("Ping", { Target = uuid })
            end
            ping.SameLine = true
            table.insert(list, ping)

            if unlock.BoughtBy[uuid] then
                b.Label = string.format("%s (%s)", name, __("bought"))

                -- b:SetStyle("Alpha", 0.5)
            end

            b.Label = string.format("  %s  ", b.Label)

            b.OnClick = function()
                b:SetStyle("Alpha", 0.2)
                Net.Request("BuyUnlock", { Id = unlock.Id, Character = uuid }):After(function(event)
                    local ok, res = table.unpack(event.Payload)

                    if not ok then
                        Event.Trigger("Error", res)
                    else
                        Event.Trigger("Success", __("Unlock %s bought for %s.", unlock.Name, name))
                    end

                    -- might not exist anymore
                    pcall(function()
                        b:SetStyle("Alpha", 1)
                    end)
                end)
            end
        end
    end

    Event.On("StateChange", function(state)
        for _, new in pairs(state.Unlocks) do
            if new.Id == unlock.Id then
                local buyable = new.Amount == nil or new.Bought < new.Amount
                btn.Visible = buyable

                popup.Visible = buyable
                createPopup(new)
                return
            end
        end
    end):Exec(State)

    btn.OnClick = function()
        popup:Open()
    end

    grp:AddText("").SameLine = true

    grp:AddDummy(1, 2)

    return grp
end
