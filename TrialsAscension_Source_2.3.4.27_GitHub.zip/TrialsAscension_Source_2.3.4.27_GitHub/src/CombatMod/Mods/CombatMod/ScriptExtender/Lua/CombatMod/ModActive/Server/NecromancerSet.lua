NecromancerSet = NecromancerSet or {}

-- Trials Ascension V8.4Z7 - native spell resurrection + party follower control.
local SET = {
    ["Helmet"] = "TOT_NECRO_HOOD",
    ["Breast"] = "TOT_NECRO_ARMOR",
    ["Cloak"] = "TOT_NECRO_CAPE",
    ["Melee Main Weapon"] = "TOT_NECRO_STAFF",
    ["Melee Offhand Weapon"] = "TOT_NECRO_TORCH",
    ["Ranged Main Weapon"] = "TOT_NECRO_BOW",
}

local TIERS = {
    {Count=2, Passive="TOT_NECRO_SET_2_PASSIVE", Status="TOT_NECRO_SET_2_STATUS"},
    {Count=4, Passive="TOT_NECRO_SET_4_PASSIVE", Status="TOT_NECRO_SET_4_STATUS"},
    {Count=6, Passive="TOT_NECRO_SET_6_PASSIVE", Status="TOT_NECRO_SET_6_STATUS"},
}

local SUMMON_BUFF = "TOT_NECRO_SET_4_SUMMON_BUFF"
local SET6_SPELL = "Target_TOT_NecroSet_ReanimateChampion"
local SET6_USED = "TOT_NECRO_SET_6_USED"
local resurrectionGuard = {}
local reanimationPending = {}
local reanimationPendingByTarget = {}
local SET2_USED = "TOT_NECRO_SET_2_USED"

-- Canonical UUID keys survive Osiris name prefixes and save/reload.
local function key(character)
    return tostring(character):sub(-36):lower()
end

local function reviveUses()
    PersistentVars.NecromancerReviveUsed = PersistentVars.NecromancerReviveUsed or {}
    return PersistentVars.NecromancerReviveUsed
end

local function equippedStat(character, slot)
    local ok, guid = pcall(Osi.GetEquippedItem, character, slot)
    if not ok or not guid or guid == "" then return nil end
    local entity = Ext.Entity.Get(guid)
    return entity and entity.ServerItem and entity.ServerItem.Stats or nil
end

function NecromancerSet.CountPieces(character)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 then return 0 end
    local count = 0
    for slot, stat in pairs(SET) do
        if equippedStat(character, slot) == stat then count = count + 1 end
    end
    return count
end

local function setTier(character, tier, active)
    if active then
        if Osi.HasPassive(character, tier.Passive) ~= 1 then pcall(Osi.AddPassive, character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) ~= 1 then pcall(Osi.ApplyStatus, character, tier.Status, -1, 1, character) end
    else
        if Osi.HasPassive(character, tier.Passive) == 1 then pcall(Osi.RemovePassive, character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) == 1 then pcall(Osi.RemoveStatus, character, tier.Status) end
        -- The 6-piece spell is granted directly by Lua and must disappear with the sixth piece.
        if tier.Count == 6 then pcall(Osi.RemoveSpell, character, SET6_SPELL, 0) end
    end
end

local function raisedTable()
    PersistentVars.NecromancerRaisedServants = PersistentVars.NecromancerRaisedServants or {}
    return PersistentVars.NecromancerRaisedServants
end

local function ritualUses()
    PersistentVars.NecromancerRitualUsed = PersistentVars.NecromancerRitualUsed or {}
    return PersistentVars.NecromancerRitualUsed
end

local function ownerForBoost(character)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 then return nil end
    if Osi.IsSummon(character) == 1 then
        local ok, owner = pcall(Osi.CharacterGetOwner, character)
        if ok and owner and owner ~= "" then return owner end
    end
    for owner, servant in pairs(raisedTable()) do
        if key(servant) == key(character) then return owner end
    end
    return nil
end

function NecromancerSet.UpdateCreatureBoost(character)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 then return end
    local owner = ownerForBoost(character)
    local should = owner and NecromancerSet.CountPieces(owner) >= 4
    if should then
        if Osi.HasAppliedStatus(character, SUMMON_BUFF) ~= 1 then pcall(Osi.ApplyStatus, character, SUMMON_BUFF, -1, 1, owner) end
    elseif Osi.HasAppliedStatus(character, SUMMON_BUFF) == 1 then
        pcall(Osi.RemoveStatus, character, SUMMON_BUFF)
    end
end

local ensureSet6SpellGrant

local function scanCreatures()
    local ok, entities = pcall(function() return Ext.Entity.GetAllEntitiesWithComponent("ServerCharacter") end)
    if not ok or not entities then return end
    for _, entity in pairs(entities) do
        local uuid = entity.Uuid and entity.Uuid.EntityUuid
        if uuid then NecromancerSet.UpdateCreatureBoost(uuid) end
    end
end

function NecromancerSet.Update(character)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 then return end
    local count = NecromancerSet.CountPieces(character)
    for _, tier in ipairs(TIERS) do setTier(character, tier, count >= tier.Count) end
    if count >= 6 then Defer(40, function() ensureSet6SpellGrant(character, false) end) end
    Defer(100, scanCreatures)
end

-- V8.4Z6: ONE source for the action.
-- Z3 mixed Passive Boosts=UnlockSpell with a Lua AddSpell fallback, which produced
-- two identical VI entries. The passive is now only a set marker; Lua owns the grant.
-- forceRefresh migrates saves that previously had both sources: remove the old passive
-- and any direct copy, re-add the marker passive, then add exactly one spell.
ensureSet6SpellGrant = function(character, forceRefresh)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 then return end
    if NecromancerSet.CountPieces(character) < 6 then
        pcall(Osi.RemoveSpell, character, SET6_SPELL, 0)
        return
    end

    if forceRefresh then
        if Osi.HasPassive(character, "TOT_NECRO_SET_6_PASSIVE") == 1 then
            pcall(Osi.RemovePassive, character, "TOT_NECRO_SET_6_PASSIVE")
        end
        -- Remove the stale direct grant left by Z3, if present.
        pcall(Osi.RemoveSpell, character, SET6_SPELL, 0)
    end

    if Osi.HasPassive(character, "TOT_NECRO_SET_6_PASSIVE") ~= 1 then
        pcall(Osi.AddPassive, character, "TOT_NECRO_SET_6_PASSIVE")
    end

    Defer(60, function()
        if Osi.IsCharacter(character) ~= 1 or NecromancerSet.CountPieces(character) < 6 then return end
        local hasSpell = 0
        local okHas, valueHas = pcall(Osi.HasSpell, character, SET6_SPELL)
        if okHas then hasSpell = tonumber(valueHas) or 0 end
        if hasSpell ~= 1 then
            pcall(Osi.AddSpell, character, SET6_SPELL, 0, 0)
        end
    end)
end

local function removeFromScenarioEnemyTracking(target)
    local ok, s = pcall(function() return Scenario and Scenario.Current and Scenario.Current() or nil end)
    if not ok or not s then return end

    local function removeGuid(list)
        if not list then return end
        for i=#list,1,-1 do
            local e=list[i]
            if e and e.GUID and U and U.UUID and U.UUID.Equals and U.UUID.Equals(e.GUID,target) then
                table.remove(list,i)
            end
        end
    end

    removeGuid(s.SpawnedEnemies)
    removeGuid(s.KilledEnemies)
    if PersistentVars and PersistentVars.SpawnedEnemies then
        PersistentVars.SpawnedEnemies[target] = nil
    end
end

-- Scenario.lua calls this from its Resurrected listener. A corpse raised by the
-- Necromancer set must not be reinserted into the Trials enemy roster between the
-- native Resurrect functor and AddPartyFollower.
function NecromancerSet.IsPendingReanimation(target)
    return target and reanimationPendingByTarget[key(target)] ~= nil or false
end

local function clearPending(caster, target)
    if caster then reanimationPending[key(caster)] = nil end
    if target then reanimationPendingByTarget[key(target)] = nil end
end

local function validateReanimation(caster, target)
    if not caster or not target then return false end
    if NecromancerSet.CountPieces(caster) < 6 or reanimationPending[key(caster)] then return false end
    if Osi.IsCharacter(target) ~= 1 or Osi.IsPlayer(target) == 1 or Osi.IsDead(target) ~= 1 then return false end
    if ritualUses()[key(caster)] or Osi.HasAppliedStatus(caster, SET6_USED) == 1 then return false end
    local okLevel, level = pcall(Osi.GetLevel, target)
    level = okLevel and tonumber(level) or 999
    return level <= 15
end

local function beginReanimation(caster, target)
    if not validateReanimation(caster, target) then return end
    reanimationPending[key(caster)] = target
    reanimationPendingByTarget[key(target)] = caster

    -- Fail-safe only: if the native Resurrect functor does not fire a Resurrected
    -- event, clear the transient guard. We intentionally do NOT call Resurrect here.
    Defer(1500, function()
        if reanimationPendingByTarget[key(target)] == caster then
            clearPending(caster, target)
        end
    end)
end

local function finishReanimation(caster, target)
    if not caster or not target then return end
    if reanimationPendingByTarget[key(target)] ~= caster then return end
    clearPending(caster, target)

    if Osi.IsCharacter(target) ~= 1 or Osi.IsDead(target) == 1 then return end

    local tbl = raisedTable()
    local prior = tbl[caster]
    if prior and prior ~= target then expireServant(caster, prior) end

    -- Remove the old enemy bookkeeping before attaching it to the player.
    removeFromScenarioEnemyTracking(target)
    pcall(Osi.SetHitpointsPercentage, target, 100, "Guaranteed")

    local attached, attachError = pcall(Osi.AddPartyFollower, target, caster)
    if not attached then
        L.Error("Necromancer follower attach failed: " .. tostring(attachError))
        return
    end

    tbl[caster] = target
    ritualUses()[key(caster)] = caster
    pcall(Osi.ApplyStatus, caster, SET6_USED, -1, 1, caster)
    NecromancerSet.UpdateCreatureBoost(target)
end

local function scheduledUpdate(character)
    Defer(120, function() NecromancerSet.Update(character) end)
end

Ext.Osiris.RegisterListener("Equipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("Unequipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character)
    Defer(250, function()
        NecromancerSet.Update(character)
        NecromancerSet.UpdateCreatureBoost(character)
    end)
end)
Ext.Osiris.RegisterListener("EnteredLevel", 3, "after", function(object, _, _)
    Defer(250, function() NecromancerSet.UpdateCreatureBoost(object) end)
end)

-- 2-piece: consume before Resurrect; only a completed long rest resets the ledger.
Ext.Osiris.RegisterListener("Died", 1, "after", function(character)
    local tbl = raisedTable()
    for owner, servant in pairs(tbl) do
        if key(servant) == key(character) then
            tbl[owner] = nil
            pcall(Osi.RemovePartyFollower, servant, owner)
            pcall(Osi.RemoveStatus, servant, SUMMON_BUFF)
        end
    end
    local used = reviveUses()
    if resurrectionGuard[character] or used[key(character)]
        or Osi.HasAppliedStatus(character, SET2_USED) == 1
        or NecromancerSet.CountPieces(character) < 2 then return end
    resurrectionGuard[character] = true
    if Osi.IsDead(character) == 1 and NecromancerSet.CountPieces(character) >= 2 then
        used[key(character)] = character
        pcall(Osi.ApplyStatus, character, SET2_USED, -1, 1, character)
        pcall(Osi.Resurrect, character)
        Defer(100, function()
            if Osi.IsCharacter(character) == 1 then pcall(Osi.SetHitpointsPercentage, character, 50, "Guaranteed") end
            resurrectionGuard[character] = nil
        end)
    else
        resurrectionGuard[character] = nil
    end
end)

Ext.Osiris.RegisterListener("UsingSpellOnTarget", 6, "before", function(caster, target, spell, _, _, _)
    if spell == SET6_SPELL then beginReanimation(caster, target) end
end)

Ext.Osiris.RegisterListener("Resurrected", 1, "after", function(target)
    local caster = reanimationPendingByTarget[key(target)]
    if caster then Defer(1, function() finishReanimation(caster, target) end) end
end)

Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    for _, character in pairs(reviveUses()) do
        if Osi.IsCharacter(character) == 1 then pcall(Osi.RemoveStatus, character, SET2_USED) end
    end
    PersistentVars.NecromancerReviveUsed = {}
    for _, character in pairs(ritualUses()) do
        if Osi.IsCharacter(character) == 1 then pcall(Osi.RemoveStatus, character, SET6_USED) end
    end
    PersistentVars.NecromancerRitualUsed = {}
    local tbl = raisedTable()
    for owner, servant in pairs(tbl) do expireServant(owner, servant) end
    PersistentVars.NecromancerRaisedServants = {}
    Defer(300, function()
        for _, character in pairs(GU.DB.GetPlayers()) do
            if Osi.HasAppliedStatus(character, SET6_USED) == 1 then pcall(Osi.RemoveStatus, character, SET6_USED) end
            NecromancerSet.Update(character)
        end
        scanCreatures()
    end)
end)

GameState.OnLoad(function()
    Defer(900, function()
        for _, character in pairs(GU.DB.GetPlayers()) do
            NecromancerSet.Update(character)
            ensureSet6SpellGrant(character, true)
        end
        scanCreatures()
    end)
end, true)
