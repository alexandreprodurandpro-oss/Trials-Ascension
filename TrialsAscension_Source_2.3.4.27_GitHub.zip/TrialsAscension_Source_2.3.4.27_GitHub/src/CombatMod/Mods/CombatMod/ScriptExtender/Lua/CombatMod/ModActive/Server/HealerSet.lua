HealerSet = HealerSet or {}

local SET = {
    ["Gloves"] = "TOT_HEALER_REVIVING_HANDS",
    ["Boots"] = "TOT_HEALER_AID_BOOTS",
    ["Amulet"] = "TOT_HEALER_RESTORATION_AMULET",
}

local TIERS = {
    {2,"TOT_HEALER_SET_2_PASSIVE","TOT_HEALER_SET_2_STATUS"},
    {3,"TOT_HEALER_SET_3_PASSIVE","TOT_HEALER_SET_3_STATUS"},
    {5,"TOT_HEALER_SET_5_PASSIVE","TOT_HEALER_SET_5_STATUS"},
}

local function equippedStat(c, slot)
    local guid = Osi.GetEquippedItem(c, slot)
    if not guid or guid == "" then return nil end
    local entity = Ext.Entity.Get(guid)
    return entity and entity.ServerItem and entity.ServerItem.Stats or nil
end

local function countPieces(c)
    local n = 0
    for slot, stat in pairs(SET) do
        if equippedStat(c, slot) == stat then n = n + 1 end
    end
    if equippedStat(c, "Ring") == "TOT_HEALER_SALVING_RING" or equippedStat(c, "Ring2") == "TOT_HEALER_SALVING_RING" then
        n = n + 1
    end
    if equippedStat(c, "Ring") == "TOT_HEALER_WHISPERING_PROMISE" or equippedStat(c, "Ring2") == "TOT_HEALER_WHISPERING_PROMISE" then
        n = n + 1
    end
    return n
end

function HealerSet.Update(c)
    if not c or Osi.IsCharacter(c) ~= 1 then return end
    local count = countPieces(c)
    for _, t in ipairs(TIERS) do
        local on = count >= t[1]
        if on and Osi.HasPassive(c, t[2]) ~= 1 then Osi.AddPassive(c, t[2]) end
        if not on and Osi.HasPassive(c, t[2]) == 1 then Osi.RemovePassive(c, t[2]) end
        if on and Osi.HasAppliedStatus(c, t[3]) ~= 1 then Osi.ApplyStatus(c, t[3], -1, 1, c) end
        if not on and Osi.HasAppliedStatus(c, t[3]) == 1 then Osi.RemoveStatus(c, t[3]) end
    end
end

local function later(c)
    Schedule(function() HealerSet.Update(c) end)
end

Ext.Osiris.RegisterListener("Equipped",2,"after",function(_,c) later(c) end)
Ext.Osiris.RegisterListener("Unequipped",2,"after",function(_,c) later(c) end)
Ext.Osiris.RegisterListener("CharacterJoinedParty",1,"after",function(c) later(c) end)
Ext.Osiris.RegisterListener("LongRestFinished",0,"after",function()
    for _,c in pairs(GU.DB.GetPlayers()) do HealerSet.Update(c) end
end)
GameState.OnLoad(function()
    Schedule(function()
        for _,c in pairs(GU.DB.GetPlayers()) do HealerSet.Update(c) end
    end)
end,true)
