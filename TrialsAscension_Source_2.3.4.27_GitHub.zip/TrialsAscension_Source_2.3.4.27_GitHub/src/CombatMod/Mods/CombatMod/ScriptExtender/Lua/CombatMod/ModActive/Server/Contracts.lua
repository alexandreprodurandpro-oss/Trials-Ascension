Contracts = Contracts or {}

local ASMODEUS_NAME = "MOD_Asmo_Combat"
local ASMODEUS_TEMPLATE = "d8caab24-6964-45c4-9bd2-ddb624a44119"

local ContractDefinitions = {
    Kill25     = { Kind="Kills",       Need=25,  Currency=50,  Tokens=0 },
    Kill50     = { Kind="Kills",       Need=50,  Currency=100, Tokens=0 },
    Kill100    = { Kind="Kills",       Need=100, Currency=200, Tokens=0 },
    Kill200    = { Kind="Kills",       Need=200, Currency=400, Tokens=0 },
    Combat10   = { Kind="Combats",     Need=10,  Currency=100, Tokens=0 },
    Combat25   = { Kind="Combats",     Need=25,  Currency=250, Tokens=0 },
    Combat50   = { Kind="Combats",     Need=50,  Currency=500, Tokens=0 },
    Level10    = { Kind="Level",       Need=10,  Currency=200, Tokens=0 },
    Level20    = { Kind="Level",       Need=20,  Currency=500, Tokens=1 },
    Arena100   = { Kind="Combats",     Need=100, Currency=0,    Tokens=4 },
    Horde500   = { Kind="Kills",       Need=500, Currency=1000, Tokens=1 },

    -- V8.3A - new normal row
    Perfect10  = { Kind="PerfectClears", Need=10, Currency=500, Tokens=0 },
    NoRest15   = { Kind="NoRestStreak", Need=15, Currency=500, Tokens=0 },
    Conquest5  = { Kind="Milestones", Need=5, Currency=1000, Tokens=0 },

    -- V8.3A - divine row. x3/x5 deliberately track now without inventing an
    -- unvalidated item payout; rewards can be granted retroactively later.
    Gods1      = { Kind="AsmodeusKills", Need=1, Currency=1000, Tokens=5, ManualClaim=true, DivineUnlock=true,
        Items={"TOT_CONQ_HELMET","TOT_CONQ_RING"} },
    Gods3      = { Kind="AsmodeusKills", Need=3, Currency=500, Tokens=0, ManualClaim=true,
        Items={"TOT_CONQ_CAPE","TOT_CONQ_BOOTS","TOT_CONQ_ARMOR"} },
    Gods5      = { Kind="AsmodeusKills", Need=5, Currency=500, Tokens=0, ManualClaim=true,
        Items={"TOT_CONQ_AMULET","TOT_CONQ_GLOVES","TOT_CONQ_BLADE"} },
}

local function ensureState()
    if type(PersistentVars.Contracts) ~= "table" then PersistentVars.Contracts = {} end
    local c = PersistentVars.Contracts
    if type(c.Kills) ~= "number" then c.Kills = 0 end
    if type(c.BossKills) ~= "number" then c.BossKills = 0 end -- legacy/debug only
    if type(c.Combats) ~= "number" then c.Combats = 0 end
    if type(c.PerfectClears) ~= "number" then c.PerfectClears = 0 end
    if type(c.NoRestStreak) ~= "number" then c.NoRestStreak = 0 end
    if type(c.AsmodeusKills) ~= "number" then c.AsmodeusKills = 0 end
    if type(c.SimulatedLevel) ~= "number" then c.SimulatedLevel = 0 end
    if type(c.Completed) ~= "table" then c.Completed = {} end
    if type(c.Claimed) ~= "table" then c.Claimed = {} end
end


local countedAsmodeus = {}

local function isAsmodeusEnemy(enemy)
    return enemy and (enemy.Name == ASMODEUS_NAME or enemy.TemplateId == ASMODEUS_TEMPLATE)
end

local function countAsmodeus(enemy, guid)
    ensureState()
    local key = guid or (enemy and enemy.GUID)
    if key and countedAsmodeus[key] then return false end
    if not isAsmodeusEnemy(enemy) then return false end
    if key then countedAsmodeus[key] = true end
    PersistentVars.Contracts.AsmodeusKills = PersistentVars.Contracts.AsmodeusKills + 1
    L.Info("Divine contract: Asmodeus defeated", PersistentVars.Contracts.AsmodeusKills)
    Contracts.Evaluate()
    SyncState()
    return true
end

local function milestoneCount()
    local n = 0
    if PersistentVars.GoblinMilestone50Done then n = n + 1 end
    if PersistentVars.GnollMilestone75Done then n = n + 1 end
    if PersistentVars.GithMilestone100Done then n = n + 1 end
    if PersistentVars.BOOOALMilestone150Done then n = n + 1 end
    if PersistentVars.ColossusMilestone200Done then n = n + 1 end
    return n
end

local function realPartyLevel()
    local best = Player.Level() or 1
    local ok, pcs = pcall(GE.GetPCs)
    if ok and pcs then
        for _, entity in pairs(pcs) do
            if entity and entity.EocLevel and entity.EocLevel.Level then
                best = math.max(best, entity.EocLevel.Level)
            end
        end
    end
    return best
end

function Contracts.Level()
    ensureState()
    return math.max(realPartyLevel(), PersistentVars.Contracts.SimulatedLevel or 0)
end

function Contracts.Progress(def)
    ensureState()
    if def.Kind == "Level" then return Contracts.Level() end
    if def.Kind == "Milestones" then return milestoneCount() end
    return PersistentVars.Contracts[def.Kind] or 0
end

function Contracts.Evaluate()
    ensureState()
    local changed = false
    for id, def in pairs(ContractDefinitions) do
        if not PersistentVars.Contracts.Completed[id] and Contracts.Progress(def) >= def.Need then
            PersistentVars.Contracts.Completed[id] = true
            if not def.ManualClaim then
                if def.Currency > 0 then PersistentVars.Currency = (PersistentVars.Currency or 0) + def.Currency end
                if def.Tokens > 0 then PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or 0) + def.Tokens end
                if def.DivineUnlock then PersistentVars.DivineRewardsUnlocked = true end
            end
            Player.Notify(Localization.Get("h72a00000000000000000000000000006"))
            changed = true
        end
    end
    if changed then SyncState() end
end


local DIVINE_ITEM_DEFS = {
    TOT_CONQ_HELMET = "8eef2dfe-bfcc-5cfa-a60f-9fe89dd67716",
    TOT_CONQ_ARMOR = "7a5d768d-3bcf-57e5-8733-b7b35be6c87f",
    TOT_CONQ_GLOVES = "0f90b44b-7e5f-519c-9e87-3dd53daed4fa",
    TOT_CONQ_BOOTS = "6b2d9ab7-0188-4c83-b664-399e2cc1d4a1",
    TOT_CONQ_CAPE = "ea23bc7d-3034-4a77-b664-c7b9bba5f811",
    TOT_CONQ_RING = "3aca14f5-0476-56ff-806d-6565ccf51117",
    TOT_CONQ_BLADE = "b9a508ed-661e-5c29-a75f-a1bfb68b9d62",
    TOT_CONQ_AMULET = "9875f590-c985-57e0-a358-8f79bc8059f9",
}

local function spawnAtFeet(character, stat)
    local root = DIVINE_ITEM_DEFS[stat]
    if not root then return false, TA_Text("Unknown item: ", "Objet inconnu : ")..tostring(stat) end
    local x,y,z = Osi.GetPosition(character)
    local ok, guid = pcall(Osi.CreateAt, root, x, y, z, 0, 1, "")
    if not ok or not guid or guid == "" then return false, tostring(guid) end
    return true, guid
end

function Contracts.ClaimDivine(id, character)
    ensureState()
    local def = ContractDefinitions[id]
    if not def or not def.ManualClaim then return false, TA_Text("Invalid contract", "Contrat invalide") end
    if not PersistentVars.Contracts.Completed[id] then return false, TA_Text("Objective not complete", "Objectif non terminé") end
    if PersistentVars.Contracts.Claimed[id] then return false, TA_Text("Already claimed", "Déjà récupéré") end
    if not character or Osi.IsCharacter(character) ~= 1 then character = Player.Host() end

    for _, item in ipairs(def.Items or {}) do
        local ok, err = spawnAtFeet(character, item)
        if not ok then return false, err end
    end

    if def.Currency and def.Currency > 0 then
        PersistentVars.Currency = (PersistentVars.Currency or 0) + def.Currency
    end
    if def.Tokens and def.Tokens > 0 then
        PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or 0) + def.Tokens
    end
    if def.DivineUnlock then PersistentVars.DivineRewardsUnlocked = true end

    PersistentVars.Contracts.Claimed[id] = true
    SyncState()
    return true, TA_Text("Claimed", "Récupéré")
end

function Contracts.DebugAdd(kind, amount)
    ensureState()
    if kind == "Level" then
        PersistentVars.Contracts.SimulatedLevel = math.max(0, amount or 0)
    elseif PersistentVars.Contracts[kind] ~= nil then
        PersistentVars.Contracts[kind] = math.max(0, PersistentVars.Contracts[kind] + (amount or 0))
    end
    Contracts.Evaluate()
    SyncState()
end

function Contracts.ResetDebug()
    PersistentVars.Contracts = {
        Kills=0, BossKills=0, Combats=0, PerfectClears=0,
        NoRestStreak=0, AsmodeusKills=0, SimulatedLevel=0, Completed={}, Claimed={}
    }
    PersistentVars.DivineRewardsUnlocked = false
    SyncState()
end

function Contracts.Definitions() return ContractDefinitions end

Event.On("ScenarioEnemyKilled", function(scenario, enemy)
    ensureState()
    PersistentVars.Contracts.Kills = PersistentVars.Contracts.Kills + 1
    if enemy and enemy.IsBoss then
        PersistentVars.Contracts.BossKills = PersistentVars.Contracts.BossKills + 1
    end
    countAsmodeus(enemy, enemy and enemy.GUID or nil)
    Contracts.Evaluate()
end)

-- Direct death fallback: this does not rely on the generic boss flag and catches
-- real Asmodeus deaths even if another ScenarioEnemyKilled listener/path changes.
Ext.Osiris.RegisterListener("Died", 1, "after", function(guid)
    local key = U.UUID.Extract(guid)
    local enemy = PersistentVars.SpawnedEnemies and PersistentVars.SpawnedEnemies[key] or nil
    countAsmodeus(enemy, key)
end)

Event.On("ScenarioPerfectClear", function(scenario)
    ensureState()
    PersistentVars.Contracts.PerfectClears = PersistentVars.Contracts.PerfectClears + 1
    Contracts.Evaluate()
end)

Event.On("ScenarioEnded", function(scenario)
    ensureState()
    PersistentVars.Contracts.Combats = PersistentVars.Contracts.Combats + 1
    PersistentVars.Contracts.NoRestStreak = PersistentVars.Contracts.NoRestStreak + 1
    Contracts.Evaluate()
end)

Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    ensureState()
    -- Once completed, NoRest15 stays completed; only the live streak resets.
    PersistentVars.Contracts.NoRestStreak = 0
    SyncState()
end)

Ext.Osiris.RegisterListener("LeveledUp", 1, "after", function(character)
    Defer(250, Contracts.Evaluate)
end)

GameState.OnLoad(function()
    ensureState()
    Defer(500, Contracts.Evaluate)
end)

Event.On("ScenarioStarted", function() countedAsmodeus = {} end)
