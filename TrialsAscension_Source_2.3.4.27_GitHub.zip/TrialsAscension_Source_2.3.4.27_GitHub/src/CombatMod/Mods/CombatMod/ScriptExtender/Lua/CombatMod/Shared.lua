---@type Mod
Mod = Require("Hlib/Mod")
Mod.EnableRCE = false -- V8.4V: network code execution removed, not merely gated.
Mod.Prefix = "Trials Ascension"
-- Internal compatibility path: do not move existing player/config/gameplay-table files during the rebrand.
Mod.StoragePrefix = "Trials of Tav"
Mod.TableKey = "ToT"

Require("Hlib/StandardLib") -- extends global metatables

---@type Utils
local Utils = Require("Hlib/Utils")

---@type Log
local Log = Require("Hlib/Log")

---@type GameUtils
local GameUtils = Require("Hlib/GameUtils")

U = Utils
L = Log
UT = Utils.Table
US = Utils.String
GU = GameUtils
GE = GameUtils.Entity
GC = GameUtils.Character

---@type IO
IO = Require("Hlib/IO")

Mod.Dev = IO.Exists("DevMode")
Mod.Debug = Mod.Dev

---@type GameState
GameState = Require("Hlib/GameState")

---@type ModEvent
ModEvent = Require("Hlib/ModEvent")

---@type Async
Async = Require("Hlib/Async")
WaitUntil = Async.WaitUntil
WaitTicks = Async.WaitTicks
RetryUntil = Async.RetryUntil
Schedule = Async.Schedule
Defer = Async.Defer
Debounce = Async.Debounce
Throttle = Async.Throttle
Interval = Async.Interval

---@type Libs
Libs = Require("Hlib/Libs")

---@type Net
Net = Require("Hlib/Net")

---@type Event
Event = Require("Hlib/Event")

---@type Localization
Localization = Require("Hlib/Localization")
__ = Localization.Localize

-- Trials Ascension player-facing bilingual helper.
-- French is detected through an existing stable native/localized string;
-- unsupported locales fall back to English.
function TA_IsFrench()
    local ok, value = pcall(function() return Localization.Localize("Buy") end)
    return ok and value == "Acheter"
end

function TA_Text(english, french)
    return TA_IsFrench() and french or english
end

-- Legacy strings inherited from the original framework are not all present in
-- ToT's FR loca tables. Keep them centralized here so every existing __("...")
-- call still resolves to French instead of silently falling back to English.
local TA_INLINE_FR = {
    ["Fully Restore Character"] = "Restaurer complètement le personnage",
    ["Heal character and restore used spells."] = "Soigne le personnage et restaure les sorts utilisés.",
    ["Skipped interaction with %s"] = "Interaction avec %s ignorée",
    ["Auto unlocking"] = "Déverrouillage automatique",
    ["Auto disarming"] = "Désamorçage automatique",
    ["Skipped combat with %s"] = "Combat avec %s ignoré",
    ["Teleporting to different ACT"] = "Téléportation vers un autre ACTE",
    ["Reward not found."] = "Récompense introuvable.",
    ["Cannot buy while in combat."] = "Impossible d'acheter pendant un combat.",
    ["Reward already purchased."] = "Récompense déjà achetée.",
    ["Combat is Starting."] = "Le combat commence.",
    ["Scenario: %s"] = "Scénario : %s",
    ["Round: %s"] = "Manche : %s",
    ["Total Rounds: %s"] = "Nombre total de manches : %s",
    ["Upcoming Spawns: %s"] = "Apparitions à venir : %s",
    ["Kill Score: %s"] = "Score d'éliminations : %s",
    ["Enemy %s spawned."] = "Ennemi %s apparu.",
    ["Round %d"] = "Manche %d",
    ["Leave camp to join the battle."] = "Quittez le camp pour rejoindre le combat.",
    ["Entered combat area."] = "Zone de combat atteinte.",
    ["Scenario restored."] = "Scénario restauré.",
    ["Failed to restore scenario."] = "Échec de la restauration du scénario.",
    ["Scenario %s started."] = "Scénario %s lancé.",
    ["Scenario ended."] = "Scénario terminé.",
    ["Scenario stopped."] = "Scénario arrêté.",
    ["All enemies are dead."] = "Tous les ennemis sont morts.",
    ["%d enemies left."] = "%d ennemis restants.",
    ["Returned to camp."] = "Retour au camp effectué.",
    ["Enemy %s joined."] = "Ennemi %s ajouté.",
    ["Enemy %s rejoined."] = "Ennemi %s réintégré.",
    ["Enemy %s killed."] = "Ennemi %s éliminé.",
    ["Combat started."] = "Combat commencé.",
    ["Dropping loot."] = "Génération du butin.",
    ["Your RogueScore changed: %d -> %d!"] = "Votre RogueScore a changé : %d -> %d !",
    ["Milestone encounter: Goblin Raid!"] = "Combat de palier : Raid gobelin !",
    ["Milestone encounter: Gnoll Hunt!"] = "Combat de palier : Chasse aux gnolls !",
    ["Milestone encounter: Githyanki Patrol!"] = "Combat de palier : Patrouille githyanki !",
    ["Select a Roguelike scenario to start!"] = "Sélectionnez un scénario Roguelike pour commencer !",
    ["Teleporting back to camp in %d seconds."] = "Retour au camp dans %d secondes.",
    ["You found the secret cow level!"] = "Vous avez trouvé le niveau secret des vaches !",
    ["You have incurred the wrath of Nature's Vengeance!"] = "Vous avez provoqué la colère de la Vengeance de la Nature !",
    ["Your Currency changed: %d -> %d!"] = "Votre monnaie a changé : %d -> %d !",
    ["Host has restricted buying unlocks."] = "L'hôte a restreint l'achat des pouvoirs.",
    ["Unlock not found."] = "Pouvoir introuvable.",
    ["Unlock out of stock."] = "Pouvoir épuisé.",
    ["Unlock needs a character."] = "Ce pouvoir nécessite un personnage.",
    ["Not enough currency."] = "Monnaie insuffisante.",
    ["Scenario not started."] = "Scénario non lancé.",
    ["Cannot stop while in progress."] = "Impossible d'arrêter pendant la progression.",
    ["Cannot teleport while in combat."] = "Impossible de se téléporter pendant un combat.",
    ["Map not found."] = "Carte introuvable.",
    ["%s is now the game master."] = "%s est maintenant le maître de partie.",
    ["Recruiting %s."] = "Recrutement de %s.",
    ["Cannot change factions while in combat."] = "Impossible de changer les factions pendant un combat.",
    ["Cannot use this function while in combat."] = "Impossible d'utiliser cette fonction pendant un combat.",
    ["Loot filter updated"] = "Filtre de butin mis à jour",
    ["Picked up %d items."] = "%d objets ramassés.",
    ["Destroyed %d items."] = "%d objets détruits.",
    ["Persisting config..."] = "Sauvegarde de la configuration...",
    ["Resetting config..."] = "Réinitialisation de la configuration...",
    ["Default config..."] = "Configuration par défaut...",
    ["Active"] = "Actif",
    ["Out of stock"] = "Épuisé",
    ["Unlock %s bought."] = "Pouvoir %s acheté.",
    ["bought"] = "acheté",
    ["Unlock %s bought for %s."] = "Pouvoir %s acheté pour %s.",
}

function TA_DisplayScenarioName(name)
    local names = {
        ["Roguelike (Bias Lower Tier)"] = TA_Text("Roguelike (Lower Tier Bias)", "Roguelike (Biais palier inférieur)"),
        ["Roguelike (Bias Balanced)"] = TA_Text("Roguelike (Balanced Bias)", "Roguelike (Biais équilibré)"),
        ["Roguelike (Bias Higher Tier)"] = TA_Text("Roguelike (Higher Tier Bias)", "Roguelike (Biais palier supérieur)"),
        ["RG50 - Goblin Raid"] = TA_Text("RG50 - Goblin Raid", "RG50 - Raid gobelin"),
        ["RG75 - Gnoll Hunt"] = TA_Text("RG75 - Gnoll Hunt", "RG75 - Chasse aux gnolls"),
        ["RG100 - Githyanki Patrol"] = TA_Text("RG100 - Githyanki Patrol", "RG100 - Patrouille githyanki"),
        ["RG150 - Cult of BOOOAL"] = TA_Text("RG150 - Cult of BOOOAL", "RG150 - Culte de BOOOAL"),
        ["RG200 - La Fosse des Colosses"] = TA_Text("RG200 - Pit of the Colossi", "RG200 - La Fosse des Colosses"),
        ["level 1"] = TA_Text("level 1", "niveau 1"),
        ["level 1 - 3"] = TA_Text("levels 1 - 3", "niveaux 1 - 3"),
        ["level 3 - 5"] = TA_Text("levels 3 - 5", "niveaux 3 - 5"),
        ["level 5 - 7"] = TA_Text("levels 5 - 7", "niveaux 5 - 7"),
        ["level 7 - 9"] = TA_Text("levels 7 - 9", "niveaux 7 - 9"),
        ["level 8 - 10"] = TA_Text("levels 8 - 10", "niveaux 8 - 10"),
        ["level 10 - 12"] = TA_Text("levels 10 - 12", "niveaux 10 - 12"),
        ["very hard"] = TA_Text("very hard", "très difficile"),
        ["ultra"] = TA_Text("ultra", "ultra"),
        ["epic"] = TA_Text("epic", "épique"),
        ["legendary"] = TA_Text("legendary", "légendaire"),
        ["impossible"] = TA_Text("impossible", "impossible"),
        ["demigods"] = TA_Text("demigods", "demi-dieux"),
        ["avatar"] = TA_Text("avatar", "avatar"),
        ["apex"] = TA_Text("apex", "apex"),
    }
    return names[tostring(name)] or tostring(name or "")
end

function TA_DisplayMapName(name)
    local names = {
        ["Goblin Camp (exterior)"] = TA_Text("Goblin Camp (exterior)", "Camp gobelin (extérieur)"),
        ["Gnoll Hill"] = TA_Text("Gnoll Hill", "Colline des gnolls"),
        ["Shadow Cursed Lands 3 (Ambush House)"] = TA_Text("Shadow-Cursed Lands 3 (Ambush House)", "Terres maudites par l'ombre 3 (Maison de l'embuscade)"),
        ["Shadow Cursed Lands 2"] = TA_Text("Shadow-Cursed Lands 2", "Terres maudites par l'ombre 2"),
        ["Myrkul Arena"] = TA_Text("Myrkul Arena", "Arène de Myrkul"),
        ["Gauntlet Of Shar (broken mirror room)"] = TA_Text("Gauntlet of Shar (broken mirror room)", "Gantelet de Shar (salle du miroir brisé)"),
    }
    return names[tostring(name)] or tostring(name or "")
end

local TA_BaseLocalize = Localization.Localize
__ = function(text, ...)
    if TA_IsFrench() then
        local base = tostring(text):gsub(";%d+$", "")
        local translated = TA_INLINE_FR[base]
        if translated then
            return string.format(translated, ...)
        end
    end
    return TA_BaseLocalize(text, ...)
end

Require("CombatMod/Constants")

---@param func fun(): any
---@param duration number
---@return fun(): any
function Cached(func, duration)
    local cache = nil
    local resetCache = Debounce(duration or 10000, function()
        cache = nil
    end)

    return function(...)
        resetCache()

        if cache then
            return table.unpack(cache)
        end

        cache = { func(...) }

        return table.unpack(cache)
    end
end
