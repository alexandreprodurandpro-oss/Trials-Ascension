SummonControl = SummonControl or {}
local STATUS = "TOT_AI_SUMMON_CONTROL"

local function isPlayerOwnedSummon(character)
    if not character or character == "" or Osi.IsCharacter(character) ~= 1 or Osi.IsSummon(character) ~= 1 then return false end
    local owner = Osi.CharacterGetOwner(character)
    if not owner or owner == "" then return false end
    return Player.IsPlayer(owner)
end

function SummonControl.Apply(character)
    if not isPlayerOwnedSummon(character) then return end
    if PersistentVars.SummonsAutomatic ~= false then
        if Osi.HasAppliedStatus(character, STATUS) ~= 1 then Osi.ApplyStatus(character, STATUS, -1, 1, character) end
    else
        if Osi.HasAppliedStatus(character, STATUS) == 1 then Osi.RemoveStatus(character, STATUS) end
    end
end

function SummonControl.ApplyExisting()
    local seen = {}
    local ok, rows = pcall(function() return Osi.DB_PartyMembers:Get(nil) end)
    if ok and rows then
        for _,row in ipairs(rows) do
            local character=row[1]
            if character and not seen[character] then seen[character]=true; SummonControl.Apply(character) end
        end
    end
    -- Some summons are not exposed in DB_PartyMembers immediately; scan ServerCharacter entities as a safe fallback.
    local ok2, entities = pcall(function() return Ext.Entity.GetAllEntitiesWithComponent("ServerCharacter") end)
    if ok2 and entities then
        for _,entity in pairs(entities) do
            local uuid = entity.Uuid and entity.Uuid.EntityUuid
            if uuid and not seen[uuid] then SummonControl.Apply(uuid) end
        end
    end
end

function SummonControl.SetAutomatic(value)
    PersistentVars.SummonsAutomatic = value == true
    SummonControl.ApplyExisting()
    SyncState()
end

-- EnteredLevel fires for dynamically spawned summons, so new vanilla/custom summons
-- are caught immediately without polling. Save-loaded summons are handled by ApplyExisting().
Ext.Osiris.RegisterListener("EnteredLevel", 3, "after", function(object, rootTemplate, level)
    Defer(100, function() SummonControl.Apply(object) end)
end)

-- CharacterEnteredRegion/2 is not present in current BG3 story; EnteredLevel, CharacterJoinedParty
-- and the load-time ApplyExisting scan already cover new and restored summons.
Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character)
    Defer(250, function() SummonControl.Apply(character) end)
end)
GameState.OnLoad(function() Defer(1000, SummonControl.ApplyExisting) end)
