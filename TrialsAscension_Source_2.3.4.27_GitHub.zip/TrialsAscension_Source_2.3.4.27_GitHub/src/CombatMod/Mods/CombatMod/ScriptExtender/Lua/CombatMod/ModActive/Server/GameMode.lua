Event.On("ScenarioStarted", function(scenario)
    Osi.AutoSave()
end)

-------------------------------------------------------------------------------------------------
--                                                                                             --
--                                       Rogue-like mode                                       --
--                                                                                             --
-------------------------------------------------------------------------------------------------

local function ifRogueLike(func)
    return function(...)
        if PersistentVars.RogueModeActive then
            func(...)
        end
    end
end

function GameMode.IsHardMode()
    return PersistentVars.HardMode
end

function GameMode.IsSuperHardMode()
    return PersistentVars.SuperHardMode
end

function GameMode.IsSoloMode()
    return PersistentVars.LoneWolfMode
end

function GameMode.IsGMMode()
    return PersistentVars.GMMode
end

function GameMode.StartRoguelike(template)
    if not PersistentVars.RogueModeActive then
        PersistentVars.RogueModeActive = true
        Event.Trigger("RogueModeChanged", PersistentVars.RogueModeActive)
    end

    PersistentVars.RogueScenario = template.Name
end

function GameMode.GetTiers(cow, harvard, score)
    -- define tiers and their corresponding difficulty values
    local tiers = {
        { name = C.EnemyTier[1], min = 0, value = 4, amount = #Enemy.GetByTier(C.EnemyTier[1]) },
        { name = C.EnemyTier[2], min = 25, value = 10, amount = #Enemy.GetByTier(C.EnemyTier[2]) },
        { name = C.EnemyTier[3], min = 45, value = 20, amount = #Enemy.GetByTier(C.EnemyTier[3]) },
        { name = C.EnemyTier[4], min = 70, value = 32, amount = #Enemy.GetByTier(C.EnemyTier[4]) },
        { name = C.EnemyTier[5], min = 90, value = 46, amount = #Enemy.GetByTier(C.EnemyTier[5]) },
        { name = C.EnemyTier[6], min = 140, value = 68, amount = #Enemy.GetByTier(C.EnemyTier[6]) },
        { name = C.EnemyTier[7], min = 200, value = 118, amount = #Enemy.GetByTier(C.EnemyTier[7]) },
        { name = C.EnemyTier[8], min = 250, value = 146, amount = #Enemy.GetByTier(C.EnemyTier[8]) },
        -- Internal apex key remains for compatibility; player-facing final grade is Palier 9 - Dieu.
        { name = C.EnemyTier[10], min = 350, value = 260, amount = #Enemy.GetByTier(C.EnemyTier[10]) },
    }

    if GameMode.IsHardMode() then
        tiers = {
            { name = C.EnemyTier[1], min = 0, value = 4, amount = #Enemy.GetByTier(C.EnemyTier[1]) },
            { name = C.EnemyTier[2], min = 15, value = 8, amount = #Enemy.GetByTier(C.EnemyTier[2]) },
            { name = C.EnemyTier[3], min = 30, value = 15, amount = #Enemy.GetByTier(C.EnemyTier[3]) },
            { name = C.EnemyTier[4], min = 50, value = 27, amount = #Enemy.GetByTier(C.EnemyTier[4]) },
            { name = C.EnemyTier[5], min = 70, value = 35, amount = #Enemy.GetByTier(C.EnemyTier[5]) },
            { name = C.EnemyTier[6], min = 110, value = 56, amount = #Enemy.GetByTier(C.EnemyTier[6]) },
            { name = C.EnemyTier[7], min = 155, value = 86, amount = #Enemy.GetByTier(C.EnemyTier[7]) },
            { name = C.EnemyTier[8], min = 195, value = 108, amount = #Enemy.GetByTier(C.EnemyTier[8]) },
            { name = C.EnemyTier[10], min = 300, value = 280, amount = #Enemy.GetByTier(C.EnemyTier[10]) },
        }
    end


    if GameMode.IsSuperHardMode() then
        tiers = {
            { name = C.EnemyTier[1], min = 0, value = 1, amount = #Enemy.GetByTier(C.EnemyTier[1]) },
            { name = C.EnemyTier[2], min = 5, value = 4, amount = #Enemy.GetByTier(C.EnemyTier[2]) },
            { name = C.EnemyTier[3], min = 15, value = 8, amount = #Enemy.GetByTier(C.EnemyTier[3]) },
            { name = C.EnemyTier[4], min = 30, value = 20, amount = #Enemy.GetByTier(C.EnemyTier[4]) },
            { name = C.EnemyTier[5], min = 45, value = 24, amount = #Enemy.GetByTier(C.EnemyTier[5]) },
            { name = C.EnemyTier[6], min = 80, value = 32, amount = #Enemy.GetByTier(C.EnemyTier[6]) },
            { name = C.EnemyTier[7], min = 115, value = 60, amount = #Enemy.GetByTier(C.EnemyTier[7]) },
            { name = C.EnemyTier[8], min = 145, value = 82, amount = #Enemy.GetByTier(C.EnemyTier[8]) },
            { name = C.EnemyTier[10], min = 250, value = 300, amount = #Enemy.GetByTier(C.EnemyTier[10]) },
        }
    end

    -- Never let the generator select an empty tier. This is important now that base T9
    -- can be empty when optional enemy packs are not installed.
    tiers = table.filter(tiers, function(tier)
        return (tier.amount or 0) > 0
    end)

    if cow then
        tiers = { { name = "TOT_OX_A", value = math.max(4, score / 100), amount = 100 } }
    end

    if harvard then
        tiers = { { name = "MOD_MysterySpawn_Combat", value = math.max(12, score / 100), amount = 100 } }
    end

    return tiers
end

function GameMode.GenerateScenario(score, tiers)

    L.Debug("Generate Scenario", score)

    local minRounds = 1
    local maxRounds = 10
    local preferredRounds = 3
    local emptyRoundChance = 0.2 -- 20% chance for a round to be empty
    local scoreTolerance = tiers[1].value
    if score > 70 then
       emptyRoundChance = 0.1
    elseif score > 120 then
        preferredRounds = 2
        emptyRoundChance = 0.05
    elseif score > 200 then
        preferredRounds = 2
        emptyRoundChance = 0
    elseif score > 500 then
        maxRounds = 20
        preferredRounds = 4
        emptyRoundChance = 0
        scoreTolerance = 50
    elseif score > 3000 then
        maxRounds = math.ceil(score / 100)
        preferredRounds = math.ceil(score / 300)
        emptyRoundChance = 0
        scoreTolerance = math.ceil(score / 30)
    end

    score = score >= tiers[1].value and score or tiers[1].value

    -- weighted random function to bias towards a preferred number of rounds
    local function weightedRandom(maxValue)
        local weights = {}
        local totalWeight = 0
        for i = minRounds, maxRounds do
            local weight = 1 / (math.abs(i - preferredRounds) + 1) -- adjusted weight calculation
            weights[i] = weight
            totalWeight = totalWeight + weight
        end
        local randomWeight = math.newRandom() * totalWeight
        for i = minRounds, maxRounds do
            randomWeight = randomWeight - weights[i]
            if randomWeight <= 0 then
                return i
            end
        end
        return maxRounds
    end

    local playerLevel = Player.Level()

    -- select a tier based on amount of enemies in tier
    local function selectTier(remainingValue)
        local validTiers = {}
        local totalWeight = 0
        for i, tier in ipairs(tiers) do
            if (GameMode.IsGMMode() or i <= playerLevel) and score >= (tier.min or tier.value) then -- handle min score
                if remainingValue >= tier.value then
                    local weight = tier.weight

                    table.insert(validTiers, { tier = tier, weight = weight })
                    totalWeight = totalWeight + weight
                end
            end
        end
        if #validTiers > 0 then
            local randomWeight = math.newRandom() * totalWeight
            for _, entry in ipairs(validTiers) do
                randomWeight = randomWeight - entry.weight
                if randomWeight <= 0 then
                    return entry.tier
                end
            end
        end

        return tiers[1] -- fallback to the lowest tier
    end

    -- generate a random timeline with bias and possible empty rounds
    local function generateTimeline(maxValue, failed)
        failed = failed + 1
        if failed > 1000 then
            L.Error("Failed to generate timeline", maxValue)
            return {}
        end

        local timeline = {}
        local numRounds = weightedRandom()
        local remainingValue = maxValue
        -- initialize rounds with empty tables
        for i = 1, numRounds do
            table.insert(timeline, {})
        end


        local roundsSkipped = {}
        local function distribute()
            local roundIndex = math.random(1, numRounds)

            if #timeline[roundIndex] > 10 then
                return
            end

            if roundsSkipped[roundIndex] then
                return
            end

            -- add a chance for the round to remain empty, except for the first round
            if
                roundIndex > 1
                and not roundsSkipped[roundIndex - 1]
                and #timeline[roundIndex] == 0
                and math.random() < emptyRoundChance
            then -- chance to skip adding a tier
                roundsSkipped[roundIndex] = true
                remainingValue = remainingValue + maxValue * emptyRoundChance
                return
            end

            local tier = selectTier(remainingValue)

            if remainingValue - tier.value >= 0 then
                table.insert(timeline[roundIndex], tier.name)
                remainingValue = remainingValue - tier.value

                local max = math.ceil(maxValue / 100)

                if #timeline[roundIndex] > max and numRounds < maxRounds then
                    -- too strong for single round in early appearances
                    if maxValue < 75 and tier.name == C.EnemyTier[5] then
                        if not timeline[roundIndex + 1] then
                            table.insert(timeline, roundIndex + 1, {})
                            numRounds = numRounds + 1
                        end
                    elseif maxValue < 120 and (tier.name == C.EnemyTier[6] or tier.name == C.EnemyTier[7]) then
                        table.insert(timeline, {})
                        numRounds = numRounds + 1
                        if not timeline[roundIndex + 1] then
                            table.insert(timeline, roundIndex + 1, {})
                            numRounds = numRounds + 1
                        end
                    elseif maxValue < 160 and (tier.name == C.EnemyTier[8] or tier.name == C.EnemyTier[9] or tier.name == C.EnemyTier[10]) then
						table.insert(timeline, {})
						table.insert(timeline, {})
                        numRounds = numRounds + 2
                        if not timeline[roundIndex + 1] then
                            table.insert(timeline, roundIndex + 1, {})
                            numRounds = numRounds + 1
                        end
						if not timeline[roundIndex + 2] then
                            table.insert(timeline, roundIndex + 2, {})
                            numRounds = numRounds + 1
                        end
					end
                end
            end
        end

        -- distribute the total value randomly across rounds
        local failsafe = 0
        while remainingValue > 0 do
            distribute()

            if remainingValue < scoreTolerance then
                break
            end

            failsafe = failsafe + 1

            if failsafe > maxValue * 100 then
                if Mod.Debug then
                    L.Error("Failsafe", remainingValue, maxValue)
                end
                return generateTimeline(maxValue, failed)
            end
        end

        -- ensure the first round is not empty
        if #timeline[1] == 0 then
            if Mod.Debug then
                L.Error("Empty first round", remainingValue, maxValue)
            end
            return generateTimeline(maxValue, failed)
        end

        local maxEmpty = math.min(2, math.max(score / 100, numRounds / 3))

        -- ensure no two consecutive rounds exist
        for i = 2, #timeline do
            if #timeline[i] <= maxEmpty and #timeline[i - 1] <= maxEmpty then
                if Mod.Debug then
                    L.Error("Consecutive empty rounds", remainingValue, maxValue, maxEmpty)
                end
                return generateTimeline(maxValue, failed)
            end
        end

        -- ensure the last round does not exceed the previous round
        if #timeline > 1 and #timeline[#timeline] > #timeline[#timeline - 1] and score < 1000 then
            L.Error("Last round is too big", #timeline[#timeline], #timeline[#timeline - 1])
            return generateTimeline(maxValue, failed)
        end

        return timeline
    end

    local partySizeMod = Player.PartySize()
	if GameMode.IsGMMode() then
		partySizeMod = math.max(1, partySizeMod - 1)
	end
    local spawnValue = score

    if partySizeMod == 4 then
        L.Debug("Standard party size, standard scaling")
    elseif partySizeMod == 1 then
        spawnValue = math.ceil(score * 0.7)
    elseif partySizeMod == 2 then
        spawnValue = math.ceil(score * 0.8)
    elseif partySizeMod == 3 then
        spawnValue = math.ceil(score * 0.9)
    elseif partySizeMod == 5 then
        spawnValue = math.ceil(score * 1.2)
    elseif partySizeMod == 6 then
        spawnValue = math.ceil(score * 1.4)
    elseif partySizeMod == 7 then
        spawnValue = math.ceil(score * 1.6)
    elseif partySizeMod >= 8 then
        spawnValue = math.ceil(score * 2)
    end

    if spawnValue < 4 then
        spawnValue = 4
    end

    return generateTimeline(spawnValue, 0)
end

function GameMode.UpdateRogueScore(score)
    local prev = PersistentVars.RogueScore

    local cap = math.min(190, (Player.Level() - 1) * 10) -- +10 per level, max 100
	
	if (GameMode.IsHardMode() and cap > 0) then
	    cap = cap - 5
	elseif (GameMode.IsSuperHardMode() and cap > 0) then
	    cap = cap - 10
	end
	
    if score < cap then
        score = cap
    end

    if prev == score then
        return
    end

    PersistentVars.RogueScore = score

    Event.Trigger("RogueScoreChanged", prev, score)

    Defer(1000, function()
        Player.Notify(__("Your RogueScore changed: %d -> %d!", prev, score))
    end)
end

local ROGUE_SCORE_REWARD_TIERS = {
    { MinScore = 0,   MinGain = 4,  MaxGain = 6  },
    { MinScore = 50,  MinGain = 5,  MaxGain = 7  },
    { MinScore = 100, MinGain = 6,  MaxGain = 8  },
    { MinScore = 150, MinGain = 7,  MaxGain = 9  },
    { MinScore = 200, MinGain = 8,  MaxGain = 11 },
    { MinScore = 300, MinGain = 10, MaxGain = 13 },
    { MinScore = 500, MinGain = 12, MaxGain = 16 },
}

local function rogueScoreRewardTier(score)
    local selected = ROGUE_SCORE_REWARD_TIERS[1]
    for _, tier in ipairs(ROGUE_SCORE_REWARD_TIERS) do
        if score >= tier.MinScore then
            selected = tier
        else
            break
        end
    end
    return selected
end

function GameMode.RewardRogueScore(scenario)
    local score = PersistentVars.RogueScore
    local tier = rogueScoreRewardTier(score)

    -- Scaling reward based only on the RogueScore at the end of the combat.
    -- Slow clears can reduce the random roll, but never below the tier's
    -- validated minimum gain.
    local baseScore = math.random(tier.MinGain, tier.MaxGain)

    -- Always has 1 round more than the timeline because of CombatRoundStarted
    local endRound = scenario.Round - 1
    local diff = math.max(0, endRound - scenario:TotalRounds())
    local gain = math.max(baseScore - diff, tier.MinGain)

    -- V8.4Z15: legacy Quick Start RogueScore multiplier retired.
    -- Run speed now comes exclusively from the selected Combat-tab mode.
    -- Classic returns x1 and therefore preserves the current base behavior exactly.
    gain = RunMode.Scale(gain)

    score = score + gain
    GameMode.UpdateRogueScore(score)

    -- If not hard mode, give an extra round for perfect clear
    if (GameMode.IsHardMode() or GameMode.IsSuperHardMode()) then
        endRound = endRound + 1
    end

    if endRound <= scenario:TotalRounds() then
        Event.Trigger("ScenarioPerfectClear", scenario)
        Player.AskConfirmation(TA_Text("Perfect Clear! Gain bonus loot and EXP?", "Combat parfait ! Gagner du butin et de l'EXP bonus ?"))
            :After(function(confirmed)
                if confirmed then
                    local bonusMod = Player.Level()
                    local bonusEXP = 100
                    if bonusMod < 4 then
                        bonusEXP = bonusMod * 100
                    elseif bonusMod < 8 then
                        bonusEXP = bonusMod * 280 
                    elseif bonusMod < 13 then
                        bonusEXP = bonusMod * 360
                    else
                        bonusEXP = bonusMod * 400
                    end
                    Player.GiveExperience(RunMode.Scale(bonusEXP))
                    local bonusRolls = math.max(math.floor(scenario:KillScore() * 0.25), 1)
                    local loot = Item.GenerateLoot(bonusRolls, scenario.LootRates, true)
                    local x, y, z = Osi.GetPosition(Player.Host())
                    Item.SpawnLoot(loot, x, y, z)
                end
            end)
    end
end

local GOBLIN_MILESTONE_50_NAME = "RG50 - Goblin Raid"
local GNOLL_MILESTONE_75_NAME = "RG75 - Gnoll Hunt"
local GITH_MILESTONE_100_NAME = "RG100 - Githyanki Patrol"
local BOOOAL_MILESTONE_150_NAME = "RG150 - Cult of BOOOAL"
local COLOSSUS_MILESTONE_200_NAME = "RG200 - La Fosse des Colosses"

-- Custom milestone encounters deliberately use verified named templates instead of random tiers.
-- This prevents Challenge/Hell tier unlocks from pulling enemies far above the intended early-run level.
-- Difficulty still applies Trials of Tav's native RogueScore scaling through ScenarioEnemySpawned.
local function GoblinMilestone50Template()
    local timeline

    if GameMode.IsSuperHardMode() then
        timeline = {
            {
                "TOT_Goblins_Male_Melee",
                "TOT_Goblins_Female_Melee",
                "TOT_Goblins_Male_Ranger",
                "TOT_Goblins_Female_Ranger",
                "TOT_Goblins_Male_Caster",
            },
            {
                "TOT_Goblins_Female_Melee",
                "TOT_Goblins_Male_Ranger",
                "TOT_Goblins_Male_Devout",
                "TOT_Goblins_Female_Devout",
                "TOT_Worg_A",
            },
            {
                "TOT_Goblins_Male_Boss",
                "TOT_Ogres_Male_A",
                "TOT_Goblins_Male_Caster",
                "TOT_Goblins_Male_Ranger",
            },
        }
    elseif GameMode.IsHardMode() then
        timeline = {
            {
                "TOT_Goblins_Male_Melee",
                "TOT_Goblins_Female_Melee",
                "TOT_Goblins_Male_Ranger",
                "TOT_Goblins_Female_Ranger",
            },
            {
                "TOT_Goblins_Female_Ranger",
                "TOT_Goblins_Male_Caster",
                "TOT_Goblins_Male_Devout",
                "TOT_Worg_A",
            },
            {
                "TOT_Goblins_Male_Boss",
                "TOT_Ogres_Male_A",
                "TOT_Goblins_Male_Caster",
                "TOT_Goblins_Male_Ranger",
            },
        }
    else
        timeline = {
            {
                "TOT_Goblins_Male_Melee",
                "TOT_Goblins_Female_Melee",
                "TOT_Goblins_Male_Ranger",
                "TOT_Goblins_Female_Ranger",
            },
            {
                "TOT_Goblins_Female_Ranger",
                "TOT_Goblins_Male_Caster",
                "TOT_Worg_A",
            },
            {
                "TOT_Goblins_Male_Boss",
                "TOT_Ogres_Male_A",
                "TOT_Goblins_Male_Caster",
                "TOT_Goblins_Male_Ranger",
            },
        }
    end

    return {
        Name = GOBLIN_MILESTONE_50_NAME,
        Map = "Goblin Camp (exterior)",
        Timeline = timeline,
        Loot = C.LootRates,
    }
end

local function GnollMilestone75Template()
    local timeline

    if GameMode.IsSuperHardMode() then
        -- Hell (expected party roughly level 6-7): many hunters/gnawers and a single Flind boss.
        timeline = {
            {
                "TOT_Hyena_A",
                "TOT_Hyena_A_Black",
                "MOD_GnollRanger_Combat",
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
            },
            {
                "MOD_GnollGnawer_Combat",
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
                "MOD_GnollRanger_Combat",
                "TOT_Hyena_A",
            },
            {
                "MOD_Flind_Combat",
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
                "TOT_Hyena_A_Black",
            },
        }
    elseif GameMode.IsHardMode() then
        -- Challenge: gnolls become the core by round two; Flind remains the only ultra-tier enemy.
        timeline = {
            {
                "TOT_Hyena_A",
                "TOT_Hyena_A_Black",
                "MOD_GnollRanger_Combat",
                "MOD_GnollGnawer_Combat",
            },
            {
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
                "MOD_GnollGnawer_Combat",
                "TOT_Hyena_A",
            },
            {
                "MOD_Flind_Combat",
                "MOD_GnollRanger_Combat",
                "MOD_GnollGnawer_Combat",
                "MOD_GnollGnawer_Combat",
                "TOT_Hyena_A_Black",
            },
        }
    else
        -- Regular: campaign-like gnoll pack, finishing with one Flind and light support.
        timeline = {
            {
                "TOT_Hyena_A",
                "TOT_Hyena_A_Black",
                "MOD_GnollRanger_Combat",
            },
            {
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
                "TOT_Hyena_A",
            },
            {
                "MOD_Flind_Combat",
                "MOD_GnollGnawer_Combat",
                "MOD_GnollRanger_Combat",
                "TOT_Hyena_A_Black",
            },
        }
    end

    return {
        Name = GNOLL_MILESTONE_75_NAME,
        Map = "Gnoll Hill",
        Timeline = timeline,
        Loot = C.LootRates,
    }
end

local function GithMilestone100Template()
    local timeline

    if GameMode.IsSuperHardMode() then
        -- Hell (expected party roughly level 6-8): standard level-5 Gith core plus two level-8 elites.
        -- Deliberately excludes level-9 Gishra, Inquisitor, Paladin and Act 3 Gith.
        timeline = {
            {
                "TOT_Githyanki_Male_Raider",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
                "TOT_Githyanki_Female_Warrior",
            },
            {
                "TOT_Githyanki_Male_Gish",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
                "TOT_Githyanki_Female_Warrior",
                "TOT_Githyanki_Female_GateMaster",
            },
            {
                "TOT_Githyanki_Male_Raider_Strong",
                "TOT_Githyanki_Female_Warrior_Strong",
                "TOT_Githyanki_Male_Gish",
                "TOT_Githyanki_Female_Raider",
            },
        }
    elseif GameMode.IsHardMode() then
        -- Challenge: mostly level-5 patrol troops, with one level-8 elite in the final wave.
        timeline = {
            {
                "TOT_Githyanki_Male_Raider",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
                "TOT_Githyanki_Female_Warrior",
            },
            {
                "TOT_Githyanki_Male_Gish",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
                "TOT_Githyanki_Female_GateMaster",
            },
            {
                "TOT_Githyanki_Male_Warrior_Strong",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
                "TOT_Githyanki_Female_Gish",
            },
        }
    else
        -- Regular: level-5 patrol only; the encounter is elite by composition rather than over-levelled enemies.
        timeline = {
            {
                "TOT_Githyanki_Male_Raider",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
            },
            {
                "TOT_Githyanki_Male_Gish",
                "TOT_Githyanki_Female_Raider",
                "TOT_Githyanki_Male_Warrior",
            },
            {
                "TOT_Githyanki_Male_Warrior_Strong",
                "TOT_Githyanki_Male_Warrior",
                "TOT_Githyanki_Female_Raider",
            },
        }
    end

    return {
        Name = GITH_MILESTONE_100_NAME,
        Map = "Shadow Cursed Lands 3 (Ambush House)",
        Timeline = timeline,
        Loot = C.LootRates,
    }
end




-- RG150 milestone encounter.
-- Explicit safe Trials templates only. Trials difficulty scaling remains active.
local function RG150EnemySource(name)
    return table.find(External.Templates.GetEnemies(), function(v)
        return v.Name == name or v.TemplateId == name
    end)
end

local function BOOOALMilestone150Enemies()
    local kuo = RG150EnemySource("TOT_Kuotoa")
    local redcapMelee = RG150EnemySource("TOT_Redcap_Pirate_Melee")
    local redcapCaster = RG150EnemySource("TOT_Redcap_Caster_A")
    local redcapPirateCaster = RG150EnemySource("TOT_Redcap_Pirate_Caster")
    local boooal = RG150EnemySource("MOD_BOOAL_Combat")
    if not kuo or not redcapMelee or not redcapCaster or not redcapPirateCaster or not boooal then return nil end
    return { kuo, redcapMelee, redcapCaster, redcapPirateCaster, boooal }
end

local function BOOOALMilestone150Template()
    return {
        Name = BOOOAL_MILESTONE_150_NAME,
        Map = "Shadow Cursed Lands 2",
        Timeline = {
            {"TOT_Kuotoa","TOT_Kuotoa","TOT_Kuotoa","TOT_Redcap_Pirate_Melee"},
            {"TOT_Kuotoa","TOT_Kuotoa","TOT_Redcap_Pirate_Melee","TOT_Redcap_Caster_A"},
            {"TOT_Kuotoa","TOT_Kuotoa","TOT_Kuotoa","TOT_Redcap_Pirate_Melee","TOT_Redcap_Pirate_Caster"},
            {"MOD_BOOAL_Combat","TOT_Redcap_Pirate_Melee","TOT_Redcap_Caster_A","TOT_Redcap_Pirate_Caster"},
        },
        Enemies = BOOOALMilestone150Enemies,
        Loot = C.LootRates,
    }
end

local function WatchBOOOALPhase(enemy)
    local function tick()
        if not enemy or not enemy.GUID or Osi.IsDead(enemy.GUID) == 1 then return end
        if Osi.GetHitpointsPercentage(enemy.GUID) <= 50 then
            if Osi.HasAppliedStatus(enemy.GUID, "TOT_BOOOAL_FRENZY_PHASE") ~= 1 then
                Osi.ApplyStatus(enemy.GUID, "TOT_BOOOAL_FRENZY_PHASE", 2, 1, enemy.GUID)
            end
            return
        end
        Defer(500, tick)
    end
    Defer(500, tick)
end

-- RG200 milestone encounter: explicit verified templates only.
-- It has priority over random/Avatar scenarios until completed, just like RG50/75/100/150.
local function RG200EnemySource(name)
    return table.find(External.Templates.GetEnemies(), function(v)
        return v.Name == name or v.TemplateId == name
    end)
end

local function ColossusMilestone200Enemies()
    local names = {
        "TOT_Minotaur", "MOD_Wolf_Combat", "MOD_Harpy_Combat",
        "TOT_S_UND_Bulette", "TOT_HookHorror_A",
    }
    local out = {}
    for _, name in ipairs(names) do
        local e = RG200EnemySource(name)
        if not e then return nil end
        table.insert(out, e)
    end
    -- RG200 uses only normal verified Trials enemy sources.
    return out
end

local function ColossusMilestone200Template()
    return {
        Name = COLOSSUS_MILESTONE_200_NAME,
        Map = "Myrkul Arena",
        Timeline = {
            {"MOD_Wolf_Combat","MOD_Wolf_Combat","TOT_Minotaur","TOT_HookHorror_A"},
            {"TOT_Minotaur","TOT_Minotaur","TOT_HookHorror_A","MOD_Harpy_Combat"},
            {"TOT_Minotaur","TOT_Minotaur","TOT_HookHorror_A","TOT_HookHorror_A"},
            {"TOT_S_UND_Bulette","TOT_HookHorror_A","MOD_Harpy_Combat"},
            {"TOT_S_UND_Bulette","TOT_Minotaur","TOT_HookHorror_A","MOD_Harpy_Combat"},
        },
        Enemies = ColossusMilestone200Enemies,
        Loot = C.LootRates,
    }
end

-- RG50 finale boss keeps the vanilla goblin boss appearance/abilities, with a stronger milestone baseline.
-- Existing Trials difficulty scaling is applied afterwards.
local function ApplyMilestoneEnemyOverride(scenario, enemy)
    if scenario and scenario.Name == COLOSSUS_MILESTONE_200_NAME then
        -- V7.5F: no custom RG200 boss. Wave 5 uses a normal TOT_Minotaur,
        -- identical to the Minotaurs that already spawn reliably in waves 2/3.
        return
    end

    if scenario and scenario.Name == BOOOAL_MILESTONE_150_NAME then
        if enemy.Name == "MOD_BOOAL_Combat" then
            enemy.IsBoss = true
            -- V8.3A: fewer adds, stronger centerpiece boss. Flat +90 max HP preserves
            -- all of BOOOAL's existing attacks and the validated 50% frenzy phase.
            if Osi.HasPassive(enemy.GUID, "TOT_BOOOAL_MILESTONE_VITALITY") ~= 1 then
                Osi.AddPassive(enemy.GUID, "TOT_BOOOAL_MILESTONE_VITALITY")
            end
            WatchBOOOALPhase(enemy)
        end
        return
    end

    if not scenario or scenario.Name ~= GOBLIN_MILESTONE_50_NAME or enemy.Name ~= "TOT_Goblins_Male_Boss" then
        return
    end

    local entity = Ext.Entity.Get(enemy.GUID)
    if not entity then
        return
    end

    -- Vanilla: level 3 / 24 HP / AC 16. RG50 baseline: level 4 / 67 HP / AC 12.
    -- The hidden passive makes the baseline save/reload-safe and prevents duplicate boosts.
    if Osi.HasPassive(enemy.GUID, "TOT_RG50_GOBLIN_BOSS_BASELINE") ~= 1 then
        Osi.AddPassive(enemy.GUID, "TOT_RG50_GOBLIN_BOSS_BASELINE")
        Osi.SetHitpointsPercentage(enemy.GUID, 100)
    end
    entity.EocLevel.Level = 4
    entity:Replicate("EocLevel")
end


function GameMode.StartNext()
    if Scenario.Current() then
        return
    end

    local score = PersistentVars.RogueScore or 0
    if PersistentVars.RogueModeActive then
        -- Always resolve milestones in campaign order. This also makes Quick Start / high-RG test saves
        -- play any missed milestone once instead of silently skipping it.
        if score >= 50 and not PersistentVars.GoblinMilestone50Done then
            Player.Notify(__("Milestone encounter: Goblin Raid!"))
            Scenario.Start(GoblinMilestone50Template())
            return
        end
        if score >= 75 and not PersistentVars.GnollMilestone75Done then
            Player.Notify(__("Milestone encounter: Gnoll Hunt!"))
            Scenario.Start(GnollMilestone75Template())
            return
        end
        if score >= 100 and not PersistentVars.GithMilestone100Done then
            Player.Notify(__("Milestone encounter: Githyanki Patrol!"))
            Scenario.Start(GithMilestone100Template())
            return
        end
        if score >= 150 and not PersistentVars.BOOOALMilestone150Done then
            Player.Notify(TA_Text("RG150 - Cult of BOOOAL!", "RG150 - Culte de BOOOAL !"))
            Scenario.Start(BOOOALMilestone150Template())
            return
        end
        if score >= 200 and not PersistentVars.ColossusMilestone200Done then
            Player.Notify(TA_Text("RG200 - Pit of the Colossi!", "RG200 - La Fosse des Colosses !"))
            Scenario.Start(ColossusMilestone200Template())
            return
        end
    end

    local rogueTemp = table.find(Scenario.GetTemplates(), function(v)
        return v.Name == PersistentVars.RogueScenario
    end)

    if not rogueTemp then
        Player.Notify(__("Select a Roguelike scenario to start!"))
        return
    end

    Scenario.Start(rogueTemp)
end

-- Rebuild the encounter that is already prepared at camp.
-- Used when Progression régionale is toggled or the camp selection changes.
-- Milestones/themes are re-resolved normally.
function GameMode.RebuildPreparedEncounter()
    if Player.InCombat() then
        return false, TA_Text("Unable to rebuild the next encounter during combat.", "Impossible de reconstruire la prochaine rencontre pendant un combat.")
    end

    if Scenario.Current() then
        Scenario.Stop()
    end

    GameMode.StartNext()

    if not Scenario.Current() then
        return false, TA_Text("Unable to prepare the next encounter.", "Impossible de préparer la prochaine rencontre.")
    end

    return true
end

function GameMode.DebugCompleteMilestones()
    -- Test utility only: mark the existing RG50/75/100/150/200 encounters as
    -- completed without granting milestone rewards/tokens. This lets high-RG
    -- pool/spawn tests reach the normal Roguelike generator immediately.
    if Player.InCombat() then
        return false, TA_Text("Unable to mark milestones complete during combat.", "Impossible de valider les paliers pendant un combat.")
    end

    if Scenario.Current() then
        Scenario.Stop()
    end

    PersistentVars.GoblinMilestone50Done = true
    PersistentVars.GnollMilestone75Done = true
    PersistentVars.GithMilestone100Done = true
    PersistentVars.BOOOALMilestone150Done = true
    PersistentVars.ColossusMilestone200Done = true

    -- Prepare the normal Roguelike scenario for the current RogueScore.
    GameMode.StartNext()
    return true, TA_Text("DEBUG: RG50/75/100/150/200 milestones marked complete without rewards.", "DEBUG : paliers RG50/75/100/150/200 validés sans récompenses.")
end

function GameMode.DebugStartMilestone(rg)
    local t = ({[50]=GoblinMilestone50Template,[75]=GnollMilestone75Template,[100]=GithMilestone100Template,[150]=BOOOALMilestone150Template,[200]=ColossusMilestone200Template})[rg]
    if not t then return false, Localization.Get("h72a00000000000000000000000000110") end

    -- Debug buttons may be used from camp while Trials still keeps a stale scenario object.
    -- Never interrupt an actual combat.
    if Scenario.Current() then
        if Player.InCombat() then
            return false, Localization.Get("h72a00000000000000000000000000109")
        end
        Scenario.Stop()
    end

    Scenario.Start(t())
    if not Scenario.Current() then
        return false, string.format(TA_Text("RG%d: scenario not created.", "RG%d : scénario non créé."), rg)
    end
    return true, "RG"..tostring(rg)
end

GameMode.DifficultyAppliedTo = {}

---@param enemy Enemy
---@param score integer
function GameMode.ApplyDifficulty(enemy, score, baseDex)
    if GameMode.DifficultyAppliedTo[enemy.GUID] then
        return
    end

-- Legendary Action summons like the Claws of Tu'narath become exponentially more dangerous if they're allowed to scale,
-- but eventually they need to start scaling for summoning to have a point
    if score < 280 and enemy.Name == "Temporary" then
        return
    end

    local originalDex = baseDex

    local function scale(i)
        local x = i / 200
        local max_value = Config.ScalingModifier

        if GameMode.IsHardMode() then
            x = x * 2
            max_value = Config.ScalingModifier * 1.6666667
        elseif GameMode.IsSuperHardMode() then
            x = (x + 0.15) * 2
            max_value = Config.ScalingModifier * 1.6666667
        end

        local rate = i / 1000
        return math.floor(max_value * (1 - math.exp(-rate * x)))
    end

    local mod = scale(score)

-- Elminster's Intelligence should not be scaling at the same rate as a cow's Strength. One gains the ability to hit you, the other's already-devastating spells become irresistible.
    if enemy.Tier == "ultra" then
        mod = math.floor(mod / 1.3333)
    elseif enemy.Tier == "epic" then
        mod = math.floor(mod / 1.6333)
    elseif enemy.Name == "Temporary" or enemy.Tier == "legendary" then
        mod = math.floor(mod / 2.2222)
    elseif enemy.Tier == "mythical" then
        mod = math.floor((mod / 3.6333)-0.2)
    elseif enemy.Tier == "divine" then
        mod = math.floor((mod / 4.4333)-0.5)
	elseif enemy.Tier == "avatar" or enemy.Tier == "apex" then
        mod = math.floor((mod / 8.3333)-1)
    end

    if mod <= 0 then
        mod = 0
        return
    end

    local mod2 = math.floor(mod / 2)
    local mod3 = math.floor(mod2 / 2)

    local map = {}
    local abilties = { "Strength", "Dexterity", "Constitution", "Intelligence", "Wisdom", "Charisma" }
    for i, v in pairs(enemy:Entity().Stats.Abilities) do
        if i > 1 and v then
            table.insert(map, { abilties[i - 1], v })
        end
    end
    table.sort(map, function(left, right)
        return left[2] > right[2]
    end)

    if mod ~= 0 then
        Osi.AddBoosts(enemy.GUID, "Ability(" .. map[1][1] .. "," .. mod .. ")", Mod.TableKey, Mod.TableKey)
        Osi.AddBoosts(enemy.GUID, "Ability(" .. map[2][1] .. "," .. mod .. ")", Mod.TableKey, Mod.TableKey)
    end
    if mod2 ~= 0 then
        Osi.AddBoosts(enemy.GUID, "Ability(" .. map[3][1] .. "," .. mod2 .. ")", Mod.TableKey, Mod.TableKey)
        Osi.AddBoosts(enemy.GUID, "Ability(" .. map[4][1] .. "," .. mod2 .. ")", Mod.TableKey, Mod.TableKey)
        Osi.AddBoosts(enemy.GUID, "IncreaseMaxHP(" .. mod2 .. "%)", Mod.TableKey, Mod.TableKey)
        if mod2 > 0 then
            Osi.AddBoosts(enemy.GUID, "IncreaseMaxHP(" .. mod2 * 10 .. ")", Mod.TableKey, Mod.TableKey)
        end
    end
    if mod3 ~= 0 then
        Osi.AddBoosts(enemy.GUID, "Ability(" .. map[5][1] .. "," .. mod3 .. ")", Mod.TableKey, Mod.TableKey)
        Osi.AddBoosts(enemy.GUID, "Ability(" .. map[6][1] .. "," .. mod3 .. ")", Mod.TableKey, Mod.TableKey)
        Osi.AddBoosts(enemy.GUID, "AC(" .. mod3 .. ")", Mod.TableKey, Mod.TableKey)
    end

    WaitTicks(6, function()
        local entity = Ext.Entity.Get(enemy.GUID)
        assert(entity, "ApplyDifficulty: entity not found")
        if mod2 > 0 then
            local maxLevel = 12
            if Player.Level() > 12 then
                maxLevel = Player.Level()
            end

            local newLevel = math.max(entity.AvailableLevel.Level, math.min(maxLevel, mod2))
            entity.EocLevel.Level = newLevel
            entity:Replicate("EocLevel")
        end

        local currentAc = entity.Resistances.AC

        local armor = Osi.GetEquippedItem(enemy.GUID, "Breast")
        local dexScaling = true
        if armor then
            dexScaling = Ext.Entity.Get(armor).Armor.ArmorType < 5
        end

        if dexScaling then
            local initialAcMax = math.max(4, mod3)
            local acMax = math.max(initialAcMax, originalDex)
            local dexAc = entity.Stats.AbilityModifiers[3] - acMax
            if dexAc > 0 then
                currentAc = currentAc - dexAc
                Osi.AddBoosts(enemy.GUID, "AC(-" .. dexAc .. ")", Mod.TableKey, Mod.TableKey)
            end
        end

        local acMax = math.max(30, mod)
        local ac = currentAc
        while ac > acMax do
            ac = ac - 3
        end

        ac = ac - currentAc
        if ac < 0 then
            Osi.AddBoosts(enemy.GUID, "AC(" .. ac .. ")", Mod.TableKey, Mod.TableKey)
        end
    end)

    GameMode.DifficultyAppliedTo[enemy.GUID] = true
end

Ext.Osiris.RegisterListener(
    "TeleportedToCamp",
    1,
    "after",
    ifRogueLike(function(uuid)
        if U.UUID.Equals(uuid, Player.Host()) then
            GameMode.StartNext()
        end
    end)
)

Event.On("RogueModeChanged", function(bool)
    -- Difficulty is a save-level commitment once the first Roguelike run is
    -- started. Disabling/re-enabling Roguelike must not reset the lock or let
    -- the player reroll a prepared encounter by changing difficulty.
    if not bool then
        return
    end

    if not PersistentVars.GUIOpen then
        Net.Send("OpenGUI")
    end
end)

--Event.On(
--    "ScenarioStopped",
--   ifRogueLike(function(scenario)
--        if scenario.OnMap then
--            GameMode.UpdateRogueScore(PersistentVars.RogueScore - 5)
--        end
--    end)
--)

Event.On(
    "ScenarioEnemySpawned",
    ifRogueLike(function(scenario, enemy)
        WaitTicks(6, function()
            local entity = Ext.Entity.Get(enemy.GUID)
            assert(entity, "ApplyDifficulty: entity not found")
            ApplyMilestoneEnemyOverride(scenario, enemy)
            local baseDex = entity.Stats.AbilityModifiers[3]
            GameMode.ApplyDifficulty(enemy, PersistentVars.RogueScore, baseDex)
        end)
        WaitTicks(54, function()
            Osi.RemoveStatus(enemy.GUID, "TOTR_INVULNERABLE")
        end)
    end)
)

Event.On(
    "ScenarioRestored",
    ifRogueLike(function(scenario)
        for _, enemy in pairs(scenario.SpawnedEnemies) do
            WaitTicks(6, function()
                local entity = Ext.Entity.Get(enemy.GUID)
                assert(entity, "ApplyDifficulty: entity not found")
                ApplyMilestoneEnemyOverride(scenario, enemy)
                local baseDex = entity.Stats.AbilityModifiers[3]
                GameMode.ApplyDifficulty(enemy, PersistentVars.RogueScore, baseDex)
            end)
            WaitTicks(54, function()
                Osi.RemoveStatus(enemy.GUID, "TOTR_INVULNERABLE")
            end)
        end
    end)
)

Event.On(
    "ScenarioEnded",
    ifRogueLike(function(scenario)
        GameMode.DifficultyAppliedTo = {}

        if scenario.Name == GOBLIN_MILESTONE_50_NAME then
            if not PersistentVars.GoblinMilestone50Done then
                PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or PersistentVars.GoblinTokens or 0) + 2
                Player.Notify(Localization.Get("h71a00000000000000000000000000022"))
            end
            PersistentVars.GoblinMilestone50Done = true
            Player.Notify(Localization.Get("h84i00000000000000000000000000201"))
        elseif scenario.Name == GNOLL_MILESTONE_75_NAME then
            if not PersistentVars.GnollMilestone75Done then
                PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or PersistentVars.GoblinTokens or 0) + 2
                Player.Notify(Localization.Get("h71a00000000000000000000000000023"))
            end
            PersistentVars.GnollMilestone75Done = true
            Player.Notify(Localization.Get("h84i00000000000000000000000000202"))
        elseif scenario.Name == GITH_MILESTONE_100_NAME then
            if not PersistentVars.GithMilestone100Done then
                PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or PersistentVars.GoblinTokens or 0) + 3
                local newCurrency = (PersistentVars.Currency or 0) + 250
                if Unlock and Unlock.UpdateCurrency then
                    Unlock.UpdateCurrency(newCurrency)
                else
                    PersistentVars.Currency = newCurrency
                end
                Player.Notify(Localization.Get("h84i00000000000000000000000000133"))
            end
            PersistentVars.GithMilestone100Done = true
            Player.Notify(Localization.Get("h84i00000000000000000000000000203"))
        elseif scenario.Name == BOOOAL_MILESTONE_150_NAME then
            if not PersistentVars.BOOOALMilestone150Done then
                PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or PersistentVars.GoblinTokens or 0) + 3
                Player.Notify(Localization.Get("h84i00000000000000000000000000144"))
            end
            PersistentVars.BOOOALMilestone150Done = true
            Player.Notify(Localization.Get("h84i00000000000000000000000000204"))
        elseif scenario.Name == COLOSSUS_MILESTONE_200_NAME then
            if not PersistentVars.ColossusMilestone200Done then
                PersistentVars.ConquestTokens = (PersistentVars.ConquestTokens or PersistentVars.GoblinTokens or 0) + 5
                Player.Notify(Localization.Get("h84i00000000000000000000000000154"))
            end
            PersistentVars.ColossusMilestone200Done = true
            Player.Notify(Localization.Get("h84i00000000000000000000000000205"))
        end

        GameMode.RewardRogueScore(scenario)
		
		if GameMode.IsGMMode() then
			Osi.RemoveStatus(PersistentVars.GameMaster, "ATT_ETHEREALNESS")
			Osi.RemoveStatus(PersistentVars.GameMaster, "TOTR_TURNHELPER")
			Osi.SetFaction(PersistentVars.GameMaster, C.CompanionFaction)
		end

        -- Jam4_ is a post-combat Easter Egg. If it starts, it owns the transition
        -- until the three-question encounter is finished so the normal 30 s return
        -- cannot interrupt the dialogue.
        local jam4Encounter = Jam4Companion and Jam4Companion.TryPostCombatEncounter and Jam4Companion.TryPostCombatEncounter(scenario)
        if jam4Encounter then
            return
        end

        if Config.AutoTeleport > 0 then
            -- Guard against StoryBypass forcing an immediate camp return while the
            -- configured post-encounter delay is still running.
            GameMode.AutoTeleportPending = true
            Player.Notify(__("Teleporting back to camp in %d seconds.", Config.AutoTeleport), true)
            local timer = Defer(Config.AutoTeleport * 1000, function()
                GameMode.AutoTeleportPending = false
                Player.ReturnToCamp()
            end)

            Event.On("ScenarioStarted", function(scenario)
                GameMode.AutoTeleportPending = false
                timer.Source:Clear()
            end, true)
        else
            GameMode.AutoTeleportPending = false
        end
    end)
)

local function getMap(template)
    local maps

    if PersistentVars.RegionalProgressionEnabled then
        local stage = Player.GetRegionalStage(PersistentVars.RogueScore)
        maps = table.filter(Map.Get(), function(v)
            return stage and Player.IsRegionAllowedForStage(v.Region, stage, "MapRegions")
        end)

        if #maps == 0 then
            L.Error("Regional progression produced an empty map pool.", stage and stage.Name or "nil")
        else
            L.Debug("Regional map pool", stage.Name, "RG", PersistentVars.RogueScore, "maps", #maps)
        end
    else
        -- Legacy Trials of Tav behavior kept behind the option for comparison/testing.
        local threshold = (GameMode.IsSuperHardMode() and 5) or (GameMode.IsHardMode() and 20) or 40
        maps = table.filter(Map.Get(), function(v)
            return PersistentVars.RogueScore > threshold or v.Region == C.Regions.Act1
        end)
    end

    local map = nil
    if #maps > 0 then
        local random = math.newRandom(#maps)

        if table.contains(PersistentVars.RandomLog.Maps, random) then
            random = math.newRandom(#maps)
        end
        LogRandom("Maps", random, 10)

        map = maps[random]
    end

    return map
end

local function makeItCow()
    local lolcow = math.newRandom() < 0.001
    if lolcow then
        local hasOX = Enemy.Find("TOT_OX_A")
        lolcow = hasOX and true or false
    end

    if lolcow then
        Defer(1000, function()
            Player.Notify(__("You found the secret cow level!"))
        end)
    end

    return lolcow
end

local function makeItWilloughby()
    local harvard = math.newRandom() < 0.0001
    if harvard then
        local hasWilloughby = Enemy.Find("MOD_MysterySpawn_Combat")
        harvard = hasWilloughby and true or false
    end

    if harvard then
        Defer(1000, function()
            Player.Notify(__("You have incurred the wrath of Nature's Vengeance!"))
        end)
    end

    return harvard
end

Schedule(function()
    External.Templates.AddScenario({
        RogueLike = true,
        OnStart = function(template)
            GameMode.StartRoguelike(template)
        end,

        Name = C.RoguelikeScenario .. " (Bias Lower Tier)",
        Map = getMap,

        -- Spawns per Round
        Timeline = function(template)
            local tiers = GameMode.GetTiers(makeItCow(), makeItWilloughby(), PersistentVars.RogueScore)

            for i, tier in ipairs(tiers) do
                local weight = (tier.amount / 100) * 0.3 -- slight bias towards tiers with more enemies
                tier.weight = weight + (1 / (i + 1)) -- strong bias towards lower tiers
                L.Debug("Tier", tier.name, tier.weight)
            end

            return GameMode.GenerateScenario(PersistentVars.RogueScore, tiers)
        end,

        Loot = C.LootRates,
    })
    External.Templates.AddScenario({
        RogueLike = true,
        OnStart = function(template)
            GameMode.StartRoguelike(template)
        end,

        Name = C.RoguelikeScenario .. " (Bias Balanced)",
        Map = getMap,

        -- Spawns per Round
        Timeline = function(template)
            local tiers = GameMode.GetTiers(makeItCow(), makeItWilloughby(), PersistentVars.RogueScore)

            for i, tier in ipairs(tiers) do
                local weight = tier.amount / 2000 -- slight bias towards tiers with more enemies
                tier.weight = weight + 1 - ((i+1) * 0.062) -- slightly descending bias per tier
                L.Debug("Tier", tier.name, tier.weight)
            end

            return GameMode.GenerateScenario(PersistentVars.RogueScore, tiers)
        end,

        Loot = C.LootRates,
    })
    External.Templates.AddScenario({
        RogueLike = true,
        OnStart = function(template)
            GameMode.StartRoguelike(template)
        end,

        Name = C.RoguelikeScenario .. " (Bias Higher Tier)",
        Map = getMap,

        -- Spawns per Round
        Timeline = function(template)
            local tiers = GameMode.GetTiers(makeItCow(), makeItWilloughby(), PersistentVars.RogueScore)

            for i, tier in ipairs(tiers) do
                local weight = tier.amount / 100 * 0.7 -- mild bias towards tiers with more enemies
                tier.weight = weight + (1 / (#tiers + 1 - i)) -- strong bias towards higher tiers
                L.Debug("Tier", tier.name, tier.weight)
            end

            return GameMode.GenerateScenario(PersistentVars.RogueScore, tiers)
        end,

        Loot = C.LootRates,
    })
end)
