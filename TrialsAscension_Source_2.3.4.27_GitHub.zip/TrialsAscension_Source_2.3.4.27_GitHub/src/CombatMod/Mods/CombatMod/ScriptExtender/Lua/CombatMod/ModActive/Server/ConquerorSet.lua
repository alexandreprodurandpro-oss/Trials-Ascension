ConquerorSet = ConquerorSet or {}

-- V8.3D: validated six-piece set: helmet, armour, gloves, amulet, ring and blade.
local SET = {
    ["Helmet"] = "TOT_CONQ_HELMET",
    ["Breast"] = "TOT_CONQ_ARMOR",
    ["Gloves"] = "TOT_CONQ_GLOVES",
    ["Amulet"] = "TOT_CONQ_AMULET",
}

local TIERS = {
    {Count=2, Passive="TOT_CONQ_SET_2_PASSIVE", Status="TOT_CONQ_SET_2_STATUS"},
    {Count=4, Passive="TOT_CONQ_SET_4_PASSIVE", Status="TOT_CONQ_SET_4_STATUS"},
    {Count=6, Passive="TOT_CONQ_SET_6_PASSIVE", Status="TOT_CONQ_SET_6_STATUS"},
}

local function equippedStat(character, slot)
    local guid = Osi.GetEquippedItem(character, slot)
    if not guid or guid == "" then return nil end
    local entity = Ext.Entity.Get(guid)
    return entity and entity.ServerItem and entity.ServerItem.Stats or nil
end

function ConquerorSet.CountPieces(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return 0 end
    local count = 0
    for slot, stat in pairs(SET) do
        if equippedStat(character, slot) == stat then count = count + 1 end
    end
    if equippedStat(character, "Ring") == "TOT_CONQ_RING" or equippedStat(character, "Ring2") == "TOT_CONQ_RING" then
        count = count + 1
    end
    if equippedStat(character, "Melee Main Weapon") == "TOT_CONQ_BLADE"
        or equippedStat(character, "Melee Offhand Weapon") == "TOT_CONQ_BLADE" then
        count = count + 1
    end
    return count
end

local function setTier(character, tier, active)
    if active then
        if Osi.HasPassive(character, tier.Passive) ~= 1 then Osi.AddPassive(character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) ~= 1 then Osi.ApplyStatus(character, tier.Status, -1, 1, character) end
    else
        if Osi.HasPassive(character, tier.Passive) == 1 then Osi.RemovePassive(character, tier.Passive) end
        if Osi.HasAppliedStatus(character, tier.Status) == 1 then Osi.RemoveStatus(character, tier.Status) end
    end
end

function ConquerorSet.Update(character)
    if not character or Osi.IsCharacter(character) ~= 1 then return end
    local count = ConquerorSet.CountPieces(character)
    for _, tier in ipairs(TIERS) do
        setTier(character, tier, count >= tier.Count)
    end
end

local function scheduledUpdate(character) Schedule(function() ConquerorSet.Update(character) end) end
Ext.Osiris.RegisterListener("Equipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("Unequipped", 2, "after", function(_, character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("CharacterJoinedParty", 1, "after", function(character) scheduledUpdate(character) end)
Ext.Osiris.RegisterListener("LongRestFinished", 0, "after", function()
    for _, character in pairs(GU.DB.GetPlayers()) do ConquerorSet.Update(character) end
end)
GameState.OnLoad(function()
    Schedule(function()
        for _, character in pairs(GU.DB.GetPlayers()) do ConquerorSet.Update(character) end
    end)
end, true)
