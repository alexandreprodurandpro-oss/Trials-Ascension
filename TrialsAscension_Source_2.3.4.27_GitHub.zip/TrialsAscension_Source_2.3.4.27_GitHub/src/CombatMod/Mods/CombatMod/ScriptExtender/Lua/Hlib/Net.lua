---@type Mod
local Mod = Require("Hlib/Mod")

---@type Utils
local Utils = Require("Hlib/Utils")

---@type GameUtils
local GameUtils = Require("Hlib/GameUtils")

---@type Log
local Log = Require("Hlib/Log")

---@type Event
local Event = Require("Hlib/Event")

---@type Libs
local Libs = Require("Hlib/Libs")

---@class Net
local M = {}

-- exposed
---@class NetEvent : Struct
---@field Action string
---@field Payload any
---@field PeerId number|nil
---@field ResponseAction string|nil
---@field UserId fun(self: NetEvent): number
---@field Character fun(self: NetEvent): string GUID
---@field IsHost fun(self: NetEvent): boolean
local NetEvent = Libs.Struct({
    Action = nil,
    Payload = nil,
    PeerId = nil,
    ResponseAction = nil,
    UserId = function(self)
        -- Legacy NetMessage.UserID is a peer ID, not an Osiris user ID.
        return (self.PeerId & 0xffff0000) | 0x0001
    end,
    Character = function(self)
        assert(Ext.IsServer(), "NetEvent:Character() is only available on the server")
        return GameUtils.Character.GetForUser(self:UserId())
    end,
    IsHost = function(self)
        assert(Ext.IsServer(), "NetEvent:IsHost() is only available on the server")
        local host = Osi.GetHostCharacter()
        if not host then return false end
        local ok, user = pcall(Osi.GetReservedUserID, host)
        return ok and user ~= nil and user ~= -65536 and user == self:UserId()
    end,
})

function NetEvent:__tostring()
    return Ext.Json.Stringify(Utils.Table.Clean(self))
end

-- Server-only ingress validation. Peer identity always comes from the transport.
local registered = {}
local hostActions = {
    ResetTemplates=true, Start=true, Stop=true, Config=true, ForwardCombat=true,
    KillSpawned=true, KillNearby=true, ClearSurfaces=true, RemoveAllEntities=true,
    RecruitOrigin=true, FixFactions=true, FixLongRest=true, CancelLongRest=true,
    CancelDialog=true, MarkSpawns=true, PingSpawns=true, DestroyAll=true,
    DestroyLoot=true, UpdateLootFilter=true, UpdateModFilter=true,
    SetLockedCamp=true, SetRegionalProgressionEnabled=true, CampBattleCleanup=true,
    SetSummonsAutomatic=true,
}

local function actionName(value, limit)
    return type(value) == "string" and #value > 0 and #value <= limit
        and value:match("^[%w_]+$") ~= nil
end

Ext.Events.NetMessage:Subscribe(function(msg)
    if Mod.NetChannel ~= msg.Channel or type(msg.Payload) ~= "string" then return end
    if Ext.IsServer() and #msg.Payload > 65536 then return end
    local ok, event = pcall(Ext.Json.Parse, msg.Payload)
    if not ok or type(event) ~= "table" or not actionName(event.Action, 96) then return end
    if event.Action == "RCE" then return end -- retired on both server and client
    local response = event.ResponseAction or event.Action
    if not actionName(response, 160) then return end
    if Ext.IsServer() then
        if not registered[event.Action] then return end
        if type(msg.UserID) ~= "number" or msg.UserID % 1 ~= 0 or msg.UserID < 0 then return end
        local prefix = event.Action .. "_Response_"
        if response ~= event.Action and response:sub(1, #prefix) ~= prefix then return end
    end
    local m = NetEvent.Init({Action=event.Action, Payload=event.Payload,
        PeerId=msg.UserID, ResponseAction=response})
    local dispatched, err = pcall(Event.Trigger, M.EventName(m.Action), m)
    if not dispatched then Log.Error("Rejected/failed net action " .. m.Action .. ": " .. tostring(err)) end
end)

---@param action string
---@return string @NetEvent_{action}
function M.EventName(action)
    return "NetEvent_" .. action
end

---@param action string
---@param payload any
---@param responseAction string|nil
---@param peerId number|nil
function M.Send(action, payload, responseAction, peerId)
    local event = NetEvent.Init({
        Action = action,
        Payload = payload,
        PeerId = peerId,
        ResponseAction = responseAction or action,
    })

    xpcall(function()
        if Ext.IsServer() then
            if event.PeerId == nil then
                Ext.Net.BroadcastMessage(Mod.NetChannel, tostring(event))
            else
                Ext.Net.PostMessageToUser(event.PeerId, Mod.NetChannel, tostring(event))
            end
            return
        end

        Ext.Net.PostMessageToServer(Mod.NetChannel, tostring(event))
    end, function(err)
        Log.Error(err)
        Log.Debug(Ext.DumpExport(event))
    end)
end

---@param action string
---@param callback fun(event: NetEvent)
---@param once boolean|nil
---@return EventListener
function M.On(action, callback, once)
    registered[action] = true
    return Event.On(M.EventName(action), function(event)
        if Ext.IsServer() then
            local privileged = hostActions[action] or action:match("^Debug") or action:match("^Jam4Debug")
            if privileged and not event:IsHost() then
                M.Respond(event, {false, TA_Text("Command restricted to the host.", "Commande réservée à l'hôte.")})
                return
            end
        end
        callback(event)
    end, once)
end

---@class ChainableRequest : ChainableEvent
---@field After fun(func: fun(event: NetEvent): any): Chainable
---@param action string
---@param payload any
---@return ChainableRequest
function M.Request(action, payload)
    local responseAction = action .. Utils.RandomId("_Response_")
    local chainable = Event.ChainOn(M.EventName(responseAction))

    M.Send(action, payload, responseAction)
    -- TODO maybe add timeout and fail

    return chainable
end

---@param event NetEvent
---@param payload any
function M.Respond(event, payload)
    M.Send(event.ResponseAction, payload, nil, event.PeerId)
end

-- There is intentionally no RCE listener or dynamic-code client API.
return M
