ContractsUI = ContractsUI or {}

local H = {
    Tab="h72a00000000000000000000000000001",
    Intro="h72a00000000000000000000000000002",
    Progress="h72a00000000000000000000000000003",
    Reward="h72a00000000000000000000000000004",
    Done="h72a00000000000000000000000000005",
    Kill25="h72a00000000000000000000000000011", Kill50="h72a00000000000000000000000000012",
    Kill100="h72a00000000000000000000000000013", Kill200="h72a00000000000000000000000000014",
    Combat10="h72a00000000000000000000000000015", Combat25="h72a00000000000000000000000000016", Combat50="h72a00000000000000000000000000017",
    Level10="h72a00000000000000000000000000018", Level20="h72a00000000000000000000000000019",
    Arena100="h72a00000000000000000000000000020", Horde500="h72a00000000000000000000000000021",
    NewTitle="h83a00000000000000000000000000110", DivineTitle="h83a00000000000000000000000000111",
    Perfect10="h83a00000000000000000000000000112", NoRest15="h83a00000000000000000000000000113", Conquest5="h83a00000000000000000000000000114",
    Gods1="h83a00000000000000000000000000115", Gods3="h83a00000000000000000000000000116", Gods5="h83a00000000000000000000000000117",
    Gods1Reward="h83s00000000000000000000000000214", Gods3Reward="h83s00000000000000000000000000215", Gods5Reward="h83s00000000000000000000000000216",
    Claim="h83s00000000000000000000000000211", Claimed="h83s00000000000000000000000000212", ObjectiveDone="h83s00000000000000000000000000213",
    AscensionLabel="h83a00000000000000000000000000120", DivineLabel="h83a00000000000000000000000000121",
    InProgress="h83a00000000000000000000000000122", MainTitle="h83a00000000000000000000000000123",
    InfoTitle="h83a00000000000000000000000000124", InfoText="h83a00000000000000000000000000125",
    ProgressPercent="h83a00000000000000000000000000126", ContractLabel="h83a00000000000000000000000000127",
    KillLabel="h83a00000000000000000000000000128", CombatLabel="h83a00000000000000000000000000129", LevelLabel="h83a00000000000000000000000000130",
    Perfect10Desc="h83e00000000000000000000000000101", NoRest15Desc="h83e00000000000000000000000000102", Conquest5Desc="h83e00000000000000000000000000103",
    Gods1Desc="h83e00000000000000000000000000104", Gods3Desc="h83e00000000000000000000000000105", Gods5Desc="h83e00000000000000000000000000106",
}

local defs = {
 {Id="Kill25",Kind="Kills",Need=25,Name=H.Kill25,Reward="+50 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Kill50",Kind="Kills",Need=50,Name=H.Kill50,Reward="+100 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Kill100",Kind="Kills",Need=100,Name=H.Kill100,Reward="+200 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Kill200",Kind="Kills",Need=200,Name=H.Kill200,Reward="+400 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Combat10",Kind="Combats",Need=10,Name=H.Combat10,Reward="+100 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Combat25",Kind="Combats",Need=25,Name=H.Combat25,Reward="+250 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Combat50",Kind="Combats",Need=50,Name=H.Combat50,Reward="+500 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Level10",Kind="Level",Need=10,Name=H.Level10,Reward="+200 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Level20",Kind="Level",Need=20,Name=H.Level20,Reward="+500 "..Localization.Get("h72a00000000000000000000000000031").." + 1 "..Localization.Get("h72a00000000000000000000000000032")},
 {Id="Arena100",Kind="Combats",Need=100,Name=H.Arena100,Reward="+4 "..Localization.Get("h72a00000000000000000000000000032")},
 {Id="Horde500",Kind="Kills",Need=500,Name=H.Horde500,Reward="+1000 "..Localization.Get("h72a00000000000000000000000000031").." + 1 "..Localization.Get("h72a00000000000000000000000000032")},
}

local NEW_NORMAL = {
 {Id="Perfect10",Kind="PerfectClears",Need=10,Name=H.Perfect10,Desc=H.Perfect10Desc,Reward="+500 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="NoRest15",Kind="NoRestStreak",Need=15,Name=H.NoRest15,Desc=H.NoRest15Desc,Reward="+500 "..Localization.Get("h72a00000000000000000000000000031")},
 {Id="Conquest5",Kind="Milestones",Need=5,Name=H.Conquest5,Desc=H.Conquest5Desc,Reward="+1000 "..Localization.Get("h72a00000000000000000000000000031")},
}

local DIVINE = {
 {Id="Gods1",Kind="AsmodeusKills",Need=1,Name=H.Gods1,Desc=H.Gods1Desc,Reward=H.Gods1Reward,RewardLocalized=true, Bg={0.035,0.090,0.165,1.00}, Accent={0.05,0.42,0.86,1.0}},
 {Id="Gods3",Kind="AsmodeusKills",Need=3,Name=H.Gods3,Desc=H.Gods3Desc,Reward=H.Gods3Reward,RewardLocalized=true, Bg={0.145,0.145,0.155,1.00}, Accent={0.92,0.92,0.95,1.0}},
 {Id="Gods5",Kind="AsmodeusKills",Need=5,Name=H.Gods5,Desc=H.Gods5Desc,Reward=H.Gods5Reward,RewardLocalized=true, Bg={0.165,0.035,0.045,1.00}, Accent={0.78,0.04,0.07,1.0}},
}

local function progress(state, def)
    local c = state.Contracts or {}
    if def.Kind == "Level" then return math.max(state.PlayerLevel or 0, c.SimulatedLevel or 0) end
    if def.Kind == "Milestones" then
        local n = 0
        if state.GoblinMilestone50Done then n = n + 1 end
        if state.GnollMilestone75Done then n = n + 1 end
        if state.GithMilestone100Done then n = n + 1 end
        if state.BOOOALMilestone150Done then n = n + 1 end
        if state.ColossusMilestone200Done then n = n + 1 end
        return n
    end
    return c[def.Kind] or 0
end

local CONTRACT_TYPE_LABEL = {
    Kills = H.KillLabel,
    Combats = H.CombatLabel,
    Level = H.LevelLabel,
}

local CONTRACT_TYPE_COLOR = {
    Kills = { 0.72, 0.34, 0.30, 1.00 },
    Combats = { 0.36, 0.62, 0.84, 1.00 },
    Level = { 0.48, 0.70, 0.46, 1.00 },
}


local function addContractCard(cell, def, index, explicitColors)
    -- Use exactly the same card constructor for normal and Divine contracts.
    -- This keeps the visible framed background while allowing per-card French-flag colours.
    local card, accent = CombatTheme.Card(
        cell,
        "ContractCard_" .. def.Id,
        index,
        0,
        explicitColors and def.Accent or nil,
        explicitColors and def.Bg or nil
    )

    local kindLabel = Localization.Get(explicitColors and H.DivineLabel or H.AscensionLabel)
    local kind = card:AddText(kindLabel)
    kind.TextWrapPos = 0
    kind:SetColor("Text", explicitColors and def.Accent or accent)

    local nameText = Localization.Get(def.Name)
    local name = card:AddText(nameText)
    name.TextWrapPos = 0
    name:SetColor("Text", explicitColors and def.Accent or { 0.94, 0.88, 0.76, 1.00 })
    if def.Desc then
        local desc = card:AddText(Localization.Get(def.Desc))
        desc.TextWrapPos = 0
        desc:SetColor("Text", { 0.88, 0.83, 0.74, 1.00 })
    end
    card:AddSeparator()

    local prog = card:AddText("")
    prog.TextWrapPos = 0
    prog:SetColor("Text", { 0.52, 0.72, 0.90, 1.00 })
    local reward = card:AddText("")
    reward.TextWrapPos = 0
    reward:SetColor("Text", explicitColors and def.Accent or { 0.95, 0.72, 0.28, 1.00 })
    local status = card:AddText("")
    status.TextWrapPos = 0

    local claimButton = nil
    if explicitColors then
        card:AddDummy(1, 4)
        claimButton = card:AddButton("    " .. Localization.Get(H.Claim) .. "    ")
        claimButton.Visible = false
        claimButton.OnClick = function()
            Net.Send("ClaimDivineContract", { Id = def.Id })
        end
    end

    local function update(state)
        state = state or {}
        local c = state.Contracts or {}
        local value = math.min(progress(state, def), def.Need)
        local isDone = (c.Completed ~= nil and c.Completed[def.Id] == true)
        local percent = math.floor((value / def.Need) * 100)
        prog.Label = string.format(Localization.Get(H.ProgressPercent), value, def.Need, percent)
        local rewardText = def.RewardLocalized and Localization.Get(def.Reward) or def.Reward
        reward.Label = Localization.Get(H.Reward) .. " " .. rewardText
        local isClaimed = c.Claimed ~= nil and c.Claimed[def.Id] == true
        if explicitColors then
            if isClaimed then
                status.Label = Localization.Get(H.Claimed)
                status:SetColor("Text", { 0.50, 0.82, 0.46, 1.00 })
                claimButton.Visible = false
            elseif isDone then
                status.Label = Localization.Get(H.ObjectiveDone)
                status:SetColor("Text", def.Accent)
                claimButton.Visible = true
            else
                status.Label = Localization.Get(H.InProgress)
                status:SetColor("Text", { 0.72, 0.68, 0.60, 1.00 })
                claimButton.Visible = false
            end
        else
            status.Label = isDone and (" " .. Localization.Get(H.Done)) or Localization.Get(H.InProgress)
            status:SetColor("Text", isDone and { 0.50, 0.82, 0.46, 1.00 } or { 0.72, 0.68, 0.60, 1.00 })
        end
    end
    Event.On("StateChange", update):Exec(State)
end

function ContractsUI.Main(tab)
    local tabItem = tab:AddTabItem(Localization.Get(H.Tab))
    local page = tabItem:AddChildWindow("ContractsPage")
    page.PositionOffset = { 8, 8 }

    local title = page:AddSeparatorText(Localization.Get(H.MainTitle))
    title:SetColor("Text", { 0.95, 0.72, 0.28, 1.00 })

    local intro = page:AddText(Localization.Get(H.Intro))
    intro.TextWrapPos = 0
    intro:SetColor("Text", { 0.72, 0.68, 0.60, 1.00 })

    -- V8.3E: information belongs at the top, before the contract cards.
    page:AddDummy(1, 6)
    local noteTitle = page:AddSeparatorText(Localization.Get(H.InfoTitle))
    noteTitle:SetColor("Text", { 0.50, 0.66, 0.72, 1.00 })
    local note = page:AddText(Localization.Get(H.InfoText))
    note.TextWrapPos = 0
    note:SetColor("Text", { 0.72, 0.76, 0.76, 1.00 })
    page:AddDummy(1, 10)

    local grid = page:AddTable("ContractsGrid", 2)
    pcall(function() grid:SetStyle("CellPadding", 7, 7) end)

    local currentRow = nil
    for index, def in ipairs(defs) do
        if index % 2 == 1 then
            currentRow = grid:AddRow()
        end

        local cell = currentRow:AddCell()
        local card, accent = CombatTheme.Card(cell, "ContractCard_" .. def.Id, index, 0)

        local kind = card:AddText(Localization.Get(CONTRACT_TYPE_LABEL[def.Kind] or H.ContractLabel))
        kind:SetColor("Text", CONTRACT_TYPE_COLOR[def.Kind] or accent)

        local name = card:AddText(Localization.Get(def.Name))
        name:SetColor("Text", { 0.94, 0.88, 0.76, 1.00 })

        card:AddSeparator()

        local prog = card:AddText("")
        prog:SetColor("Text", { 0.52, 0.72, 0.90, 1.00 })

        local reward = card:AddText("")
        reward:SetColor("Text", { 0.95, 0.72, 0.28, 1.00 })

        local status = card:AddText("")

        local function update(state)
            state = state or {}
            local c = state.Contracts or {}
            local value = math.min(progress(state, def), def.Need)
            local isDone = (c.Completed ~= nil and c.Completed[def.Id] == true)
            local percent = math.floor((value / def.Need) * 100)

            prog.Label = string.format(Localization.Get(H.ProgressPercent), value, def.Need, percent)
            reward.Label = Localization.Get(H.Reward) .. " " .. def.Reward
            status.Label = isDone and (" " .. Localization.Get(H.Done)) or Localization.Get(H.InProgress)
            status:SetColor("Text", isDone and { 0.50, 0.82, 0.46, 1.00 } or { 0.72, 0.68, 0.60, 1.00 })
        end

        Event.On("StateChange", update):Exec(State)
    end

    -- The three Ascension contracts are part of the existing contract list.
    -- Keep them as one 3-card row, but do not create a separate "Nouveaux contrats" section.
    page:AddDummy(1, 8)
    local normalGrid = page:AddTable("ContractsAscensionRow", 3)
    pcall(function() normalGrid:SetStyle("CellPadding", 7, 7) end)
    local normalRow = normalGrid:AddRow()
    for i, def in ipairs(NEW_NORMAL) do addContractCard(normalRow:AddCell(), def, #defs + i, false) end

    page:AddDummy(1, 14)
    local divineTitle = page:AddSeparatorText(Localization.Get(H.DivineTitle))
    divineTitle:SetColor("Text", { 0.90, 0.82, 0.62, 1.00 })
    local divineGrid = page:AddTable("ContractsDivineGrid", 3)
    pcall(function() divineGrid:SetStyle("CellPadding", 7, 7) end)
    local divineRow = divineGrid:AddRow()
    for i, def in ipairs(DIVINE) do addContractCard(divineRow:AddCell(), def, i, true) end

end
