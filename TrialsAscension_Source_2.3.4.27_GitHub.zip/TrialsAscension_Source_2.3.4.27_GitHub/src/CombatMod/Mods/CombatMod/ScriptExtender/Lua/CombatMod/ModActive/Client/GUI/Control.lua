Control = {}

function Control.Events()
    Event.On("Start", function(scenarioName, mapName, difficultyName)
        Net.Request("Start", {
            Scenario = scenarioName,
            Map = mapName,
            Difficulty = difficultyName,
        }):After(DisplayResponse)
    end)

    Event.On("Stop", function() Net.Request("Stop"):After(DisplayResponse) end)
    Event.On("MarkSpawns", function(data) Net.Request("MarkSpawns", data):After(DisplayResponse) end)
    Event.On("PingSpawns", function(data) Net.Request("PingSpawns", data):After(DisplayResponse) end)
    Event.On("Teleport", function(data) Net.Request("Teleport", data):After(DisplayResponse) end)
    Event.On("ToCamp", function() Net.Request("ToCamp"):After(DisplayResponse) end)
    Event.On("ForwardCombat", function() Net.Request("ForwardCombat"):After(DisplayResponse) end)
end

local ASCENSION_GRADES = {
    TA_Text("Novice", "Novice"), TA_Text("Aspirant", "Aspirant"), TA_Text("Initiate", "Initié"),
    TA_Text("Veteran", "Vétéran"), TA_Text("Champion", "Champion"), TA_Text("Herald", "Héraut"),
    TA_Text("Mythic", "Mythique"), TA_Text("Ascendant", "Ascendant"), TA_Text("God", "Dieu"),
}

local ASCENSION_GRADE_COLORS = {
    { 0.72, 0.72, 0.66, 1.00 },
    { 0.58, 0.76, 0.66, 1.00 },
    { 0.42, 0.68, 0.86, 1.00 },
    { 0.38, 0.58, 0.86, 1.00 },
    { 0.66, 0.46, 0.84, 1.00 },
    { 0.82, 0.42, 0.66, 1.00 },
    { 0.86, 0.42, 0.38, 1.00 },
    { 0.92, 0.62, 0.24, 1.00 },
    { 0.78, 0.18, 0.16, 1.00 },
}

local function clampAscensionTier(value)
    local n = tonumber(value) or 1
    if n < 1 then n = 1 end
    if n > #ASCENSION_GRADES then n = #ASCENSION_GRADES end
    return n
end

local function formatNumber(value)
    local n = math.floor(tonumber(value) or 0)
    local sign = n < 0 and "-" or ""
    local s = tostring(math.abs(n))
    local out = s
    while true do
        local nextValue, count = out:gsub("^(%d+)(%d%d%d)", "%1 %2")
        out = nextValue
        if count == 0 then break end
    end
    return sign .. out
end

local function localizedScenarioName(name)
    return TA_DisplayScenarioName(name)
end

local function localizedMapName(name)
    return TA_DisplayMapName(name)
end

local function addDifficulty(selection)
    selection.AddItem(TA_Text("Normal - balanced progression", "Normal - progression équilibrée"), 0)
    selection.AddItem(TA_Text("Challenge - more dangerous enemies", "Challenge - ennemis plus dangereux"), 1)
    selection.AddItem(TA_Text("Hell - punishing experience", "Enfer - expérience punitive"), 2)
end

---@param tab ExtuiTabBar
function Control.Main(tab)
    Control.Events()

    local root = tab:AddTabItem("Combat")
    local content = root:AddChildWindow(U.RandomId())
    content.PositionOffset = { 8, 8 }

    local title = content:AddSeparatorText("Trials Ascension - Roguelike")
    title:SetColor("Text", { 0.95, 0.72, 0.28, 1.00 })

    local progression = content:AddTable("AscensionProgression", 3)
    pcall(function() progression:SetStyle("CellPadding", 14, 8) end)
    local prow = progression:AddRow()

    local gradeCell = prow:AddCell()
    local gradeLabel = gradeCell:AddText(TA_Text("CURRENT TIER", "GRADE ACTUEL"))
    gradeLabel:SetColor("Text", { 0.58, 0.54, 0.48, 1.00 })
    local gradeValue = gradeCell:AddText(TA_Text("Tier 1 - Novice", "Palier 1 - Novice"))

    local rgCell = prow:AddCell()
    local rgLabel = rgCell:AddText("ROGUESCORE")
    rgLabel:SetColor("Text", { 0.58, 0.54, 0.48, 1.00 })
    local rgValue = rgCell:AddText("0")
    rgValue:SetColor("Text", { 0.42, 0.72, 0.92, 1.00 })

    local shardCell = prow:AddCell()
    local shardLabel = shardCell:AddText(TA_Text("ASCENSION SHARDS", "ÉCLATS D'ASCENSION"))
    shardLabel:SetColor("Text", { 0.58, 0.54, 0.48, 1.00 })
    shardCell:AddImage("Item_LOOT_COINS_Electrum_Pile_Small_A", { 42, 42 })
    local shardValue = shardCell:AddText("0")
    shardValue.SameLine = true
    shardValue:SetColor("Text", { 0.95, 0.72, 0.28, 1.00 })

    pcall(function() gradeValue:SetStyle("FontScale", 1.18) end)
    pcall(function() rgValue:SetStyle("FontScale", 1.18) end)
    pcall(function() shardValue:SetStyle("FontScale", 1.18) end)

    local modeLine = content:AddText("")
    modeLine:SetColor("Text", { 0.72, 0.68, 0.60, 1.00 })

    Event.On("StateChange", function(state)
        if not state then
            gradeValue.Label = TA_Text("Loading...", "Chargement...")
            rgValue.Label = "-"
            shardValue.Label = "-"
            modeLine.Label = ""
            return
        end

        local tier = clampAscensionTier(state.AscensionTier)
        gradeValue.Label = string.format(TA_Text("Tier %d - %s", "Palier %d - %s"), tier, ASCENSION_GRADES[tier])
        gradeValue:SetColor("Text", ASCENSION_GRADE_COLORS[tier])
        rgValue.Label = formatNumber(state.RogueScore or 0)
        shardValue.Label = formatNumber(state.Currency or 0)
        modeLine.Label = TA_Text("Mode: ", "Mode : ") .. (state.RogueModeActive and "ROGUELIKE" or TA_Text("CAMPAIGN", "CAMPAGNE"))
    end):Exec(State)

    content:AddDummy(1, 12)

    -- V8.4Z14: keep the current-combat controls on the left and use the
    -- previously empty right side for the mandatory run progression choice.
    local combatArea = content:AddTable("CombatRunModeArea", 2)
    pcall(function() combatArea:SetStyle("CellPadding", 12, 8) end)
    local combatRow = combatArea:AddRow()
    local combatCell = combatRow:AddCell()
    local modeCell = combatRow:AddCell()

    local startHost = combatCell:AddGroup("StartHost")
    local runningHost = combatCell:AddGroup("RunningHost")

    local modeCard, modeAccent = CombatTheme.Card(
        modeCell,
        "RunProgressionModeCard",
        2,
        nil,
        { 0.20, 0.30, 0.38, 1.00 },
        { 0.050, 0.060, 0.070, 0.96 }
    )
    local modeTitle = modeCard:AddSeparatorText(TA_Text("RUN MODE", "MODE DE PARTIE"))
    modeTitle:SetColor("Text", { 0.48, 0.62, 0.72, 1.00 })

    local modeRequirement = modeCard:AddText(TA_Text("Selection required before the first combat.", "Sélection obligatoire avant le premier combat."))
    modeRequirement:SetColor("Text", { 0.92, 0.48, 0.32, 1.00 })
    local modeInfo = modeCard:AddText(TA_Text("Your choice is locked for the entire run.", "Le choix est verrouillé pour toute la run."))
    modeInfo:SetColor("Text", { 0.72, 0.70, 0.66, 1.00 })

    local modeChoiceGroup = modeCard:AddGroup("RunProgressionChoices")

    local classicTitle = modeChoiceGroup:AddText(TA_Text("CLASSIC", "CLASSIQUE"))
    classicTitle:SetColor("Text", { 0.38, 0.78, 0.42, 1.00 })
    modeChoiceGroup:AddText(TA_Text("Starting RG: 0\nXP: x1\nRogueScore: x1\nShards: x1\nStarting bonus: 0", "RG de départ : 0\nXP : x1\nRogueScore : x1\nÉclats : x1\nBonus initial : 0"))
    local classicButton = modeChoiceGroup:AddButton(TA_Text("  CHOOSE CLASSIC  ", "  CHOISIR CLASSIQUE  "))
    pcall(function() classicButton:SetColor("Button", { 0.10, 0.28, 0.13, 1.00 }) end)
    pcall(function() classicButton:SetColor("ButtonHovered", { 0.16, 0.42, 0.20, 1.00 }) end)
    pcall(function() classicButton:SetColor("ButtonActive", { 0.22, 0.56, 0.27, 1.00 }) end)
    classicButton.OnClick = function()
        Net.Request("SetRunProgressionMode", { Mode = "Classic" }):After(DisplayResponse)
    end

    modeChoiceGroup:AddDummy(1, 8)
    local acceleratedTitle = modeChoiceGroup:AddText(TA_Text("ACCELERATED", "ACCÉLÉRÉE"))
    acceleratedTitle:SetColor("Text", { 0.34, 0.66, 0.96, 1.00 })
    modeChoiceGroup:AddText(TA_Text("Starting RG: 25\nXP: x1.75\nRogueScore: x1.75\nShards: x1.75\nStarting bonus: +150 Shards", "RG de départ : 25\nXP : x1,75\nRogueScore : x1,75\nÉclats : x1,75\nBonus initial : +150 Éclats"))
    local acceleratedButton = modeChoiceGroup:AddButton(TA_Text("  CHOOSE ACCELERATED  ", "  CHOISIR ACCÉLÉRÉE  "))
    pcall(function() acceleratedButton:SetColor("Button", { 0.08, 0.22, 0.40, 1.00 }) end)
    pcall(function() acceleratedButton:SetColor("ButtonHovered", { 0.12, 0.34, 0.58, 1.00 }) end)
    pcall(function() acceleratedButton:SetColor("ButtonActive", { 0.18, 0.46, 0.76, 1.00 }) end)
    acceleratedButton.OnClick = function()
        Net.Request("SetRunProgressionMode", { Mode = "Accelerated" }):After(DisplayResponse)
    end

    modeChoiceGroup:AddDummy(1, 8)
    local expressTitle = modeChoiceGroup:AddText("EXPRESS")
    expressTitle:SetColor("Text", { 0.70, 0.48, 0.90, 1.00 })
    modeChoiceGroup:AddText(TA_Text("Starting RG: 50\nXP: x2.5\nRogueScore: x2.5\nShards: x2.5\nStarting bonus: +300 Shards", "RG de départ : 50\nXP : x2,5\nRogueScore : x2,5\nÉclats : x2,5\nBonus initial : +300 Éclats"))
    local expressButton = modeChoiceGroup:AddButton(TA_Text("  CHOOSE EXPRESS  ", "  CHOISIR EXPRESS  "))
    pcall(function() expressButton:SetColor("Button", { 0.24, 0.12, 0.34, 1.00 }) end)
    pcall(function() expressButton:SetColor("ButtonHovered", { 0.34, 0.18, 0.48, 1.00 }) end)
    pcall(function() expressButton:SetColor("ButtonActive", { 0.46, 0.24, 0.62, 1.00 }) end)
    expressButton.OnClick = function()
        Net.Request("SetRunProgressionMode", { Mode = "Express" }):After(DisplayResponse)
    end

    local modeLockedGroup = modeCard:AddGroup("RunProgressionLocked")
    local modeLockedTitle = modeLockedGroup:AddText("")
    local modeLockedStats = modeLockedGroup:AddText("")
    local modeLockedInfo = modeLockedGroup:AddText(TA_Text("Mode locked until the next run.", "Mode verrouillé jusqu'à la prochaine run."))
    modeLockedInfo:SetColor("Text", { 0.68, 0.66, 0.62, 1.00 })

    Event.On("StateChange", function(state)
        local locked = state and state.RunProgressionLocked == true
        modeChoiceGroup.Visible = not locked
        modeLockedGroup.Visible = locked
        modeRequirement.Visible = not locked
        modeInfo.Visible = not locked

        if not locked then return end
        if state.RunProgressionMode == "Express" then
            modeLockedTitle.Label = TA_Text("EXPRESS — LOCKED", "EXPRESS — VERROUILLÉ")
            modeLockedTitle:SetColor("Text", { 0.70, 0.48, 0.90, 1.00 })
            modeLockedStats.Label = TA_Text("Start: RG 50\nXP: x2.5\nRogueScore: x2.5\nShards: x2.5\nStarting bonus: +300 Shards", "Départ : RG 50\nXP : x2,5\nRogueScore : x2,5\nÉclats : x2,5\nBonus initial : +300 Éclats")
        elseif state.RunProgressionMode == "Accelerated" then
            modeLockedTitle.Label = TA_Text("ACCELERATED — LOCKED", "ACCÉLÉRÉE — VERROUILLÉE")
            modeLockedTitle:SetColor("Text", { 0.34, 0.60, 0.82, 1.00 })
            modeLockedStats.Label = TA_Text("Start: RG 25\nXP: x1.75\nRogueScore: x1.75\nShards: x1.75\nStarting bonus: +150 Shards", "Départ : RG 25\nXP : x1,75\nRogueScore : x1,75\nÉclats : x1,75\nBonus initial : +150 Éclats")
        else
            modeLockedTitle.Label = TA_Text("CLASSIC — LOCKED", "CLASSIQUE — VERROUILLÉ")
            modeLockedTitle:SetColor("Text", { 0.38, 0.78, 0.42, 1.00 })
            modeLockedStats.Label = TA_Text("Start: RG 0\nXP: x1\nRogueScore: x1\nShards: x1\nStarting bonus: 0", "Départ : RG 0\nXP : x1\nRogueScore : x1\nÉclats : x1\nBonus initial : 0")
        end
    end):Exec(State)

    Components.Layout(startHost, 3, 1, function(layout)
        local scenarioCell, difficultyCell, mapCell = layout.Cells[1][1], layout.Cells[1][2], layout.Cells[1][3]
        scenarioCell:AddSeparatorText(TA_Text("Scenario", "Scénario"))
        difficultyCell:AddSeparatorText(TA_Text("Difficulty", "Difficulté"))
        mapCell:AddSeparatorText(TA_Text("Map", "Carte"))

        local scenarioSelection = Components.Selection(scenarioCell)
        local difficultySelection = Components.Selection(difficultyCell)
        local mapSelection = Components.Selection(mapCell)

        local scenarioPages = Components.Pagination(scenarioSelection.Root, {}, 6)
        local mapPages = Components.Pagination(mapSelection.Root, {}, 6)
        addDifficulty(difficultySelection)

        Net.On("GetSelection", function(event)
            scenarioSelection.Reset()
            mapSelection.Reset()

            local payload = (event and type(event.Payload) == "table") and event.Payload or {}
            for _, item in ipairs(payload.Scenarios or {}) do
                scenarioSelection.AddItem(localizedScenarioName(item.Name), item.Name)
            end
            scenarioPages.UpdateItems(scenarioSelection.Selectables)

            mapSelection.AddItem(TA_Text("Random", "Aléatoire"), nil)
            if not State.RogueModeActive then
                for _, item in ipairs(payload.Maps or {}) do
                    local displayName = localizedMapName(item.Name)
                    local label = item.Author and (item.Author .. " - " .. displayName) or displayName
                    mapSelection.AddItem(label, item.Name)
                end
            end
            mapPages.UpdateItems(mapSelection.Selectables)
        end)

        scenarioCell:AddDummy(1, 12)
        local startButton = scenarioCell:AddButton(TA_Text("      START COMBAT      ", "      COMMENCER LE COMBAT      "))
        CombatTheme.Primary(startButton)
        local pressed = false
        startButton.OnClick = function()
            if not State or State.RunProgressionLocked ~= true then
                Event.Trigger("Error", TA_Text("Choose Classic, Accelerated or Express first in Run Mode.", "Choisissez d'abord Classique, Accélérée ou Express dans Mode de partie."))
                return
            end
            if pressed then return end
            pressed = true
            startButton:SetStyle("Alpha", 0.55)
            Event.Trigger("Start", scenarioSelection.Value, mapSelection.Value, difficultySelection.Value)
        end

        local campButton = scenarioCell:AddButton(TA_Text("  Return to camp  ", "  Retourner au camp  "))
        CombatTheme.Secondary(campButton)
        campButton.OnClick = function() Event.Trigger("ToCamp") end

        Components.Conditional(mapCell, function(cond)
            local grp = cond.Root:AddGroup("DebugStart")
            grp:AddSeparatorText("Debug")
            local dbgTeleport = grp:AddButton(TA_Text("  Teleport to map  ", "  Téléporter sur la carte  "))
            CombatTheme.Secondary(dbgTeleport)
            dbgTeleport.OnClick = function() Event.Trigger("Teleport", { Map = mapSelection.Value }) end
            local dbgPing = grp:AddButton(TA_Text("  Ping spawns  ", "  Ping des spawns  "))
            CombatTheme.Secondary(dbgPing)
            dbgPing.OnClick = function() Event.Trigger("PingSpawns", { Map = mapSelection.Value }) end
            local dbgKill = grp:AddButton(TA_Text("  Kill spawned enemies  ", "  Tuer les ennemis invoqués  "))
            CombatTheme.Secondary(dbgKill)
            dbgKill.OnClick = function() Net.Send("KillSpawned") end
            return grp
        end, "ToggleDebug").Update(Mod.Debug)

        Event.On("StateChange", function(state)
            pressed = false
            local modeReady = state and state.RunProgressionLocked == true
            startButton:SetStyle("Alpha", modeReady and 1 or 0.55)
            startButton.Label = modeReady and TA_Text("      START COMBAT      ", "      COMMENCER LE COMBAT      ") or TA_Text("      CHOOSE A MODE      ", "      CHOISISSEZ UN MODE      ")
            Net.Send("GetSelection")
        end)
    end)

    local encounterTitle = runningHost:AddSeparatorText(TA_Text("Current combat", "Combat actuel"))
    encounterTitle:SetColor("Text", { 0.82, 0.62, 0.28, 1.00 })

    -- Camp selector lives beside Combat actuel. With Progression régionale enabled,
    -- the server only exposes camps belonging to the RogueScore-unlocked act.
    local campSelectButton = runningHost:AddButton(TA_Text("  Camp: automatic  ", "  Camp : automatique  "))
    campSelectButton.SameLine = true
    CombatTheme.Secondary(campSelectButton)
    local campPopup = runningHost:AddPopup("")
    campPopup.IDContext = U.RandomId()
    campPopup:AddSeparatorText(TA_Text("Trials Ascension main camp", "Camp principal Trials Ascension"))
    local campPopupItems = {}

    local function clearCampPopupItems()
        for _, item in ipairs(campPopupItems) do
            pcall(function() item:Destroy() end)
        end
        campPopupItems = {}
    end

    local function prettyCampId(id)
        if not id or id == "" then return TA_Text("automatic", "automatique") end
        local value = tostring(id):gsub("_", " ")
        return value
    end

    local function rebuildCampPopup(payload)
        clearCampPopupItems()

        local regional = payload and payload.RegionalEnabled == true
        local stageName = payload and payload.StageName or nil
        local autoLabel = regional
            and ("  " .. TA_Text("Automatic - ", "Automatique - ") .. tostring(stageName or TA_Text("current act", "acte actuel")) .. "  ")
            or TA_Text("  Automatic (BG3) - no lock  ", "  Automatique (BG3) - aucun verrouillage  ")

        local auto = campPopup:AddButton(autoLabel)
        auto.IDContext = U.RandomId()
        table.insert(campPopupItems, auto)
        auto.OnClick = function()
            Net.Request("SetLockedCamp", { Id = nil }):After(DisplayResponse)
        end

        if regional then
            local info = campPopup:AddText(
                TA_Text("Camps available for: ", "Camps autorisés pour : ") .. tostring(stageName or TA_Text("current act", "acte actuel")) ..
                TA_Text(". The next region is activated automatically with RogueScore.", ". La région suivante est activée automatiquement avec le RogueScore.")
            )
            info:SetColor("Text", { 0.72, 0.72, 0.68, 1.00 })
            table.insert(campPopupItems, info)
        end

        local camps = payload and payload.Camps or {}
        for _, camp in ipairs(camps) do
            local suffix = ""
            if camp.Locked then suffix = TA_Text("  [LOCKED]", "  [VERROUILLÉ]")
            elseif camp.Active then suffix = TA_Text("  [CURRENT]", "  [ACTUEL]") end

            local regions = ""
            if camp.Regions and #camp.Regions > 0 then
                regions = " - " .. table.concat(camp.Regions, ", ")
            end

            local b = campPopup:AddButton("  " .. prettyCampId(camp.Id) .. regions .. suffix .. "  ")
            b.IDContext = U.RandomId()
            table.insert(campPopupItems, b)
            b.OnClick = function()
                Net.Request("SetLockedCamp", { Id = camp.Id }):After(DisplayResponse)
            end
        end
    end

    campSelectButton.OnClick = function()
        Net.Request("GetCampList"):After(function(event)
            rebuildCampPopup(event and event.Payload or {})
            campPopup:Open()
        end)
    end

    Event.On("StateChange", function(state)
        local locked = state and state.LockedCampId or nil
        local stageName = state and state.RegionalStageName or nil
        local prefix = (state and state.RegionalProgressionEnabled ~= false and stageName)
            and ("Camp " .. tostring(stageName) .. " : ")
            or "Camp : "

        campSelectButton.Label = locked
            and ("  " .. prefix .. prettyCampId(locked) .. "  ")
            or ("  " .. prefix .. TA_Text("automatic", "automatique") .. "  ")
    end):Exec(State)

    local runningText = runningHost:AddText("")
    runningText:SetColor("Text", { 0.90, 0.86, 0.76, 1.00 })
    Components.Computed(runningText, function(_, state)
        if not state or not state.Scenario then return "" end
        local s = state.Scenario
        local difficulty = state.SuperHardMode and TA_Text("Hell", "Enfer") or (state.HardMode and "Challenge" or "Normal")
        local map = s.Map and localizedMapName(s.Map.Name) or "?"
        return string.format(TA_Text(
            "Scenario: %s\nDifficulty: %s     Map: %s\nRound: %s / %s     Enemies defeated: %s",
            "Scénario : %s\nDifficulté : %s     Carte : %s\nManche : %s / %s     Ennemis vaincus : %s"
        ), localizedScenarioName(s.Name), difficulty, tostring(map), tostring(s.Round or 0), tostring(#(s.Timeline or {})), tostring(#(s.KilledEnemies or {})))
    end, "StateChange")

    local teleport = runningHost:AddButton(TA_Text("      START COMBAT      ", "      COMMENCER LE COMBAT      "))
    CombatTheme.Primary(teleport)
    teleport.OnClick = function()
        if not State or State.RunProgressionLocked ~= true then
            Event.Trigger("Error", TA_Text("Choose Classic, Accelerated or Express first in Run Mode.", "Choisissez d'abord Classique, Accélérée ou Express dans Mode de partie."))
            return
        end
        if State and State.Scenario and State.Scenario.Map then
            Event.Trigger("Teleport", { Map = State.Scenario.Map.Name, Restrict = true })
        else
            Event.Trigger("Error", TA_Text("No active scenario.", "Aucun scénario actif."))
        end
    end

    local returnCamp = runningHost:AddButton(TA_Text("  Return to camp  ", "  Retourner au camp  "))
    CombatTheme.Secondary(returnCamp)
    returnCamp.OnClick = function() Event.Trigger("ToCamp") end

    -- Advanced scenario controls are test/debug tools. Keep the normal Combat
    -- tab focused on the actions a player actually needs during a run.
    Components.Conditional(runningHost, function(cond)
        local grp = cond.Root:AddGroup("DebugCombat")
        grp:AddSeparatorText("Debug combat")

        local nextRound = grp:AddButton(TA_Text("  Next round  ", "  Manche suivante  "))
        CombatTheme.Secondary(nextRound)
        nextRound.OnClick = function() Event.Trigger("ForwardCombat") end

        local markSpawns = grp:AddButton(TA_Text("  Show spawn points  ", "  Afficher les points d'apparition  "))
        CombatTheme.Secondary(markSpawns)
        markSpawns.OnClick = function()
            if State and State.Scenario and State.Scenario.Map then
                Event.Trigger("MarkSpawns", { Map = State.Scenario.Map.Name })
            end
        end

        local kill = grp:AddButton(TA_Text("  Kill spawned enemies  ", "  Tuer les ennemis invoqués  "))
        CombatTheme.Secondary(kill)
        kill.OnClick = function() Net.Send("KillSpawned") end

        local ping = grp:AddButton(TA_Text("  Ping spawns  ", "  Ping des spawns  "))
        CombatTheme.Secondary(ping)
        ping.OnClick = function()
            if State and State.Scenario and State.Scenario.Map then
                Event.Trigger("PingSpawns", { Map = State.Scenario.Map.Name })
            end
        end

        return grp
    end, "ToggleDebug").Update(Mod.Debug)

    Event.On("StateChange", function(state)
        -- ExtUI Visible is strictly boolean; never pass nil during the first
        -- StateChange/Exec before State is available.
        local running = (state ~= nil and state.Scenario ~= nil) and true or false
        local locked = (state ~= nil and state.RunDifficultyLocked == true) and true or false

        -- Do not briefly expose the difficulty selectors between ScenarioEnded
        -- and the automatically prepared next scenario.
        startHost.Visible = (not running and not locked)
        runningHost.Visible = (running or locked) and true or false

        local modeReady = (state ~= nil and state.RunProgressionLocked == true) and true or false
        teleport:SetStyle("Alpha", modeReady and 1 or 0.55)
        teleport.Label = modeReady and TA_Text("      START COMBAT      ", "      COMMENCER LE COMBAT      ") or TA_Text("      CHOOSE A MODE      ", "      CHOISISSEZ UN MODE      ")

        if not running and locked then
            runningText.Label = TA_Text("Difficulty locked for this run. Returning to camp...", "Difficulté verrouillée pour cette partie. Retour au camp en cours...")
        end
    end):Exec()

    content:AddDummy(1, 18)

    local infoTitle = content:AddSeparatorText(TA_Text("Ascension Information", "Information de l'Ascension"))
    infoTitle:SetColor("Text", { 0.82, 0.62, 0.28, 1.00 })
    local info = content:AddText(TA_Text(
        "Your RogueScore increases after each completed combat.\n" ..
        "Encounter power increases with your RogueScore.\n" ..
        "At certain tiers, new rewards and features become available.\n" ..
        "Choose your difficulty, start the combat, then continue your ascension until the end of the run.",
        "Votre RogueScore augmente après chaque combat terminé.\n" ..
        "La puissance des rencontres augmente avec votre RogueScore.\n" ..
        "À certains paliers, de nouvelles récompenses et fonctionnalités deviennent disponibles.\n" ..
        "Choisissez votre difficulté, lancez le combat, puis poursuivez votre ascension jusqu'à la fin de la run."
    ))
    info:SetColor("Text", { 0.80, 0.76, 0.68, 1.00 })

    content:AddDummy(1, 12)
    local helpTitle = content:AddSeparatorText(TA_Text("Help & Troubleshooting", "Aide & dépannage"))
    helpTitle:SetColor("Text", { 0.42, 0.68, 0.86, 1.00 })
    local help = content:AddText(TA_Text(
        "If Long Rest no longer works, open the Extras tab and use the corresponding repair tool.\n" ..
        "If a camp NPC is missing, use Return to camp or the repair tools available in Extras.\n" ..
        "Also use Return to camp if the end of a combat does not return you correctly.\n" ..
        "These tools are emergency solutions and are not normally needed during a run.",
        "Si le repos long ne fonctionne plus, ouvrez l'onglet Extras et utilisez l'outil de réparation correspondant.\n" ..
        "Si un PNJ du camp est absent, utilisez Retourner au camp ou les outils de correction disponibles dans Extras.\n" ..
        "Utilisez également Retourner au camp si la fin d'un combat ne vous y ramène pas correctement.\n" ..
        "Ces outils sont des solutions de secours et ne sont normalement pas nécessaires pendant une run."
    ))
    help:SetColor("Text", { 0.72, 0.78, 0.84, 1.00 })

    content:AddDummy(1, 12)
    local devTitle = content:AddSeparatorText(TA_Text("Developer Note", "Note du développeur"))
    devTitle:SetColor("Text", { 0.62, 0.46, 0.78, 1.00 })
    local dev = content:AddText(TA_Text(
        "Trials Ascension is designed as a continuous roguelike progression.\n" ..
        "If an issue prevents the run from continuing normally, check the Extras tab, which contains several repair and troubleshooting tools.\n\n" ..
        "Trials Ascension is a roguelike overhaul built from Hippo0o's work on Trials of Tav and celerev's work on Trials of Tav Reloaded.\n" ..
        "Development, overhaul and additional Trials Ascension content: Jam4_.",
        "Trials Ascension est conçu comme une progression roguelike continue.\n" ..
        "Si un problème empêche la poursuite normale de la run, consultez l'onglet Extras, qui contient plusieurs outils de correction et de dépannage.\n\n" ..
        "Trials Ascension est une refonte roguelike construite à partir du travail de Hippo0o sur Trials of Tav et de celerev sur Trials of Tav Reloaded.\n" ..
        "Développement, refonte et contenu additionnel de Trials Ascension : Jam4_."
    ))
    dev:SetColor("Text", { 0.72, 0.68, 0.76, 1.00 })

    Net.Send("GetSelection")
end
