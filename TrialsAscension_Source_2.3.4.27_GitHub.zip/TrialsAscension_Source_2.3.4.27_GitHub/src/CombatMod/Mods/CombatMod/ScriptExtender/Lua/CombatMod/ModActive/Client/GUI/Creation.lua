Creation = {}
local function request(op, fields, after)
    fields = fields or {}; fields.Op=op
    return Net.Request("DebugCommand",fields):After(function(event)
        local p=event.Payload or {}
        if not p[1] then Event.Trigger("Error", p[2] or TA_Text("Command refused", "Commande refusée")); return end
        if after then after(table.unpack(p,2)) end
    end)
end
local function coordinates(text)
    local x,y,z=text:match("^%s*([^,]+),%s*([^,]+),%s*([^,]+)%s*$")
    x,y,z=tonumber(x),tonumber(y),tonumber(z)
    if not x or not y or not z then Event.Trigger("Error","Format attendu : x, y, z");return end
    return {X=x,Y=y,Z=z}
end

---@param tab ExtuiTabBar
function Creation.Main(tab)
    ---@type ExtuiTree
    local root = tab:AddTabItem(__("Creation"))

    do
        ---@type ExtuiInputText
        local posBox = root:AddInputText("List")
        posBox.Multiline = true

        local pb = root:AddButton(__("Pos"))
        pb.SameLine = true

        local pi = root:AddInputText(__("Pos"))
        pi.IDContext = U.RandomId()
        pi.Text = "0, 0, 0"
        local ping = root:AddButton(__("Ping"))
        ping.SameLine = true
        local tp = root:AddButton(__("TP"))
        tp.SameLine = true

        pb.OnClick = function()
            local host = GE.GetHost()
            local region = host.Level.LevelName
            L.Dump("Host", host.CustomName)
            request("Position", nil, function(x,y,z)
                posBox.Text = posBox.Text .. string.format("%s: %s, %s, %s", region, x, y, z) .. "\n"
                pi.Text = string.format("%s, %s, %s", x, y, z)
            end)
        end
        ping.OnClick = function()
            local p=coordinates(pi.Text); if p then request("Ping",p) end
        end
        tp.OnClick = function()
            local p=coordinates(pi.Text); if p then request("TeleportPosition",p) end
        end
    end

    do
        local uwp = root:AddButton(__("Unlock Waypoints"))
        uwp.OnClick = function()
            request("UnlockWaypoints")
        end
        local wp = root:AddCollapsingHeader(__("Waypoints"))
        wp.SameLine = true
        Components.Layout(wp, 1, 1, function(layout)
            layout.Table.ScrollY = true
            local wp = layout.Cells[1][1]

            local acts = table.keys(C.Waypoints)
            table.sort(acts)
            for _, act in ipairs(acts) do
                wp:AddSeparatorText(act .. " - " .. C.Regions[act])
                for short, waypoint in pairs(C.Waypoints[act]) do
                    local label = waypoint:gsub(string.escape(U.UUID.Extract(waypoint)), short)
                    local b = wp:AddButton(label)
                    b.OnClick = function()
                        request("TeleportWaypoint", {Waypoint=waypoint})
                    end
                end
            end
        end)
    end

    return root
end
