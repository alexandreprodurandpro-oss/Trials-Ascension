-- Trials Ascension V8.4V: typed replacements for the retired RCE debug channel.
local function exactFields(p, fields)
    if type(p) ~= "table" then return false end
    for k in pairs(p) do if not fields[k] then return false end end
    return true
end
local function finite(v)
    return type(v) == "number" and v == v and math.abs(v) <= 100000
end
local function coords(p)
    return exactFields(p, {Op=true,X=true,Y=true,Z=true}) and finite(p.X) and finite(p.Y) and finite(p.Z)
end
local function ident(v)
    return type(v) == "string" and #v > 0 and #v <= 200 and v:match("^[%w_%-]+$") ~= nil
end
local operations = {}
operations.Position = function(p, character)
    assert(exactFields(p,{Op=true}), TA_Text("Invalid parameters", "Paramètres invalides"))
    local x,y,z=Osi.GetPosition(character)
    Osi.RequestPing(x,y,z,"","")
    return {true,x,y,z}
end
operations.Ping = function(p)
    assert(coords(p), TA_Text("Invalid coordinates", "Coordonnées invalides"))
    Osi.RequestPing(p.X,p.Y,p.Z,"","")
    return {true}
end
operations.TeleportPosition = function(p, character)
    assert(coords(p), TA_Text("Invalid coordinates", "Coordonnées invalides"))
    assert(Osi.IsInCombat(character) ~= 1, TA_Text("Debug teleport unavailable during combat", "Téléportation debug indisponible en combat"))
    local x,y,z=Osi.FindValidPosition(p.X,p.Y,p.Z,5,character,1)
    assert(x and y and z, TA_Text("No accessible position nearby", "Aucune position accessible à proximité"))
    Osi.TeleportToPosition(character,x,y,z,"",0,0,0,0,1)
    return {true}
end
operations.UnlockWaypoints = function(p)
    assert(exactFields(p,{Op=true}), TA_Text("Invalid parameters", "Paramètres invalides"))
    Osi.PROC_Debug_UnlockAllWP()
    return {true}
end
operations.TeleportWaypoint = function(p,character)
    assert(exactFields(p,{Op=true,Waypoint=true}) and ident(p.Waypoint), TA_Text("Invalid waypoint", "Point de passage invalide"))
    assert(Osi.IsInCombat(character) ~= 1, TA_Text("Debug teleport unavailable during combat", "Téléportation debug indisponible en combat"))
    local allowed=false
    for _,act in pairs(C.Waypoints) do
        for _,waypoint in pairs(act) do if waypoint==p.Waypoint then allowed=true end end
    end
    assert(allowed,TA_Text("Waypoint is not present in the server list", "Point de passage absent de la liste serveur"))
    TeleportToWaypoint(character,p.Waypoint)
    return {true}
end
operations.SpawnEnemy = function(p,character)
    assert(exactFields(p,{Op=true,TemplateId=true}) and ident(p.TemplateId), TA_Text("Invalid template", "Modèle invalide"))
    local list=Enemy.GetByTemplateId(p.TemplateId)
    assert(list and list[1], TA_Text("Enemy is not present in the server list", "Ennemi absent de la liste serveur"))
    assert(list[1]:Spawn(Osi.GetPosition(character)), TA_Text("Failed to create this enemy", "Échec de création de cet ennemi"))
    return {true}
end
operations.SpawnItem = function(p,character)
    assert(exactFields(p,{Op=true,Name=true,RootTemplate=true}) and ident(p.Name)
        and ident(p.RootTemplate), TA_Text("Invalid item", "Objet invalide"))
    local found
    for _,items in ipairs({Item.Objects(nil,false),Item.Objects(nil,true),Item.Armor(),Item.Weapons()}) do
        for _,item in pairs(items) do
            if item.Name==p.Name and item.RootTemplate==p.RootTemplate then found=item;break end
        end
        if found then break end
    end
    assert(found,TA_Text("Item is not present in the server list", "Objet absent de la liste serveur"))
    assert(Item.Create(found.Name,found.Type,found.RootTemplate,found.Rarity):Spawn(Osi.GetPosition(character)), TA_Text("Failed to create this item", "Échec de création de cet objet"))
    return {true}
end

local function amount(p, maximum)
    assert(exactFields(p,{Op=true,Value=true}) and type(p.Value)=="number"
        and p.Value==p.Value and p.Value%1==0 and p.Value>=0 and p.Value<=maximum,
        TA_Text("Non-negative integer value out of range", "Valeur entière positive ou nulle hors limites"))
    return p.Value
end
operations.SetRogueScore=function(p)
    PersistentVars.RogueScore=amount(p,100000)
    Event.Trigger("RogueScoreChanged",PersistentVars.RogueScore)
    return {true}
end
operations.SetCurrency=function(p)
    PersistentVars.Currency=amount(p,1000000000)
    return {true}
end
operations.SetConquestTokens=function(p)
    PersistentVars.ConquestTokens=amount(p,1000000)
    return {true}
end
operations.GiveExperience=function(p)
    Player.GiveExperience(amount(p,1000000000))
    return {true}
end

local recent = {}
Net.On("DebugCommand",function(event)
    -- Defense in depth: also works if invoked directly, outside the Net dispatcher.
    if not event:IsHost() then Net.Respond(event,{false,TA_Text("Command restricted to the host.", "Commande réservée à l'hôte.")});return end
    local p=event.Payload
    if type(p)~="table" or type(p.Op)~="string" or not operations[p.Op] then
        Net.Respond(event,{false,TA_Text("Unknown debug command.", "Commande debug inconnue.")});return
    end
    local now=Ext.Utils.MonotonicTime()
    local last=recent[event.PeerId]
    if last and now-last < 100 then
        Net.Respond(event,{false,TA_Text("Please wait a moment before the next command.", "Attendez un instant avant la prochaine commande.")});return
    end
    recent[event.PeerId]=now
    local character=event:Character()
    if not character or Osi.IsCharacter(character)~=1 or Osi.IsPlayer(character)~=1 then
        Net.Respond(event,{false,TA_Text("No controllable character selected.", "Aucun personnage contrôlable sélectionné.")});return
    end
    local ok,result=pcall(operations[p.Op],p,character)
    if not ok then L.Error("DebugCommand "..p.Op..": "..tostring(result)) end
    Net.Respond(event,ok and result or {false,tostring(result)})
end)
