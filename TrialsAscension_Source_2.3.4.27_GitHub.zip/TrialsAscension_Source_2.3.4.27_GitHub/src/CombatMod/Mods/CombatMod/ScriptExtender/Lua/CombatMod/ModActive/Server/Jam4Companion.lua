-- Trials Ascension V8.4Z13 - Jam4_ Easter Egg camp guest; recruitment deliberately paused.
-- Important: the natural encounter uses the same RNG philosophy as the existing
-- neutral dialogue encounter rather than an enemy tier replacement.
-- neutral dialogue/recruitment encounter rather than an enemy tier replacement.

Jam4Companion = Jam4Companion or {}

local JAM4_TEMPLATE = "4f593b14-4f08-4b74-a4d1-839b2f0e7c41"
local JAM4_ENEMY_TEMPLATE = "1e24f54b-5239-4ddd-8f2d-4a884035668d"
local JAM4_ENEMY_LOADOUT = "TOT_JAM4_ENEMY_LOADOUT"
local JAM4_GOD_STATUS = "TOT_GOD_V2_001"
local WITHERS = "S_GLO_JergalAvatar_0133f2ad-e121-4590-b5f0-a79413919805"
local JAM4_VOICE5 = "f5b335b2-9cd9-4b38-a4c1-458b846ab499" -- Tav Voice 5 (male)
local BLOCK_RESURRECTION_TAG = "BLOCK_RESURRECTION_22a75dbb-1588-407e-b559-5aa4e6d4e6a6"

-- Fixed combat package is reserved for hostile Jam4_.
-- The recruited companion uses native class progression exclusively.
local PHASE1_BUILD_PASSIVES = {
    "TOT_JAM4_P1_RESOURCES",
    "TOT_JAM4_P1_BARD_CORE",
    "TOT_JAM4_P1_BARD_SPELLS",
    "TOT_JAM4_P1_BARD_SPELLCASTING",
    "TOT_JAM4_P1_FONT_OF_INSPIRATION",
    "TOT_JAM4_P1_JACK_OF_ALL_TRADES",
    "TOT_JAM4_P1_EXTRA_ATTACK",
    "TOT_JAM4_P1_FIGHTER_CORE",
    "TOT_JAM4_P1_FAST_HANDS",
    "TOT_JAM4_P1_ROGUE_CORE",
}
local JAM4_BARDIC_D8 = "BardicInspiration_d8"
local BARD_CLASS_UUID = "92cd50b6-eb1b-4824-8adb-853e90c34c90"

local MIN_RG = 100
local ENCOUNTER_CHANCE = 0.03 -- 3% per eligible completed combat, easy to tune later.
local RECRUITMENT_ENABLED = false -- Z13: recruitment deliberately paused; Jam4_ becomes a camp guest on success.

local CRITFAIL_WATCH_PASSIVE = "TOT_JAM4_CRITFAIL_WATCH"
local CRITFAIL_SIGNAL_STATUS = "TOT_JAM4_CRITFAIL_SIGNAL"
local BARK_CHANCE = 0.10

local quizSessions = {}
local interactionBusy = {}
local barkBusy = false
local lastBarkIndex = { CritFail=0, CritHit=0, AllyDeath=0 }
local voiceApplyPending = {}

local H = {
    Intro="h84l10000000000000000000000000002", IntroYes="h84l10000000000000000000000000003", IntroNo="h84l10000000000000000000000000004",
    Q1="h84l10000000000000000000000000005", Q1A="h84l10000000000000000000000000006", Q1B="h84l10000000000000000000000000007",
    Q2="h84l10000000000000000000000000008", Q2A="h84l10000000000000000000000000009", Q2B="h84l10000000000000000000000000010",
    Q3="h84l10000000000000000000000000011", Q3A="h84l10000000000000000000000000012", Q3B="h84l10000000000000000000000000013",
    Success="h84l10000000000000000000000000014", Failure="h84l10000000000000000000000000015", Already="h84l10000000000000000000000000016", CampGuest="h84l10000000000000000000000000017",
    BarkFail1="h84r00000000000000000000000000101", BarkFail2="h84r00000000000000000000000000102", BarkFail3="h84r00000000000000000000000000103", BarkFail4="h84r00000000000000000000000000104", BarkFail5="h84r00000000000000000000000000105",
    BarkCrit1="h84r00000000000000000000000000111", BarkCrit2="h84r00000000000000000000000000112", BarkCrit3="h84r00000000000000000000000000113", BarkCrit4="h84r00000000000000000000000000114", BarkCrit5="h84r00000000000000000000000000115",
    BarkDeath1="h84r00000000000000000000000000121", BarkDeath2="h84r00000000000000000000000000122", BarkDeath3="h84r00000000000000000000000000123", BarkDeath4="h84r00000000000000000000000000124", BarkDeath5="h84r00000000000000000000000000125",
}

local function loc(handle)
    local value = Localization.Get(handle)
    return (value and value ~= "") and value or handle
end

local QUESTIONS = {
    { message=H.Q1, a=H.Q1A, b=H.Q1B, correct="B" },
    { message=H.Q2, a=H.Q2A, b=H.Q2B, correct="B" },
    { message=H.Q3, a=H.Q3A, b=H.Q3B, correct="A" },
}

local BARKS = {
    CritFail={H.BarkFail1,H.BarkFail2,H.BarkFail3,H.BarkFail4,H.BarkFail5},
    CritHit={H.BarkCrit1,H.BarkCrit2,H.BarkCrit3,H.BarkCrit4,H.BarkCrit5},
    AllyDeath={H.BarkDeath1,H.BarkDeath2,H.BarkDeath3,H.BarkDeath4,H.BarkDeath5},
}

local function defaultState()
    return {
        State="NotMet", GUID=nil, Recruited=false, AtCamp=false,
        Failed=false, EnemyPending=false, EnemyInjected=false, EnemySpawning=false,
        NativePartyInitialized=false, NativePartyInGroup=false,
        BuildOverriddenByRespec=false,
        EligibleCombats=0, QuizStep=0, QuizPlayer=nil,
    }
end

local function state()
    if type(PersistentVars.Jam4) ~= "table" then PersistentVars.Jam4 = defaultState() end
    local s = PersistentVars.Jam4
    for k,v in pairs(defaultState()) do if s[k] == nil then s[k] = v end end
    return s
end

local function validCharacter(guid)
    return guid and guid ~= "" and Ext.Entity.Get(guid) ~= nil and Osi.IsCharacter(guid) == 1
end

-- V8.4Z: Jam4_ uses Tav Voice 5.  Voice is an ECS component, so apply it on a
-- deferred tick and coalesce requests.  This avoids writing the component twice in
-- the same engine tick, a pattern known to be unstable on some BG3SE/game versions.
local function applyJam4Voice(guid)
    if not validCharacter(guid) then return false end
    local ok, result = pcall(function()
        local entity = Ext.Entity.Get(guid)
        if not entity then return false end
        if not entity.Voice then entity:CreateComponent("Voice") end
        if not entity.Voice then return false end
        local current = tostring(entity.Voice.Voice or ""):lower()
        if current:find(JAM4_VOICE5, 1, true) then return true end
        entity.Voice.Voice = JAM4_VOICE5
        entity:Replicate("Voice")
        return true
    end)
    if not ok then
        L.Error("Jam4 Voice 5: " .. tostring(result))
        return false
    end
    return result == true
end

local function queueJam4Voice(guid, delay)
    if not guid or guid == "" or voiceApplyPending[guid] then return end
    voiceApplyPending[guid] = true
    Defer(delay or 250, function()
        voiceApplyPending[guid] = nil
        applyJam4Voice(guid)
    end)
end

local function isPlayable(guid)
    if not validCharacter(guid) then return false end
    local ok, player = pcall(Osi.IsPlayer, guid)
    return ok and player == 1
end

local function forceCombatDress(guid)
    if not validCharacter(guid) then return end
    -- V8.4W: only select the native adventure armour set.  Do not manufacture or
    -- rewrite Story cache rows: equipped/unequipped items must remain player-owned.
    local ok, err = pcall(Osi.SetArmourSet, guid, "Normal")
    if not ok then L.Error("Jam4 armour-set selection: " .. tostring(err)) end
end

-- Native resurrection scrolls/Withers story logic relies on DB_CanBeResurrected.
-- Dynamic companions do not automatically inherit every Origin story fact, so Jam4_
-- explicitly joins that vanilla DB after recruitment.  BLOCK_RESURRECTION is cleared
-- first, matching the game's own companion repair logic for Jaheira/Minsc.
local function registerNativeResurrection(guid)
    if not validCharacter(guid) then return false end
    pcall(Osi.ClearTag, guid, BLOCK_RESURRECTION_TAG)
    local already = false
    local okRows, rows = pcall(function() return Osi.DB_CanBeResurrected:Get(guid) end)
    if okRows and type(rows) == "table" and #rows > 0 then already = true end
    if not already then
        local ok, err = pcall(function() Osi.DB_CanBeResurrected(guid) end)
        if not ok then
            L.Error("Jam4 DB_CanBeResurrected: " .. tostring(err))
            return false
        end
    end
    return true
end

local function unregisterNativeResurrection(guid)
    if not guid or guid == "" then return end
    pcall(function() Osi.DB_CanBeResurrected:Delete(guid) end)
end

-- Never manufacture active-player rows for an unconverted NPC.
local function registerNativePlayerRows(guid)
    if not isPlayable(guid) then return false end
    pcall(function() Osi.DB_PartOfTheTeam(guid) end)
    pcall(function() Osi.DB_IsOrWasInParty(guid) end)
    pcall(function() Osi.DB_Players(guid) end)
    pcall(function() Osi.DB_PartyMembers(guid) end)
    pcall(function() Osi.ProcRegisterPlayerTriggers(guid) end)
    pcall(function() Osi.PROC_CheckPartyFull() end)
    registerNativeResurrection(guid)
    return true
end

local function unregisterNativePlayerRows(guid)
    if not guid or guid == "" then return end
    pcall(function() Osi.DB_Players:Delete(guid) end)
    pcall(function() Osi.DB_PartyMembers:Delete(guid) end)
end

local function unregisterNativeRosterRows(guid)
    if not guid or guid == "" then return end
    unregisterNativeResurrection(guid)
    pcall(function() Osi.DB_PartOfTheTeam:Delete(guid) end)
    pcall(function() Osi.DB_IsOrWasInParty:Delete(guid) end)
    pcall(function() Osi.DB_GLO_PartyMembers_DefaultFaction:Delete(guid, C.CompanionFaction) end)
    pcall(function() Osi.ProcUnRegisterPlayerTriggers(guid) end)
    pcall(function() Osi.PROC_CheckPartyFull() end)
end

-- Story registration alone does not guarantee conversion of a dynamic NPC.
local function nativePartyAdd(guid, recruiter)
    if not validCharacter(guid) or not validCharacter(recruiter) then return false end
    local s = state()
    pcall(function() Osi.DB_GLO_PartyMembers_DefaultFaction(guid, C.CompanionFaction) end)
    if not s.NativePartyInitialized then
        local ok, err = pcall(Osi.PROC_GLO_PartyMembers_Initialize, guid)
        s.NativePartyInitialized = ok
        if not ok then L.Error("Jam4 story initialization: " .. tostring(err)) end
    end
    local registered, err = pcall(Osi.RegisterAsCompanion, guid, recruiter)
    if not registered then L.Error("Jam4 companion registration: " .. tostring(err));return false end
    if not isPlayable(guid) then
        -- A story procedure can succeed as a Lua call while its rules do nothing.
        pcall(Osi.PROC_GLO_PartyMembers_Add, guid, recruiter)
        if not isPlayable(guid) then
            local ok, convertError = pcall(Osi.MakePlayer, guid, recruiter, 1)
            if not ok then L.Error("Jam4 MakePlayer: " .. tostring(convertError)) end
        end
    end
    if isPlayable(guid) then
        -- Register once more after MakePlayer: RegisterAsCompanion called on the NPC
        -- before conversion only gives NPC companion/long-rest semantics.
        pcall(Osi.RegisterAsCompanion, guid, recruiter)
        registerNativePlayerRows(guid)
        pcall(Osi.AttachToPartyGroup, guid, recruiter)
        s.NativePartyInGroup = true
    else
        s.NativePartyInGroup = false
    end
    registerNativeResurrection(guid)
    forceCombatDress(guid)
    return isPlayable(guid)
end


local function jam4CanBark()
    local s = state()
    if not validCharacter(s.GUID) or Osi.IsDead(s.GUID) == 1 or Osi.IsInCombat(s.GUID) ~= 1 then return false end
    return s.Recruited or s.State == "EnemyFight"
end

local function installCritFailWatchers()
    local jam = state().GUID
    for _,character in pairs(GU.DB.GetPlayers()) do
        if validCharacter(character) and (not jam or not U.UUID.Equals(character,jam)) and Osi.HasPassive(character, CRITFAIL_WATCH_PASSIVE) ~= 1 then
            pcall(Osi.AddPassive, character, CRITFAIL_WATCH_PASSIVE)
        end
    end
end

local function removeCritFailWatchers()
    for _,character in pairs(GU.DB.GetPlayers()) do
        if validCharacter(character) and Osi.HasPassive(character, CRITFAIL_WATCH_PASSIVE) == 1 then
            pcall(Osi.RemovePassive, character, CRITFAIL_WATCH_PASSIVE)
        end
    end
end

local function maybeBark(category)
    if barkBusy or not jam4CanBark() or math.newRandom() >= BARK_CHANCE then return false end
    local lines = BARKS[category]
    if not lines or #lines == 0 then return false end
    local idx = math.floor(math.newRandom() * #lines) + 1
    if #lines > 1 and idx == lastBarkIndex[category] then idx = (idx % #lines) + 1 end
    lastBarkIndex[category] = idx
    local line = loc(lines[idx])
    pcall(Osi.DebugText, state().GUID, line)
    barkBusy = true
    Defer(2600, function() barkBusy = false end)
    return true
end

local function classLevel(guid, classUuid)
    if not validCharacter(guid) then return nil end
    local entity = Ext.Entity.Get(guid)
    local classes = entity and entity.Classes and entity.Classes.Classes
    if not classes then return nil end
    local level = 0
    local found = false
    for _,entry in pairs(classes) do
        local entryUuid = entry and entry.ClassUUID and tostring(entry.ClassUUID) or nil
        -- Script Extender versions can stringify a UUID either directly or
        -- through a Guid wrapper.  Match the actual UUID inside either form.
        if entryUuid and string.find(string.lower(entryUuid), string.lower(classUuid), 1, true) then
            level = level + (tonumber(entry.Level) or 0)
            found = true
        end
    end
    return found and level or 0
end

local function removePhase1Build(guid)
    if not validCharacter(guid) then return end
    for _,passive in ipairs(PHASE1_BUILD_PASSIVES) do
        if Osi.HasPassive(guid, passive) == 1 then pcall(Osi.RemovePassive, guid, passive) end
    end
end

local function cleanupBardicD8AfterRespec(guid)
    -- The d8 marker is a native passive because Target_BardicInspiration checks
    -- that exact identifier.  Keep it only if the player's new native build is
    -- still Bard 5-9; otherwise remove our initial marker.
    local bardLevel = classLevel(guid, BARD_CLASS_UUID)
    if bardLevel ~= nil and (bardLevel < 5 or bardLevel >= 10) and Osi.HasPassive(guid, JAM4_BARDIC_D8) == 1 then
        pcall(Osi.RemovePassive, guid, JAM4_BARDIC_D8)
    end
end

local function applyEnemyBuild(guid)
    local s = state()
    -- Never inject class spells/resources into the neutral or recruited character.
    if s.State ~= "EnemyFight" or s.Recruited or not validCharacter(guid) then return false end
    for _,passive in ipairs(PHASE1_BUILD_PASSIVES) do
        if Osi.HasPassive(guid, passive) ~= 1 then pcall(Osi.AddPassive, guid, passive) end
    end
    -- Bard 5+ -> Bardic Inspiration d8.  This exact native marker makes the
    -- normal inspiration action choose the d8 statuses/interrupts.
    if Osi.HasPassive(guid, JAM4_BARDIC_D8) ~= 1 then
        pcall(Osi.AddPassive, guid, JAM4_BARDIC_D8)
    end
    return true
end


local function restoreFullHealth(guid)
    if not validCharacter(guid) then return false end

    -- Some dynamically-created character templates can enter the world in a dead/0 HP
    -- state.  Resurrect first, then explicitly restore to 100% after replication.
    if Osi.IsDead(guid) == 1 or (Osi.GetHitpoints(guid) or 0) <= 0 then
        pcall(Osi.Resurrect, guid)
    end
    pcall(Osi.SetHitpointsPercentage, guid, 100.0, "Guaranteed")

    Defer(250, function()
        if not validCharacter(guid) then return end
        if Osi.IsDead(guid) == 1 or (Osi.GetHitpoints(guid) or 0) <= 0 then
            pcall(Osi.Resurrect, guid)
        end
        pcall(Osi.SetHitpointsPercentage, guid, 100.0, "Guaranteed")
    end)
    return true
end

local function deleteEncounterBody(guid)
    if not validCharacter(guid) then return end
    pcall(Osi.SetHasOsirisDialog, guid, 0)
    pcall(Osi.SetVisible, guid, 0)
    pcall(Osi.SetOnStage, guid, 0)
    Defer(250, function()
        if validCharacter(guid) then pcall(Osi.RequestDelete, guid) end
    end)
end

local function safeRegion(guid)
    if not validCharacter(guid) then return nil end
    local ok, region = pcall(Osi.GetRegion, guid)
    return ok and region or nil
end

local function moveNear(guid, anchor, dx, dz)
    if not validCharacter(guid) or not validCharacter(anchor) then return false end
    local x,y,z = Osi.GetPosition(anchor)
    x, z = x + (dx or 2.0), z + (dz or 1.5)
    local vx,vy,vz = Osi.FindValidPosition(x,y,z,80,anchor,1)
    if vx and vy and vz then x,y,z = vx,vy,vz end
    pcall(Osi.TeleportToPosition, guid, x,y,z, "", 0,0,0,0,1)
    return true
end

local function makeEncounterSafe(guid)
    if not validCharacter(guid) then return end
    pcall(Osi.SetImmortal, guid, 1)
    pcall(Osi.ApplyStatus, guid, "INVULNERABLE_NOT_SHOWN", -1, 1, guid)
    pcall(Osi.SetCanJoinCombat, guid, 0)
    pcall(Osi.SetCanFight, guid, 0)
    pcall(Osi.BlockFlee, guid)
    pcall(Osi.BlockNewCrimeReactions, guid, 1)
    pcall(Osi.SetHasOsirisDialog, guid, 1)
    forceCombatDress(guid)
end

local function makePlayable(guid)
    if not validCharacter(guid) then return end
    pcall(Osi.RemoveStatus, guid, "INVULNERABLE_NOT_SHOWN")
    pcall(Osi.SetImmortal, guid, 0)
    pcall(Osi.SetCanJoinCombat, guid, 1)
    pcall(Osi.SetCanFight, guid, 1)
    pcall(Osi.BlockNewCrimeReactions, guid, 0)
    pcall(Osi.UnblockFlee, guid)
    pcall(Osi.SetHasOsirisDialog, guid, 1)
    forceCombatDress(guid)
end

local function refreshNativeCompanionRegistration(guid, owner)
    if not validCharacter(guid) or not isPlayable(guid) then return false end
    local recruiter = validCharacter(owner) and owner or Player.Host()
    pcall(Osi.RegisterAsCompanion, guid, recruiter)
    pcall(Osi.SetFaction, guid, C.CompanionFaction)
    registerNativePlayerRows(guid)
    registerNativeResurrection(guid)
    pcall(Osi.AttachToPartyGroup, guid, recruiter)
    pcall(Osi.SetBlockDismiss, guid, 0)
    makePlayable(guid)
    return true
end

local function syncCompanionExperience(guid)
    if not validCharacter(guid) or not isPlayable(guid) then return false end
    local entity = Ext.Entity.Get(guid)
    if not entity or not entity.Experience then return false end

    local targetExp = tonumber(entity.Experience.TotalExperience) or 0
    for _,character in pairs(GU.DB.GetPlayers()) do
        if validCharacter(character) and not U.UUID.Equals(character, guid) then
            local partyEntity = Ext.Entity.Get(character)
            local partyExp = partyEntity and partyEntity.Experience and tonumber(partyEntity.Experience.TotalExperience) or nil
            if partyExp and partyExp > targetExp then targetExp = partyExp end
        end
    end

    local currentExp = tonumber(entity.Experience.TotalExperience) or 0
    local missingExp = math.max(0, targetExp - currentExp)
    if missingExp > 0 then
        local ok, err = pcall(Osi.AddExplorationExperience, guid, missingExp)
        if not ok then
            L.Error("Jam4 XP sync: " .. tostring(err))
            return false
        end
    end
    return true
end

local function ensureEnemyLoadout(guid)
    if not validCharacter(guid) then return false end
    forceCombatDress(guid)
    local breast = nil
    local mainHand = nil
    pcall(function() breast = Osi.GetEquippedItem(guid, "Breast") end)
    pcall(function() mainHand = Osi.GetEquippedItem(guid, "Melee Main Weapon") end)
    if (not breast or breast == "") and (not mainHand or mainHand == "") then
        local ok, err = pcall(Osi.CharacterGiveEquipmentSet, guid, JAM4_ENEMY_LOADOUT)
        if not ok then L.Error("Jam4 enemy loadout repair: " .. tostring(err)) end
    end
    forceCombatDress(guid)
    return true
end

local function spawn(player)
    local s = state()
    if validCharacter(s.GUID) then
        moveNear(s.GUID, player, 2.0, 1.5)
        makeEncounterSafe(s.GUID)
        restoreFullHealth(s.GUID)
        queueJam4Voice(s.GUID, 250)
        return s.GUID
    end
    if not validCharacter(player) then return nil, "Aucun joueur valide pour l'apparition de Jam4_." end
    local x,y,z = Osi.GetPosition(player)
    local vx,vy,vz = Osi.FindValidPosition(x+2.0,y,z+1.5,80,player,1)
    if vx and vy and vz then x,y,z = vx,vy,vz else x,z = x+2.0,z+1.5 end
    -- Permanent character (Temporary=0): companion state/corpse can be saved.
    local guid = Osi.CreateAt(JAM4_TEMPLATE, x,y,z, 0,1,"")
    if not validCharacter(guid) then return nil, TA_Text("Failed to create Jam4_ RootTemplate.", "Échec de création du RootTemplate Jam4_.") end
    s.GUID = guid
    s.State = "EncounterActive"
    s.AtCamp = false
    -- This actor was created from the V8.4Q RootTemplate, whose Equipment
    -- field already points to TOT_JAM4_LOADOUT.
    makeEncounterSafe(guid)
    restoreFullHealth(guid)
    queueJam4Voice(guid, 250)
    return guid
end

local function resumeCampReturn(debugMode)
    GameMode.AutoTeleportPending = false
    if debugMode then return end
    if Config.AutoTeleport and Config.AutoTeleport > 0 then
        Defer(1800, function() Player.ReturnToCamp() end)
    end
end

local function ask(player, step, debugMode)
    local q=QUESTIONS[step]
    if not q then return end
    local message, a, b = loc(q.message), loc(q.a), loc(q.b)
    quizSessions[player] = {kind="quiz", step=step, message=message, a=a, b=b, debugMode=debugMode}
    local s=state(); s.QuizStep=step; s.QuizPlayer=player; s.State="EncounterActive"
    Osi.OpenMessageBoxChoice(player, message, a, b)
end

local function configureCampGuest(guid)
    if not validCharacter(guid) then return false end
    -- Recruitment is paused: Jam4_ remains a normal camp NPC, never a player/companion.
    removeCritFailWatchers()
    unregisterNativePlayerRows(guid)
    unregisterNativeRosterRows(guid)
    pcall(Osi.MakeNPC, guid)
    pcall(Osi.UnregisterAsCompanion, guid)
    pcall(Osi.SetCanFight, guid, 0)
    pcall(Osi.SetCanJoinCombat, guid, 0)
    pcall(Osi.BlockFlee, guid)
    pcall(Osi.BlockNewCrimeReactions, guid, 1)
    pcall(Osi.SetHasOsirisDialog, guid, 1)
    pcall(Osi.SetImmortal, guid, 1)
    if Osi.HasAppliedStatus(guid, "INVULNERABLE_NOT_SHOWN") ~= 1 then
        pcall(Osi.ApplyStatus, guid, "INVULNERABLE_NOT_SHOWN", -1, 1, guid)
    end
    forceCombatDress(guid)
    restoreFullHealth(guid)
    queueJam4Voice(guid, 250)
    return true
end

local function completeSuccessAtCamp(player, debugMode)
    local s=state(); local guid=s.GUID
    if not validCharacter(guid) then return false, TA_Text("Jam4_ is no longer present.", "Jam4_ n'est plus présent.") end
    s.QuizPassed=true
    s.RecruitPending=false
    s.Recruited=false
    s.Failed=false
    s.EnemyPending=false
    s.EnemyInjected=false
    s.EnemySpawning=false
    s.NativePartyInGroup=false
    s.State="CampGuest"
    s.AtCamp=true
    s.QuizStep=0
    s.QuizPlayer=nil
    quizSessions[player]=nil
    removePhase1Build(guid)
    cleanupBardicD8AfterRespec(guid)
    configureCampGuest(guid)
    Osi.OpenMessageBox(player, loc(H.Success))
    resumeCampReturn(debugMode)
    Defer(1800, function() Jam4Companion.EnsureCampPosition() end)
    return true, TA_Text("Jam4_ will remain at camp.", "Jam4_ restera au camp.")
end

local function recruit(player, debugMode)
    if not RECRUITMENT_ENABLED then return completeSuccessAtCamp(player, debugMode) end
    local s=state(); local guid=s.GUID
    if not validCharacter(guid) then return false, TA_Text("Jam4_ is no longer present.", "Jam4_ n'est plus présent.") end
    if s.RecruitPending then return false, TA_Text("Recruitment in progress.", "Recrutement en cours.") end
    s.QuizPassed=true; s.Recruiter=player; s.RecruitPending=true
    s.Recruited=false; s.State="RecruitPending"; s.AtCamp=false
    s.QuizStep=0; s.QuizPlayer=nil; quizSessions[player]=nil
    removePhase1Build(guid)
    cleanupBardicD8AfterRespec(guid)
    local function attempt(number)
        if state()~=s or s.GUID~=guid or not validCharacter(guid) or not s.RecruitPending then return end
        nativePartyAdd(guid,player)
        Defer(350,function()
            if state()~=s or s.GUID~=guid or not validCharacter(guid) or not s.RecruitPending then return end
            if not isPlayable(guid) then
                if number<3 then attempt(number+1);return end
                s.RecruitPending=false; s.Recruited=false; s.State="RecruitFailed"
                s.NativePartyInGroup=false
                makeEncounterSafe(guid)
                Osi.OpenMessageBox(player, TA_Text("Jam4_ could not join the party. Talk to him again to retry; the successful quiz is preserved.", "Jam4_ n'a pas pu rejoindre le groupe. Reparlez-lui pour réessayer ; le quiz réussi est conservé."))
                L.Error("Jam4: not player-controlled after three conversion attempts")
                resumeCampReturn(debugMode)
                return
            end
            s.RecruitPending=false; s.Recruited=true; s.State="Recruited"
            s.Failed=false; s.EnemyPending=false; s.NativePartyInGroup=true
            -- One-shot native adventure armour-set selection after conversion.
            forceCombatDress(guid)
            Defer(500,function()
                if state()==s and s.GUID==guid and validCharacter(guid) and s.Recruited then
                    forceCombatDress(guid)
                end
            end)
            -- Voice 5 is synchronized after MakePlayer.
            registerNativeResurrection(guid)
            queueJam4Voice(guid, 700)
            s.RecruitmentVerifiedV84V=true
            registerNativePlayerRows(guid)
            pcall(Osi.SetFaction,guid,C.CompanionFaction)
            pcall(Osi.AttachToPartyGroup,guid,player)
            makePlayable(guid)
            -- Companion progression is deliberately manual: only synchronize XP.
            -- Never call RequestInitialLevel/RequestAutoLevel for recruited Jam4_.
            Defer(700, function()
                if validCharacter(guid) and isPlayable(guid) then syncCompanionExperience(guid) end
            end)
            if Osi.HasAppliedStatus(guid,JAM4_GOD_STATUS)~=1 then
                pcall(Osi.ApplyStatus,guid,JAM4_GOD_STATUS,-1,1,guid)
            end
            pcall(Osi.SetBlockDismiss,guid,0)
            installCritFailWatchers()
            Osi.OpenMessageBox(player,loc(H.Success))
            resumeCampReturn(debugMode)
        end)
    end
    attempt(1)
    return true, TA_Text("Jam4_ recruitment in progress.", "Recrutement de Jam4_ en cours.")
end

local function fail(player, debugMode)
    local s=state()
    s.State="Failed"; s.Failed=true; s.EnemyPending=true; s.EnemyInjected=false; s.EnemySpawning=false
    s.QuizStep=0; s.QuizPlayer=nil
    quizSessions[player]=nil
    Osi.OpenMessageBox(player, loc(H.Failure))

    -- The neutral quiz actor is disposable.  Deleting it here avoids carrying a
    -- hidden actor across region/camp transitions; the punishment encounter creates
    -- a fresh hostile Jam4_ beside the first enemy of the next combat.
    local oldGuid=s.GUID
    s.GUID=nil
    deleteEncounterBody(oldGuid)
    resumeCampReturn(debugMode)
end

local function openIntro(player, debugMode)
    if interactionBusy[player] then return end
    interactionBusy[player]=true
    local message, a, b = loc(H.Intro), loc(H.IntroYes), loc(H.IntroNo)
    quizSessions[player]={kind="intro",message=message,a=a,b=b,debugMode=debugMode}
    Osi.OpenMessageBoxChoice(player, message, a, b)
    Defer(750,function() interactionBusy[player]=nil end)
end

function Jam4Companion.StartEncounter(player, debugMode)
    local s=state()
    if s.Recruited or s.Failed or (s.State ~= "NotMet" and s.State ~= "EncounterReady" and s.State ~= "EncounterActive") then
        return false, loc(H.Already)
    end
    local guid,err=spawn(player)
    if not guid then return false,err end
    s.State="EncounterActive"
    GameMode.AutoTeleportPending = true -- blocks StoryBypass from returning to camp mid-question.
    Defer(500,function() if validCharacter(player) then openIntro(player, debugMode == true) end end)
    return true, TA_Text("Jam4_ Easter Egg started.", "Easter Egg Jam4_ lancé.")
end

function Jam4Companion.TryPostCombatEncounter(scenario)
    local s=state()
    if (PersistentVars.RogueScore or 0) < MIN_RG then return false end
    if s.Recruited or s.Failed or s.State ~= "NotMet" then return false end
    s.EligibleCombats=(s.EligibleCombats or 0)+1
    -- Same RNG style as makeItCow()/makeItWilloughby(), with a dedicated 3% rate.
    if math.newRandom() >= ENCOUNTER_CHANCE then return false end
    s.State="EncounterReady"
    local player=Player.Host()
    local ok,msg=Jam4Companion.StartEncounter(player,false)
    if not ok then
        L.Error("Jam4 Easter Egg failed to start",msg)
        s.State="NotMet"
        return false
    end
    return true
end

local function campAnchor()
    local host=Player.Host()
    if not validCharacter(host) then return nil end
    local region=safeRegion(host)
    if validCharacter(WITHERS) and safeRegion(WITHERS)==region then return WITHERS end
    return host
end

function Jam4Companion.EnsureCampPosition()
    local s=state()
    local shouldBeAtCamp = (s.State == "CampGuest") or (s.Recruited and s.AtCamp)
    if not shouldBeAtCamp or not validCharacter(s.GUID) or not Player.InCamp() then return end
    local anchor=campAnchor()
    if anchor then
        moveNear(s.GUID,anchor,4.5,2.5)
        if s.State == "CampGuest" then
            forceCombatDress(s.GUID)
            queueJam4Voice(s.GUID, 250)
        end
    end
end

local function spawnPunishmentEnemy(anchorGuid)
    local s=state()
    if not s.EnemyPending or s.EnemySpawning then return false end
    if not validCharacter(anchorGuid) then return false end
    s.EnemySpawning=true

    local x,y,z=Osi.GetPosition(anchorGuid)
    local vx,vy,vz=Osi.FindValidPosition(x+2.5,y,z+1.0,80,anchorGuid,1)
    if vx and vy and vz then x,y,z=vx,vy,vz end
    local guid=Osi.CreateAt(JAM4_ENEMY_TEMPLATE,x,y,z,0,1,"")
    if not validCharacter(guid) then
        s.EnemySpawning=false
        L.Error("Jam4 punishment spawn failed")
        return false
    end

    -- Punishment Jam4_ is intentionally a fixed level-12 encounter,
    -- regardless of the party level.
    pcall(Osi.SetLevel, guid, 12)

    s.GUID=guid
    s.State="EnemyFight"
    s.EnemyPending=false
    s.EnemyInjected=true
    s.EnemySpawning=false

    pcall(Osi.SetVisible,guid,1)
    pcall(Osi.SetOnStage,guid,1)
    pcall(Osi.RemoveStatus,guid,"INVULNERABLE_NOT_SHOWN")
    pcall(Osi.SetImmortal,guid,0)
    pcall(Osi.SetCanJoinCombat,guid,1)
    pcall(Osi.SetCanFight,guid,1)
    pcall(Osi.SetHasOsirisDialog,guid,0)
    restoreFullHealth(guid)
    pcall(Osi.SetFaction,guid,C.EnemyFaction)
    if Osi.HasAppliedStatus(guid,JAM4_GOD_STATUS) ~= 1 then
        pcall(Osi.ApplyStatus,guid,JAM4_GOD_STATUS,-1,1,guid)
    end
    applyEnemyBuild(guid)
    queueJam4Voice(guid, 250)
    installCritFailWatchers()

    -- Hostile Jam4_ has a dedicated equipment set. The RootTemplate equips it
    -- natively; this delayed check only repairs a genuinely empty fresh spawn.
    Defer(250, function() ensureEnemyLoadout(guid) end)

    Defer(300,function()
        if not validCharacter(guid) then return end
        pcall(Osi.SetLevel, guid, 12)
        restoreFullHealth(guid)
        pcall(Osi.SetFaction,guid,C.EnemyFaction)
        applyEnemyBuild(guid)
        ensureEnemyLoadout(guid)
        local scenario=Scenario.Current()
        if not scenario then return end
        local tracked=Enemy.CreateTemporary(guid)
        if tracked then
            tracked.Name="Jam4_"
            tracked.Tier=C.EnemyTier[1] -- punishment add-on should not create a large bonus-loot spike.
            table.insert(scenario.SpawnedEnemies,tracked)
            Scenario.CombatSpawned(tracked)
            Player.Notify(TA_Text("Jam4_ has joined the enemy side.", "Jam4_ a rejoint le camp ennemi."))
        else
            Enemy.Combat(guid,true)
        end
    end)
    return true
end

function Jam4Companion.DebugForce(player)
    local s=state()
    if s.State ~= "NotMet" then return false,"RESET JAM4_ avant de relancer la rencontre." end
    s.State="EncounterReady"
    return Jam4Companion.StartEncounter(player,true)
end

function Jam4Companion.DebugReset()
    local s=state(); local guid=s.GUID
    removeCritFailWatchers()
    if validCharacter(guid) then
        unregisterNativePlayerRows(guid)
        unregisterNativeRosterRows(guid)
        pcall(Osi.MakeNPC,guid)
        pcall(Osi.UnregisterAsCompanion,guid)
        pcall(Osi.SetHasOsirisDialog,guid,0)
        pcall(Osi.SetVisible,guid,0)
        Defer(250,function() if validCharacter(guid) then pcall(Osi.RequestDelete,guid) end end)
    end
    PersistentVars.Jam4=defaultState(); quizSessions={}; interactionBusy={}
    GameMode.AutoTeleportPending=false
    return true,TA_Text("Jam4_ reset.", "Jam4_ réinitialisé.")
end

function Jam4Companion.DebugCampToggle(player)
    return false,"Recrutement de Jam4_ en pause : il reste PNJ au camp."
end

function Jam4Companion.DebugRespec()
    return false,TA_Text("Jam4_ respec is disabled while recruitment is paused.", "Respec de Jam4_ désactivé tant que son recrutement est en pause.")
end

Ext.Osiris.RegisterListener("RespecCompleted",1,"after",function(character)
    local s = state()
    if not s.Recruited or not validCharacter(s.GUID) or not U.UUID.Equals(character,s.GUID) then return end
    -- From this point on the native level-up system owns Jam4_.  Never reapply
    -- the initial package on load/camp transitions after a successful respec.
    removePhase1Build(s.GUID)
    s.BuildOverriddenByRespec = true
    cleanupBardicD8AfterRespec(s.GUID)
    refreshNativeCompanionRegistration(s.GUID, validCharacter(s.Recruiter) and s.Recruiter or Player.Host())
    queueJam4Voice(s.GUID, 250)
    Player.Notify(TA_Text("Jam4_: native progression active after respec.", "Jam4_ : progression native active après le respec."))
end)


Ext.Osiris.RegisterListener("MessageBoxChoiceClosed",3,"after",function(player,message,resultChoice)
    local session=quizSessions[player]
    if not session or session.message ~= message then return end
    quizSessions[player]=nil
    if session.kind=="companion" then
        if resultChoice==session.a then
            local ok,msg=Jam4Companion.DebugCampToggle(player)
            Osi.OpenMessageBox(player,msg)
        end
        return
    end
    if session.kind=="intro" then
        if resultChoice==session.a then ask(player,1,session.debugMode) else fail(player,session.debugMode) end
        return
    end
    local q=QUESTIONS[session.step]
    if not q then return end
    local expected=(q.correct=="A") and session.a or session.b
    if resultChoice~=expected then fail(player,session.debugMode); return end
    if session.step>=#QUESTIONS then completeSuccessAtCamp(player,session.debugMode) else ask(player,session.step+1,session.debugMode) end
end)

-- Retry a passed quiz without replaying it; camp interaction remains available.
Ext.Osiris.RegisterListener("DialogStartRequested",2,"after",function(target,player)
    local s=state()
    if not validCharacter(s.GUID) or not U.UUID.Equals(target,s.GUID) or s.Failed then return end
    if s.State == "CampGuest" then
        Osi.OpenMessageBox(player, loc(H.CampGuest))
        return
    end
    if s.RecruitPending then return end
    if s.QuizPassed then
        completeSuccessAtCamp(player,true)
    else
        openIntro(player,true)
    end
end)

Ext.Osiris.RegisterListener("EnteredLevel",3,"after",function(object,rootTemplate,level)
    local host=Player.Host()
    if host and U.UUID.Equals(object,host) then Defer(1200,Jam4Companion.EnsureCampPosition) end
    local s=state()
    if s.Recruited and not s.AtCamp and validCharacter(s.GUID) and U.UUID.Equals(object,s.GUID) then
        Defer(800,function()
            if validCharacter(s.GUID) and isPlayable(s.GUID) then
                refreshNativeCompanionRegistration(s.GUID, validCharacter(s.Recruiter) and s.Recruiter or host)
            end
        end)
    end
end)
Ext.Osiris.RegisterListener("LongRestFinished",0,"after",function()
    Defer(500,function()
        Jam4Companion.EnsureCampPosition()
        local s=state();if validCharacter(s.GUID) and not s.AtCamp then forceCombatDress(s.GUID) end
    end)
end)
GameState.OnLoad(function()
    Defer(1200,function()
        local s=state()
        if not validCharacter(s.GUID) then return end
        -- Z13 migration: recruitment is paused. Existing recruited Jam4_ instances
        -- are converted back into the persistent camp-guest version.
        if s.Recruited then
            s.Recruited=false
            s.RecruitPending=false
            s.QuizPassed=true
            s.State="CampGuest"
            s.AtCamp=true
            s.NativePartyInGroup=false
            configureCampGuest(s.GUID)
        end
        if s.State == "CampGuest" then
            configureCampGuest(s.GUID)
            Jam4Companion.EnsureCampPosition()
            return
        end
        if s.Recruited and not s.AtCamp and not isPlayable(s.GUID) then
            -- V8.4U could save a false success before conversion; repair that state.
            s.QuizPassed=true; s.RecruitPending=false
            recruit(validCharacter(s.Recruiter) and s.Recruiter or Player.Host(),true)
            return
        end
        if s.RecruitPending or (s.QuizPassed and not s.Recruited and not s.Failed) then
            s.RecruitPending=false
            s.Recruited=false
            s.State="CampGuest"
            s.AtCamp=true
            configureCampGuest(s.GUID)
            Jam4Companion.EnsureCampPosition()
            return
        end
        if s.Recruited then
            removePhase1Build(s.GUID)
            cleanupBardicD8AfterRespec(s.GUID)
            if not s.AtCamp then
                nativePartyAdd(s.GUID,Player.Host())
                if isPlayable(s.GUID) then
                    refreshNativeCompanionRegistration(s.GUID, validCharacter(s.Recruiter) and s.Recruiter or Player.Host())
                else
                    makePlayable(s.GUID)
                end
                installCritFailWatchers()
                Defer(700, function()
                    if validCharacter(s.GUID) and isPlayable(s.GUID) then syncCompanionExperience(s.GUID) end
                end)
            else
                pcall(Osi.RegisterAsCompanion,s.GUID,Player.Host())
                unregisterNativePlayerRows(s.GUID)
                s.NativePartyInGroup=false
                pcall(Osi.SetHasOsirisDialog,s.GUID,1)
                removeCritFailWatchers()
            end
            registerNativeResurrection(s.GUID)
        end
        queueJam4Voice(s.GUID, 300)
        Jam4Companion.EnsureCampPosition()
    end)
end,true)

-- ---------------------------------------------------------------------------
-- V8.4R - Jam4_ overhead combat barks (10% each eligible event).
-- DebugText is the native call that displays short text directly above an entity.
-- Variants never repeat twice in a row within the same category.
-- ---------------------------------------------------------------------------
Ext.Osiris.RegisterListener("StatusApplied",4,"after",function(object,status,causee,storyActionID)
    if status ~= CRITFAIL_SIGNAL_STATUS then return end
    pcall(Osi.RemoveStatus, object, CRITFAIL_SIGNAL_STATUS)
    local s = state()
    if not jam4CanBark() or not validCharacter(object) or (s.GUID and U.UUID.Equals(object,s.GUID)) then return end
    maybeBark("CritFail")
end)

Ext.Osiris.RegisterListener("CriticalHitBy",4,"after",function(defender,attackerOwner,attacker,storyActionID)
    local s = state()
    if not jam4CanBark() or not s.GUID then return end
    local jamCrit = (attacker and U.UUID.Equals(attacker,s.GUID)) or (attackerOwner and U.UUID.Equals(attackerOwner,s.GUID))
    if jamCrit then maybeBark("CritHit") end
end)

-- Keep Jam4_ in the same native resurrection database used by resurrectable
-- companions. Death must never turn him into a cleanup-only dynamic NPC corpse.
Ext.Osiris.RegisterListener("Died",1,"after",function(character)
    local s = state()
    if s.Recruited and s.GUID and U.UUID.Equals(character,s.GUID) and validCharacter(character) then
        registerNativeResurrection(character)
    end
end)

Ext.Osiris.RegisterListener("Resurrected",1,"after",function(character)
    local s = state()
    if not s.Recruited or not s.GUID or not U.UUID.Equals(character,s.GUID) or not validCharacter(character) then return end
    registerNativeResurrection(character)
    pcall(Osi.RegisterAsCompanion, character, validCharacter(s.Recruiter) and s.Recruiter or Player.Host())
    if not s.AtCamp and isPlayable(character) then
        refreshNativeCompanionRegistration(character, validCharacter(s.Recruiter) and s.Recruiter or Player.Host())
        s.NativePartyInGroup = true
    end
    queueJam4Voice(character, 250)
end)

Ext.Osiris.RegisterListener("Died",1,"after",function(character)
    local s = state()
    if not jam4CanBark() or not validCharacter(character) or not s.GUID or U.UUID.Equals(character,s.GUID) then return end
    local ok, ally = pcall(Osi.IsAlly, s.GUID, character)
    if ok and ally == 1 then maybeBark("AllyDeath") end
end)

Ext.Osiris.RegisterListener("CharacterJoinedParty",1,"after",function(character)
    local s = state()
    if s.Recruited or s.State == "EnemyFight" then
        if validCharacter(character) and (not s.GUID or not U.UUID.Equals(character,s.GUID))
            and Osi.HasPassive(character, CRITFAIL_WATCH_PASSIVE) ~= 1 then
            pcall(Osi.AddPassive, character, CRITFAIL_WATCH_PASSIVE)
        end
    end
end)

Ext.Osiris.RegisterListener("CharacterLeftParty",1,"after",function(character)
    local s = state()
    if s.Recruited and validCharacter(s.GUID) and U.UUID.Equals(character,s.GUID) then
        s.NativePartyInGroup = false
    end
end)

Ext.Osiris.RegisterListener("CharacterMadePlayer",1,"after",function(character)
    local s = state()
    if s.Recruited and validCharacter(s.GUID) and U.UUID.Equals(character,s.GUID) and not s.AtCamp then
        refreshNativeCompanionRegistration(s.GUID, validCharacter(s.Recruiter) and s.Recruiter or Player.Host())
        queueJam4Voice(s.GUID, 250)
        installCritFailWatchers()
    end
end)

-- Vanilla Withers respec sets the object flag GLO_Respec_Start on the character.
-- RequestRespec only prepares a respec and exposes a level-up button; StartRespec
-- is the engine call that actually opens the respec character-creation screen.
Ext.Osiris.RegisterListener("FlagSet",3,"after",function(flag, speaker, dialogInstance)
    if type(flag) ~= "string" or not flag:find("GLO_Respec_Start", 1, true) then return end
    local s = state()
    if not s.Recruited or not validCharacter(s.GUID) or not U.UUID.Equals(speaker, s.GUID) then return end
    if not isPlayable(s.GUID) then return end
    refreshNativeCompanionRegistration(s.GUID, validCharacter(s.Recruiter) and s.Recruiter or Player.Host())
    -- Mirror the vanilla PROC_FlagReactionAfterDialog flow, but explicitly support
    -- our dynamically-created companion.  Clearing the flag allows future respecs.
    pcall(Osi.ClearFlag, flag, speaker, dialogInstance)
    pcall(Osi.MakePlayerActive, speaker)
    Defer(100, function()
        if validCharacter(speaker) and isPlayable(speaker) then
            local ok, err = pcall(Osi.StartRespec, speaker)
            if not ok then L.Error("Jam4 StartRespec from Withers: " .. tostring(err)) end
        end
    end)
end)

-- Failed quiz punishment: inject Jam4_ once beside the first real enemy spawned in
-- the next scenario.  This reuses the normal scenario combat tracking so the fight
-- cannot finish while Jam4_ is still alive.
Event.On("ScenarioEnemySpawned",function(scenario,enemy)
    local s=state()
    if not s.EnemyPending or s.EnemyInjected or s.EnemySpawning then return end
    if not enemy or not validCharacter(enemy.GUID) then return end
    spawnPunishmentEnemy(enemy.GUID)
end)

Event.On("ScenarioEnemyKilled",function(scenario,enemy)
    local s=state()
    if s.State ~= "EnemyFight" or not enemy or not s.GUID then return end
    if U.UUID.Equals(enemy.GUID,s.GUID) then
        s.State="Defeated" -- Easter egg permanently complete after the one punishment fight.
        s.EnemyPending=false
        s.EnemyInjected=false
        s.EnemySpawning=false
        removeCritFailWatchers()
    end
end)

Net.On("Jam4DebugForce",function(event)
    if not event:IsHost() then Net.Respond(event,{false,TA_Text("Jam4_ command restricted to the host.", "Commande Jam4_ réservée à l'hôte.")}); return end
    local ok,msg=Jam4Companion.DebugForce(event:Character()); Net.Respond(event,{ok,msg})
end)
Net.On("Jam4DebugReset",function(event)
    if not event:IsHost() then Net.Respond(event,{false,TA_Text("Jam4_ command restricted to the host.", "Commande Jam4_ réservée à l'hôte.")}); return end
    local ok,msg=Jam4Companion.DebugReset(); Net.Respond(event,{ok,msg})
end)
Net.On("Jam4DebugCampToggle",function(event)
    if not event:IsHost() then Net.Respond(event,{false,TA_Text("Jam4_ command restricted to the host.", "Commande Jam4_ réservée à l'hôte.")}); return end
    local ok,msg=Jam4Companion.DebugCampToggle(event:Character()); Net.Respond(event,{ok,msg})
end)
Net.On("Jam4DebugRespec",function(event)
    if not event:IsHost() then Net.Respond(event,{false,TA_Text("Jam4_ command restricted to the host.", "Commande Jam4_ réservée à l'hôte.")}); return end
    local ok,msg=Jam4Companion.DebugRespec(); Net.Respond(event,{ok,msg})
end)
