Extras = {}

local SECTION_COLORS = {
    Troubleshoot = { 0.40, 0.70, 0.90, 1.00 },
    Player = { 0.92, 0.66, 0.26, 1.00 },
    Experimental = { 0.68, 0.46, 0.84, 1.00 },
    Debug = { 0.88, 0.40, 0.26, 1.00 },
    Milestone = { 0.82, 0.58, 0.24, 1.00 },
    Equipment = { 0.42, 0.72, 0.64, 1.00 },
    RegionalProgression = { 0.74, 0.48, 0.28, 1.00 },
}

local function section(root, label, color)
    local h = root:AddSeparatorText(label)
    h:SetColor("Text", color or { 0.82, 0.62, 0.28, 1.00 })
    return h
end

function Extras.Main(tab)
    ---@type ExtuiTabItem
    local root = tab:AddTabItem(__("Extras")):AddChildWindow(""):AddGroup("")
    root.PositionOffset = { 8, 8 }

    -- ================================================================
    -- DEPANNAGE
    -- ================================================================
    section(root, TA_Text("Troubleshooting", "Dépannage"), SECTION_COLORS.Troubleshoot)
    local help = root:AddText(TA_Text("Emergency tools to use only if your run becomes stuck.", "Outils de secours à utiliser uniquement en cas de blocage."))
    help:SetColor("Text", { 0.72, 0.78, 0.84, 1.00 })
    root:AddDummy(1, 4)

    Extras.Button(root, __("End Long Rest"), __("Use when stuck in night time."), function(btn)
        Net.Request("CancelLongRest"):After(DisplayResponse)
    end)

    Extras.Button(root, __("Cancel Dialog"), __("End the current dialog."), function(btn)
        Net.Request("CancelDialog"):After(DisplayResponse)
    end)

    Extras.Button(root, __("Fix Factions"), __("Resets the faction all of current party members, in case scripting has caused someone to stop being considered an ally. Cannot be used during combat."), function(btn)
        Net.Request("FixFactions"):After(DisplayResponse)
    end)

    Extras.Button(root, __("Fix Long Rest"), __("Reruns the scripting that applies each time you press the Camp button, fixing Long Rest. Cannot be used during combat."), function(btn)
        Net.Request("FixLongRest"):After(DisplayResponse)
    end)

    root:AddDummy(1, 10)

    -- ================================================================
    -- REGIONAL PROGRESSION - LOADING OPTIMISATION
    -- ================================================================
    section(root, TA_Text("Regional Progression - Optimization", "Progression régionale - Optimisation"), SECTION_COLORS.RegionalProgression)
    local regionalInfo = root:AddText(TA_Text(
        "Enabled by default. Reduces loading times by keeping encounters in the same major level during a RogueScore range. " ..
        "Start: WLD 0-100, SCL 101-200, BGO 201-299, CTY 300-399, WLD 400-499. From RG500 onward, " ..
        "rotation continues in 200-RG blocks up to RG1900+, then remains permanently in WLD.",
        "Activée par défaut. Réduit les temps de chargement en gardant les combats dans un même gros niveau " ..
        "pendant une tranche de RogueScore. Début : WLD 0-100, SCL 101-200, BGO 201-299, CTY 300-399, " ..
        "WLD 400-499. À partir de RG500, la rotation continue par blocs de 200 RG jusqu'à RG1900+, " ..
        "puis reste définitivement sur WLD."
    ))
    regionalInfo:SetColor("Text", { 0.78, 0.72, 0.64, 1.00 })

    local regionalEnabled = State and State.RegionalProgressionEnabled ~= false
    local regionalBtn = root:AddButton("")
    regionalBtn.IDContext = U.RandomId()

    local function refreshRegionalProgression(state)
        regionalEnabled = state and state.RegionalProgressionEnabled ~= false
        regionalBtn.Label = regionalEnabled
            and TA_Text("  Regional progression: ENABLED  ", "  Progression régionale : ACTIVÉE  ")
            or TA_Text("  Regional progression: DISABLED  ", "  Progression régionale : DÉSACTIVÉE  ")
    end
    Event.On("StateChange", refreshRegionalProgression):Exec(State)

    regionalBtn.OnClick = function()
        Net.Request("SetRegionalProgressionEnabled", { Value = not regionalEnabled }):After(DisplayResponse)
    end

    local regionalHelp = root:AddText(TA_Text(
        "Available camps and maps remain locked to the region corresponding to your RogueScore. " ..
        "WLD/SCL/BGO/CTY are separated to avoid unnecessary major-level transitions. " ..
        "Disable this option to compare with the historical behavior.",
        "Le camp et les cartes disponibles restent verrouillés dans la région correspondant à votre RogueScore. " ..
        "WLD/SCL/BGO/CTY sont séparés pour éviter les changements de gros niveau inutiles. " ..
        "Désactivez cette option pour comparer avec le comportement historique."
    ))
    regionalHelp:SetColor("Text", { 0.68, 0.72, 0.76, 1.00 })

    -- ================================================================
    -- SUMMON CONTROL - EXPERIMENTAL PLAYER FEATURE
    -- ================================================================
    section(root, TA_Text("Summon Control - Experimental", "Contrôle des invocations - Expérimental"), SECTION_COLORS.Experimental)
    local summonInfo = root:AddText(TA_Text(
        "Switches summons between automatic and manual control. This feature is still experimental: some summon types may not behave as expected.",
        "Permet de basculer les invocations entre contrôle automatique et manuel. Fonction encore expérimentale : certains types d'invocations peuvent ne pas réagir comme prévu."
    ))
    summonInfo:SetColor("Text", { 0.74, 0.68, 0.80, 1.00 })

    local auto = (State.SummonsAutomatic ~= false)
    local summonBtn = root:AddButton("")
    summonBtn.IDContext = U.RandomId()
    local function refreshSummonLabel(state)
        auto = state.SummonsAutomatic ~= false
        summonBtn.Label = auto and Localization.Get("h72a00000000000000000000000000107") or Localization.Get("h72a00000000000000000000000000108")
    end
    Event.On("StateChange", refreshSummonLabel):Exec(State)
    summonBtn.OnClick = function()
        Net.Request("SetSummonsAutomatic", {Value=not auto}):After(DisplayResponse)
    end

    root:AddDummy(1, 10)

    -- ================================================================
    -- RECRUITMENT - EXPERIMENTAL
    -- ================================================================
    section(root, __("Recruit Origins (Experimental)"), SECTION_COLORS.Experimental)
    for name, char in pairs(C.OriginCharacters) do
        local b = Extras.Button(root, name, "", function(btn)
            Net.Request("RecruitOrigin", name):After(DisplayResponse)
        end)
        b.SameLine = true
    end

    local recruitWarn = root:AddText(
        __("Needs to be run multiple times in some cases. May not work in all cases.") .. "\n" ..
        __("Level will be reset. Inventory will be emptied.") .. "\n" ..
        __("Alfira is barely functional. Larian did not fully implement her as a companion, just a set piece for one camp night. Use at your own risk.")
    )
    recruitWarn:SetColor("Text", { 0.72, 0.66, 0.76, 1.00 })

    root:AddDummy(1, 12)

    -- ================================================================
    -- DEBUG / CHEAT / PROGRESSION
    -- ================================================================
    section(root, TA_Text("Test Tools / Debug / Cheat", "Outils de test / Debug / Cheat"), SECTION_COLORS.Debug)
    local debugInfo = root:AddText(TA_Text("Tools intended for testing. They can directly modify run progression.", "Outils destinés aux tests. Ils peuvent modifier directement la progression de la run."))
    debugInfo:SetColor("Text", { 0.82, 0.62, 0.54, 1.00 })

    root:AddInputInt("RogueScore", State.RogueScore or 0).OnChange = Debounce(1000, function(input)
        Net.Request("DebugCommand", {Op="SetRogueScore", Value=input.Value[1]}):After(function(event)
            if event.Payload and event.Payload[1] then Net.Send("SyncState")
            else DisplayResponse(event) end
        end)
    end)

    root:AddInputInt(Localization.Get("h72a00000000000000000000000000031"), State.Currency or 0).OnChange = Debounce(1000, function(input)
        Net.Request("DebugCommand", {Op="SetCurrency", Value=input.Value[1]}):After(function(event)
            if event.Payload and event.Payload[1] then Net.Send("SyncState")
            else DisplayResponse(event) end
        end)
    end)

    root:AddInputInt(Localization.Get("h71a00000000000000000000000000040"), State.ConquestTokens or State.GoblinTokens or 0).OnChange = Debounce(1000, function(input)
        Net.Request("DebugCommand", {Op="SetConquestTokens", Value=input.Value[1]}):After(function(event)
            if event.Payload and event.Payload[1] then Net.Send("SyncState")
            else DisplayResponse(event) end
        end)
    end)

    local input = root:AddInputInt(U.RandomId(), 0)
    input.Label = ""
    local btn = root:AddButton(TA_Text("Add XP", "Ajouter de l'EXP"))
    btn.SameLine = true
    btn.OnClick = function(btn)
        Net.Request("DebugCommand", {Op="GiveExperience", Value=input.Value[1]}):After(function(event)
            if event.Payload and event.Payload[1] then Net.Send("SyncState")
            else DisplayResponse(event) end
        end)
    end

    root:AddDummy(1, 6)
    local contractsLabel = root:AddText(TA_Text("Contracts Debug", "Debug Contrats"))
    contractsLabel:SetColor("Text", SECTION_COLORS.Debug)
    Extras.Button(root, "+1 Kill", nil, function() Net.Request("DebugContract", {Kind="Kills",Amount=1}):After(DisplayResponse) end)
    Extras.Button(root, "+10 Kills", nil, function() Net.Request("DebugContract", {Kind="Kills",Amount=10}):After(DisplayResponse) end)
    Extras.Button(root, "+1 Combat", nil, function() Net.Request("DebugContract", {Kind="Combats",Amount=1}):After(DisplayResponse) end)
    Extras.Button(root, Localization.Get("h72a00000000000000000000000000103"), nil, function() Net.Request("DebugResetContracts"):After(DisplayResponse) end)

    Components.Conditional(root:AddGroup(U.RandomId()), function(c)
        local debugGroup = c.Root
        local cleanTitle = debugGroup:AddText(TA_Text("World Debug", "Debug monde"))
        cleanTitle:SetColor("Text", SECTION_COLORS.Debug)
        return {
            Extras.Button(debugGroup, "Clean Ground", "", function(btn)
                Net.Request("ClearSurfaces"):After(DisplayResponse)
            end),
            Extras.Button(debugGroup, "Remove all Entities", "", function(btn)
                Net.Request("RemoveAllEntities"):After(DisplayResponse)
            end),
        }
    end, "ToggleDebug")

    root:AddDummy(1, 12)

    -- ================================================================
    -- MILESTONE TESTS
    -- ================================================================
    section(root, TA_Text("Milestone Tests", "Tests des paliers"), SECTION_COLORS.Milestone)
    for _, rg in ipairs({50, 75, 100, 150, 200}) do
        local b = Extras.Button(root, string.format("RG%d", rg), nil, function()
            Net.Request("DebugStartMilestone", {RG=rg}):After(DisplayResponse)
        end)
        b.SameLine = rg ~= 50
    end

    Extras.Button(
        root,
        TA_Text("MARK RG50 - RG200 COMPLETE - DEBUG", "VALIDER RG50 - RG200 - DEBUG"),
        TA_Text("Marks all five milestone scenarios as completed without granting their rewards. Allows direct testing of high-RogueScore encounters.", "Marque les cinq scénarios de palier comme terminés sans donner leurs récompenses. Permet de tester directement les combats haut RogueScore."),
        function() Net.Request("DebugCompleteMilestones"):After(DisplayResponse) end
    )

    root:AddDummy(1, 12)

    -- ================================================================
    -- EQUIPMENT TESTS
    -- ================================================================
    section(root, TA_Text("Equipment Tests", "Tests équipements"), SECTION_COLORS.Equipment)
    Extras.Button(root, TA_Text("SPAWN ALL MODDED EQUIPMENT - TEST", "SPAWN TOUS LES ÉQUIPEMENTS MODDÉS - TEST"), TA_Text("Adds all Trials Ascension equipment currently created or modified in this build in one click: milestone rewards, sets, unique equipment and custom variants. Used for global auditing of tooltips, prices, bonuses, appearances and effect contamination.", "Ajoute en un clic tous les équipements Trials Ascension actuellement créés ou modifiés dans cette build : récompenses de paliers, sets, équipements uniques et variantes custom. Utilisé pour l'audit global des tooltips, prix, bonus, apparences et contaminations."), function()
        Net.Request("DebugSpawnAllCustomGear"):After(DisplayResponse)
    end)

    Extras.Button(root, Localization.Get("h72a00000000000000000000000000105"), nil, function()
        Net.Request("DebugResetRewardPurchases"):After(DisplayResponse)
    end)
end

function Extras.Button(root, text, desc, callback)
    local root = root:AddGroup("")

    local b = root:AddButton(text)
    b.IDContext = U.RandomId()
    b.OnClick = callback

    if desc then
        for i, s in ipairs(string.split(desc, "\n")) do
            if s ~= "" then
                root:AddText(s).SameLine = i == 1
            end
        end
    end

    return root
end
