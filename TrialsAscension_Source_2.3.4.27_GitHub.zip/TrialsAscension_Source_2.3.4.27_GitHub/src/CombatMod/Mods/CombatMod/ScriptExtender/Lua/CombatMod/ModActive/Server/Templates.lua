local enemyTemplates = Require("CombatMod/Server/Templates/Enemies.lua")
local soloModeEnemyTemplates = Require("CombatMod/Server/Templates/LoneWolfEnemies.lua")
local exandriaEnemyTemplates = Require("CombatMod/Server/Templates/SOEEnemies.lua")
local exandriaSoloEnemyTemplates = Require("CombatMod/Server/Templates/SOELoneWolfEnemies.lua")
local mapTemplates = Require("CombatMod/Server/Templates/Maps.lua")
local scenarioTemplates = Require("CombatMod/Server/Templates/Scenarios.lua")
local unlockTemplates = Require("CombatMod/Server/Templates/Unlocks.lua")
local itemBlacklist = Require("CombatMod/Server/Templates/ItemBlacklist.lua")

local BROKEN_OWLBEAR_TEMPLATE = "f2d065e9-b779-4fe5-9a23-4cca8faae822"
local function RemoveBrokenOwlbear(list)
    local out = {}
    for _, enemy in ipairs(list or {}) do
        if enemy.TemplateId ~= BROKEN_OWLBEAR_TEMPLATE and enemy.Name ~= "TOT_Owlbear_Dad" then
            table.insert(out, enemy)
        end
    end
    return out
end
local originalLootRates = table.deepclone(C.LootRates)
local EXANDRIA_UUID = "a27fdbe3-4d1a-641d-d05f-1ba4ee529da8"

local function IsExandriaLoaded()
    return Ext.Mod.IsModLoaded(EXANDRIA_UUID)
end

if IsExandriaLoaded() then
	External.File.ExportIfNeeded("Enemies", exandriaEnemyTemplates)
else
	External.File.ExportIfNeeded("Enemies", enemyTemplates)
end
External.File.ExportIfNeeded("Maps", mapTemplates)
External.File.ExportIfNeeded("Scenarios", scenarioTemplates)
External.File.ExportIfNeeded("LootRates", originalLootRates)
External.File.ExportIfNeeded("ItemFilters", { Names = {}, Mods = {} })

function Templates.ExportEnemies()
    External.File.Export("Enemies", RemoveBrokenOwlbear(enemyTemplates))
end

function Templates.ExportSoloModeEnemies()
    External.File.Export("Enemies", RemoveBrokenOwlbear(soloModeEnemyTemplates))
end

function Templates.ExportExandriaModeEnemies()
    External.File.Export("Enemies", RemoveBrokenOwlbear(exandriaEnemyTemplates))
end

function Templates.ExportExandriaSoloModeEnemies()
    External.File.Export("Enemies", RemoveBrokenOwlbear(exandriaSoloEnemyTemplates))
end

function Templates.ExportMaps()
    External.File.Export("Maps", mapTemplates)
end

function Templates.ExportScenarios()
    External.File.Export("Scenarios", scenarioTemplates)
end

function Templates.ExportLootRates()
    External.File.Export("LootRates", originalLootRates)
end

function Templates.GetEnemies()
    if IsExandriaLoaded() then
        return table.deepclone(RemoveBrokenOwlbear(exandriaEnemyTemplates))
    else
        return table.deepclone(RemoveBrokenOwlbear(enemyTemplates))
    end
end

-- Centralized gameplay-table refresh used by the historical confirmation popup
-- and by manual template resets.  The important part is that the enemy cache is
-- invalidated AFTER writing Enemies.json, so the next encounter cannot keep an
-- older pre-refresh pool for up to 10 seconds.
function Templates.RefreshGameplayTables(reason)
    reason = reason or "manual"
    local exandria = IsExandriaLoaded()

    L.Info("[Trials Ascension] Refreshing gameplay tables", reason, "Exandria", exandria and "YES" or "NO")

    Templates.ExportScenarios()
    Templates.ExportMaps()
    if exandria then
        Templates.ExportExandriaModeEnemies()
    else
        Templates.ExportEnemies()
    end
    Templates.ExportLootRates()

    if Enemy and Enemy.ClearTemplateCache then
        Enemy.ClearTemplateCache()
    end

    -- Force one fresh read now and print a compact diagnostic.
    if Enemy and Enemy.GetTemplates then
        local pool = Enemy.GetTemplates() or {}
        local modded = 0
        local asmodeus = false
        for _, enemy in ipairs(pool) do
            local name = enemy.Name or ""
            if string.sub(name, 1, 4) == "MOD_" then
                modded = modded + 1
            end
            if name == "MOD_Asmo_Combat" or enemy.TemplateId == "d8caab24-6964-45c4-9bd2-ddb624a44119" then
                asmodeus = true
            end
        end
        L.Info("[Trials Ascension] Enemy pool refreshed", "entries", #pool, "MOD_", modded, "Asmodeus", asmodeus and "FOUND" or "NOT FOUND")
    end

    return true
end

function Templates.GetMaps()
    return table.deepclone(mapTemplates)
end

function Templates.GetScenarios()
    return table.deepclone(scenarioTemplates)
end

function Templates.GetUnlocks()
    return table.deepclone(unlockTemplates)
end

function Templates.GetItemFilters()
    return table.deepclone({ Names = itemBlacklist, Mods = {} })
end
