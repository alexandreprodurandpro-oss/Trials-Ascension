-------------------------------------------------------------------------------------------------
--                                                                                             --
--                                    Player introduction                                      --
--                                                                                             --
-------------------------------------------------------------------------------------------------

function Intro.AskTutSkip()
    return Player.AskConfirmation(TA_Text([[
Skip directly to camp?
Yes: go to camp to prepare Roguelike mode.
No: remain in the current campaign.]], [[
Passer directement au camp ?
Oui : rejoindre le camp pour préparer le mode Roguelike.
Non : rester dans la campagne actuelle.]]))
        :After(function(confirmed)
            if not confirmed then
                return
            end

            Schedule(function()
                for _, entity in pairs(GE.GetParty()) do
                    for _, item in pairs(entity.InventoryOwner.Inventories[1].InventoryContainer.Items) do
                        xpcall(function()
                            local isFromMod = Ext.Mod.GetMod(Ext.Stats.Get(item.Item.Data.StatsId).ModId).Info.Author
                                ~= ""
                            if not isFromMod then
                                GU.Object.Remove(item.Item.Uuid.EntityUuid)
                            end
                        end, L.Error)
                    end
                end
            end)

            Osi.Use(Player.Host(), "S_TUT_Helm_ControlPanel_bcbba417-6403-40a6-aef6-6785d585df2a", "")
            return Defer(1000)
        end)
        :After(function()
            local done = false
            GameState.OnLoad(function()
                Defer(3000, function()
                    Osi.PROC_GLO_Jergal_MoveToCamp()

                    -- go underdark to trigger tremor
                    Osi.TeleportToPosition(Player.Host(), 149.56359863281, 59.6376953125, -139.54454040527, "", 1, 1, 1)

                    return Defer(1000)
                end):After(function()
                    -- go to first camp
                    Osi.TeleportToPosition(Player.Host(), -649.25, -0.0244140625, -184.75, "", 1, 1, 1)
                    -- Osi.TeleportTo(Player.Host(), C.NPCCharacters.Jergal, "", 1, 1, 1)
                    Osi.PROC_Camp_ForcePlayersToCamp()

                    -- add starting items
                    Osi.AddGold(Player.Host(), 500)
                    Osi.TemplateAddTo("efcb70b7-868b-4214-968a-e23f6ad586bc", Player.Host(), 1, 0) -- camp supply backpack
                    Osi.TemplateAddTo("b7543ff4-5010-4c01-9bcd-4da1047aebfc", Player.Host(), 1, 0) -- alchemy pouch
                    Osi.TemplateAddTo("c1c3e4fb-d68c-4e10-afdc-d4550238d50e", Player.Host(), 4, 1) -- revify scrolls
                    Osi.TemplateAddTo("d47006e9-8a51-453d-b200-9e0d42e9bbab", Player.Host(), 10, 1) -- health potions
                    Osi.PROC_CAMP_GiveFreeSupplies()
                    Osi.PROC_CAMP_GiveFreeSupplies()
                    Osi.PROC_CAMP_GiveFreeSupplies()

                    -- recruitable hirelings at lvl 1
                    Osi.SetFlag("Hirelings_State_FeatureAvailable_66a34105-f02f-4c74-a3c8-085f1de12db8")
                    Osi.SetFlag("Hirelings_State_ShowIntro_b3983f00-096e-4e8b-82d5-8ae92a806dfc")
                    Osi.SetFlag(
                        "FCRD_Jergal_HirelingsIntro_02e588d1-0c38-4743-afba-481d1b842975",
                        C.NPCCharacters.Jergal
                    )

                    -- remove summon block
                    for _, p in pairs(GU.DB.GetPlayers()) do
                        Osi.RemoveStatus(p, "TUT_SUMMON_BLOCK")
                    end

                    -- maybe fix random cutscene at goblin camp related to Shadowheart
                    Osi.PROC_GLO_InfernalBox_SetNewOwner(Player.Host())
                    Osi.PROC_GLO_InfernalBox_AddToOwner()

                    -- fixing some potential issues with checkpoint
                    Osi.QRY_OnlyOnce("PLA_GithChokepoint_PlayerReaction_OnlyOnce")
                    Osi.TriggerUnregisterForCharacter("S_PLA_ChokepointLaezelADArea_b0ef4dd5-b22a-43cd-8129-ad52b532eba1", "S_Player_Laezel_58a69333-40bf-8358-1d17-fff240d7fb12")
                    Osi.PROC_GithChokepoint_Cancel("PLA")
                    Osi.PROC_PLA_GithChokepoint_CleanUp()

					-- make orpheus prison functional
					Osi.PROC_GLO_NarrativeCombat_EndCombat("INT_Orpheus_NarrativeCombat")
					Osi.PROC_TriggerUnregisterForPlayers("S_INT_EmperorRevealArea_f765db82-3fa8-4f4b-b92a-55bdc95fc1ba")
					Osi.DB_GLO_NarrativeCombat_Region:Delete("INT_Orpheus_NarrativeCombat",nil)

                    -- fixing Gale's arcane hunger
                    Osi.PROC_ORI_Gale_DisableDeathEffect()
					Osi.SetFlag("ORI_Gale_Event_BombDisarmed_3d014e79-5595-9365-87bb-5cbb1f87fe5c")
					
					-- prevent goblin party; prevent camps from getting wrecked by act transitions
					Osi.PROC_TOT_ClearGoal("Act1_CAMP_GoblinHuntCelebration")
					Osi.PROC_TOT_ClearGoal("Act1_CAMP_GoblinHuntCelebration_PostEA")
					Osi.DB_Level_InaccessibleAfterLoading:Delete(nil,nil)
					Osi.DB_Level_InaccessibleAfterFlagSet:Delete(nil,nil)

                    -- maybe fixing a niche Orin interaction
                    Osi.PROC_GEN_OrinsAbduction_DisableAllImpersonations()
					
					-- prevent colony teleport on load
					Osi.DB_OnlyOnce("KethericShowdown_CrownController")

                    Player.Notify(__("Starting items added. Hirelings unlocked."))
                    done = true

                    Osi.AutoSave()
                end)
            end, true)

            return WaitUntil(function()
                return done
            end):After(function()
                return Defer(1000)
            end)
        end)
end

function Intro.AskOnboarding()
    PersistentVars.Active = false
    PersistentVars.Asked = true

    return Player.AskConfirmation(TA_Text("Welcome to Trials Ascension! Enable the mod?", "Bienvenue dans Trials Ascension ! Activer le mod ?"))
        :After(function(confirmed)
            if not confirmed then
                return
            end

            Event.Trigger("ModActive")

            if Player.Region() == C.Regions.Act0 then
                return Intro.AskTutSkip()
            end

            return true
        end)
        :After(function()
            Intro.AskEnableRogueMode()
        end)
end

function Intro.AskEnableRogueMode()
    local rogueConfirmed = false

    return Player.AskConfirmation(TA_Text([[
Enable Roguelike mode?
Recommended: Yes if you want to play Roguelike mode.
The mod will generate successive encounters and difficulty will increase with your RogueScore.]], [[
Activer le mode Roguelike ?
Recommandé : Oui si vous souhaitez jouer au mode Roguelike.
Le mod générera des combats successifs et la difficulté augmentera avec votre RogueScore.]])):After(function(confirmed)
        rogueConfirmed = confirmed
        L.Debug("RogueMode", confirmed)

        -- IMPORTANT:
        -- Do not activate RogueMode / open the Trials Ascension menu yet.
        -- Popup 4 must remain the only foreground UI until the player answers it.
        return Player.AskConfirmation(TA_Text([[
Refresh Trials Ascension tables?
Recommended: Yes.
Reloads available enemies, items, maps and scenarios, including compatible monsters from currently loaded mods.]], [[
Actualiser les tables de Trials Ascension ?
Recommandé : Oui.
Recharge les ennemis, objets, cartes et scénarios disponibles, y compris les monstres compatibles provenant des mods actuellement chargés.]]))
    end):After(function(refreshConfirmed)
        if refreshConfirmed then
            Templates.RefreshGameplayTables("Popup 4")
            Net.Send("GetTemplates")
        end

        -- Give the confirmation dialog one short UI tick to disappear before
        -- RogueModeChanged is allowed to open the main menu.
        return Defer(150)
    end):After(function()
        PersistentVars.RogueModeActive = rogueConfirmed

        if PersistentVars.RogueScore == 0 then
            PersistentVars.RogueScore = math.min(190, (Player.Level() - 1) * 10) -- +10 per level, max 190
        end

        Event.Trigger("RogueModeChanged", PersistentVars.RogueModeActive)

        -- Refresh selectable scenarios/maps only AFTER the final RogueMode state
        -- exists. This avoids the temporary/default Bias selection race.
        Net.Send("GetSelection")

        -- Robust recovery: explicitly mark/open the GUI after popup 4 instead of
        -- depending only on the RogueModeChanged listener and previous GUIOpen state.
        if rogueConfirmed then
            PersistentVars.GUIOpen = true
            Net.Send("OpenGUI")
        end

        return rogueConfirmed
    end)
end

Ext.Osiris.RegisterListener("AutomatedDialogStarted", 2, "after", function(dialog, instanceID)
    -- if
    --     string.contains(dialog, {
    --         "GLO_Jergal_AD_AttackFromDialog",
    --         "GLO_Jergal_AD_AttackedByPlayer",
    --     })
    -- then
    --     if PersistentVars.Active then
    --         Net.Send("OpenGUI", {})
    --     end
    -- end

    if not PersistentVars.Active and dialog:match("GLO_Jergal_AD_AttackFromDialog") then
        Intro.AskOnboarding()
    end
end)

Ext.Osiris.RegisterListener("DialogActorJoined", 4, "after", function(dialog, instanceID, actor, speakerIndex)
    if
        string.contains(dialog, {
            "TUT_Start_PAD_Start_",
            "TUT_Misc_PAD_OriginPod_PlayerEmpty_",
        }) and U.UUID.Equals(actor, Player.Host())
    then
        Intro.AskOnboarding()
    end

    -- if dialog:match("CAMP_Jergal_") then
    --     if PersistentVars.Active and not PersistentVars.GUIOpen then
    --         Osi.DialogRemoveActorFromDialog(instanceID, actor)
    --         Osi.DialogRequestStopForDialog(dialog, actor)
    --
    --         if U.UUID.Equals(actor, Player.Host()) then
    --             Net.Send("OpenGUI", {})
    --         end
    --     end
    -- end
end)
