CombatTheme = {}

-- Experimental palette: dark BG3-like charcoal + bronze/gold accents.
CombatTheme.Colors = {
    WindowBg      = { 0.055, 0.050, 0.045, 0.98 },
    ChildBg       = { 0.075, 0.068, 0.058, 0.96 },
    PopupBg       = { 0.065, 0.058, 0.050, 0.98 },
    Border        = { 0.42, 0.31, 0.16, 0.80 },
    Separator     = { 0.52, 0.36, 0.15, 0.90 },
    Text          = { 0.93, 0.88, 0.76, 1.00 },
    TextDisabled  = { 0.52, 0.48, 0.42, 1.00 },
    Button        = { 0.24, 0.16, 0.08, 1.00 },
    ButtonHovered = { 0.39, 0.25, 0.10, 1.00 },
    ButtonActive  = { 0.58, 0.36, 0.10, 1.00 },
    Header        = { 0.20, 0.13, 0.07, 1.00 },
    HeaderHovered = { 0.34, 0.22, 0.09, 1.00 },
    HeaderActive  = { 0.48, 0.30, 0.10, 1.00 },
    Tab           = { 0.13, 0.10, 0.07, 1.00 },
    TabHovered    = { 0.38, 0.24, 0.09, 1.00 },
    TabActive     = { 0.47, 0.29, 0.09, 1.00 },
    TitleBg       = { 0.10, 0.075, 0.05, 1.00 },
    TitleBgActive = { 0.22, 0.14, 0.06, 1.00 },
}

function CombatTheme.Apply(root)
    for key, value in pairs(CombatTheme.Colors) do
        pcall(function() root:SetColor(key, value) end)
    end
    pcall(function() root:SetStyle("WindowPadding", 18, 16) end)
    pcall(function() root:SetStyle("FramePadding", 10, 7) end)
    pcall(function() root:SetStyle("ItemSpacing", 10, 8) end)
    pcall(function() root:SetStyle("WindowRounding", 5) end)
    pcall(function() root:SetStyle("FrameRounding", 4) end)
end

function CombatTheme.Primary(button)
    pcall(function() button:SetColor("Button", { 0.46, 0.27, 0.07, 1.00 }) end)
    pcall(function() button:SetColor("ButtonHovered", { 0.62, 0.39, 0.10, 1.00 }) end)
    pcall(function() button:SetColor("ButtonActive", { 0.74, 0.48, 0.13, 1.00 }) end)
end

function CombatTheme.Secondary(button)
    pcall(function() button:SetColor("Button", { 0.15, 0.12, 0.09, 1.00 }) end)
    pcall(function() button:SetColor("ButtonHovered", { 0.28, 0.20, 0.11, 1.00 }) end)
end


-- Shared muted card palette.
-- Neighbouring cards intentionally use different accents so each bonus is
-- readable as an individual card without making the UI neon/flashy.
CombatTheme.CardPalette = {
    { 0.72, 0.47, 0.18, 1.00 }, -- aged bronze
    { 0.32, 0.50, 0.67, 1.00 }, -- steel blue
    { 0.62, 0.27, 0.25, 1.00 }, -- burgundy
    { 0.39, 0.56, 0.34, 1.00 }, -- moss green
    { 0.50, 0.34, 0.58, 1.00 }, -- dark violet
    { 0.67, 0.43, 0.22, 1.00 }, -- amber brown
    { 0.43, 0.47, 0.53, 1.00 }, -- slate
    { 0.27, 0.52, 0.50, 1.00 }, -- petrol
    { 0.56, 0.33, 0.46, 1.00 }, -- muted plum
}

-- Backgrounds are deliberately more visible than before, but stay very dark.
-- They are not simple multiplications of the border color because that made
-- the differences almost impossible to see on a black BG3-style window.
CombatTheme.CardBackgroundPalette = {
    { 0.105, 0.078, 0.050, 0.96 }, -- bronze brown
    { 0.060, 0.082, 0.110, 0.96 }, -- blue night
    { 0.105, 0.058, 0.056, 0.96 }, -- wine red
    { 0.060, 0.090, 0.058, 0.96 }, -- forest
    { 0.082, 0.058, 0.100, 0.96 }, -- violet night
    { 0.105, 0.072, 0.048, 0.96 }, -- amber
    { 0.072, 0.076, 0.086, 0.96 }, -- slate
    { 0.052, 0.088, 0.086, 0.96 }, -- petrol
    { 0.092, 0.058, 0.078, 0.96 }, -- plum
}

function CombatTheme.CardColor(index)
    local n = #CombatTheme.CardPalette
    return CombatTheme.CardPalette[((index - 1) % n) + 1]
end

function CombatTheme.CardBackground(index)
    local n = #CombatTheme.CardBackgroundPalette
    return CombatTheme.CardBackgroundPalette[((index - 1) % n) + 1]
end

-- Creates a framed NON-SCROLLING card.
-- Important: do not use AddChildWindow here. Child windows own their own scroll
-- context in the Script Extender UI, which caused every bonus/reward tile to
-- capture the mouse wheel. A one-cell table gives us a visual frame while the
-- surrounding page/table remains the only vertical scrolling surface.
function CombatTheme.Card(root, id, index, height, customAccent, customBackground)
    local accent = customAccent or CombatTheme.CardColor(index)
    local background = customBackground or CombatTheme.CardBackground(index)
    local frame = root:AddTable(id, 1)
    frame.Borders = true

    -- Best-effort visual styling only; unsupported style/color keys are ignored.
    pcall(function() frame.RowBg = true end)
    pcall(function() frame:SetColor("TableBorderStrong", accent) end)
    pcall(function() frame:SetColor("TableBorderLight", accent) end)
    pcall(function() frame:SetColor("TableRowBg", background) end)
    pcall(function() frame:SetColor("TableRowBgAlt", background) end)
    pcall(function() frame:SetStyle("CellPadding", 10, 8) end)

    local row = frame:AddRow()
    local cell = row:AddCell()
    local card = cell:AddGroup(id .. "_Content")

    return card, accent
end

function CombatTheme.AccentText(widget, index)
    pcall(function() widget:SetColor("Text", CombatTheme.CardColor(index)) end)
end

function CombatTheme.Danger(button)
    pcall(function() button:SetColor("Button", { 0.38, 0.08, 0.07, 1.00 }) end)
    pcall(function() button:SetColor("ButtonHovered", { 0.56, 0.12, 0.10, 1.00 }) end)
    pcall(function() button:SetColor("ButtonActive", { 0.70, 0.16, 0.13, 1.00 }) end)
end
