# Trials Ascension

**Current source version:** `2.3.4.27`  
**Developer / maintainer:** Jam4_

Trials Ascension is a Baldur's Gate 3 roguelike overhaul derived from the Trials of Tav / Trials of Tav Reloaded codebase and extensively expanded with its own progression systems, encounters, rewards, equipment, contracts, Ascension systems and UI.

## Repository layout

The exact unpacked mod source is located in:

`src/CombatMod/`

This directory is the package root used to build `CombatMod.pak`.

The internal package/module name is intentionally still `CombatMod` for compatibility. Do not rename internal folders, UUIDs or namespaces unless all references are migrated deliberately.

## Building the PAK

Use a BG3-compatible LSLib / Divine ExportTool.

Example:

```text
Divine.exe -g bg3 -a create-package -s "<repo>\src\CombatMod" -d "CombatMod.pak" -c lz4hc
```

The output file should be named:

`CombatMod.pak`

The PAK is the installable build. The files in `src/CombatMod/` are the source/unpacked workspace.

## Required external dependencies

Trials Ascension expects the following external projects to be installed separately:

- ImprovedUI / ImpUI
- UnlockLevelCurve
- AdvancedTabletopSpells
- BG3 Script Extender

Optional integration:

- Spells of Exandria

**AdvancedTabletopSpells and Spells of Exandria are separate external projects. Their content is not part of Trials Ascension and is not redistributed in this repository.**

Do not add or republish their PAK files in this repository.

## Recommended player load order

1. ImprovedUI
2. UnlockLevelCurve
3. AdvancedTabletopSpells
4. Trials Ascension

## Localization

Current supported in-game languages:

- English
- French

## Credits and licensing

See `CREDITS_AND_LICENSE.txt`.

This repository contains code derived from the GPL-3.0 Trials codebase. Inherited GPL-covered code remains subject to GPL-3.0.

Baldur's Gate 3, its assets, characters and related intellectual property remain the property of their respective rights holders.

## Source integrity

`SOURCE_MANIFEST_SHA256.txt` contains SHA-256 hashes for every file extracted from the public `2.3.4.27` PAK used to create this repository snapshot.
